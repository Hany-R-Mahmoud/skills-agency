# Skill Map

## Foundation

- `diagram-foundation`: `modes/diagram-foundation/PLAYBOOK.md`, shared
  visualization framing, scope definition, and abstraction-level rules

Always start with `diagram-foundation`.

## Modes

- `mermaid-diagrams`: `modes/mermaid-diagrams/PLAYBOOK.md`, Mermaid flows,
  sequences, states, and lightweight architecture visuals
- `c4-context`: `modes/c4-context/PLAYBOOK.md`, system context diagrams
- `c4-container`: `modes/c4-container/PLAYBOOK.md`, container-level diagrams
- `c4-component`: `modes/c4-component/PLAYBOOK.md`, component-level diagrams
- `c4-code`: `modes/c4-code/PLAYBOOK.md`, code-level relationships and
  dependencies
- `artifact-support`: `modes/artifact-support/PLAYBOOK.md`, optional
  lightweight generated-support artifacts that help communicate a diagrammed
  system
