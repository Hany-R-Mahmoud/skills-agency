# Request Recipes

- "Make a Mermaid diagram":
  start with `diagram-foundation`; add `mermaid-diagrams`
- "Make a system context diagram":
  start with `diagram-foundation`; add `c4-context`
- "Make a container diagram":
  start with `diagram-foundation`; add `c4-container`
- "Make a component diagram":
  start with `diagram-foundation`; add `c4-component`
- "Show code-level structure":
  start with `diagram-foundation`; add `c4-code`
- "Generate a supporting visual artifact":
  start with `diagram-foundation`; add `artifact-support`
