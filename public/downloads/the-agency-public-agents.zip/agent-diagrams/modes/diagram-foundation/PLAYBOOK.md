---
name: diagram-foundation
description: Shared foundation for technical diagramming with abstraction discipline, audience fit, and low-clutter communication rules.
---

Use this playbook before any other `agent-diagrams` mode.

## Rules

- decide the audience and abstraction level before drawing
- show only the relationships needed for the decision or explanation
- prefer clean labels and readable grouping over maximal completeness
