---
name: c4-code
description: Build code-level structure views that show important modules, dependencies, and interfaces without becoming an unreadable dump.
---

Use for code-level relationship mapping when implementation details matter.
