---
name: c4-container
description: Build C4 container diagrams that show deployable/runtime building blocks, data stores, and major integrations.
---

Use for service and runtime topology.
