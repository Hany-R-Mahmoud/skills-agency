---
name: mermaid-diagrams
description: Create Mermaid diagrams that are readable, syntactically valid, and fitted to the user's actual communication goal.
---

Use for flowcharts, sequences, state diagrams, and simple architecture visuals.
