---
name: c4-component
description: Build C4 component diagrams that show internal service or application structure without collapsing into code trivia.
---

Use for internal subsystem decomposition.
