---
name: artifact-support
description: Create lightweight supporting artifacts around a diagram when small generated visuals improve communication, while keeping the core artifact diagram-first.
---

Use this mode sparingly when a diagram benefits from a small supporting visual
or generated companion artifact.

## Guardrails

- the diagram remains the primary communication object
- avoid decorative artifacts that do not clarify the system
- keep vendor-specific generation optional
