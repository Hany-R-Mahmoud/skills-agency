---
name: c4-context
description: Build C4 context diagrams showing the system, primary actors, and neighboring systems at the right abstraction level.
---

Use for high-level system boundaries and external relationships.
