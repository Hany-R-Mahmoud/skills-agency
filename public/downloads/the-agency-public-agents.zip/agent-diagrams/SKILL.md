---
name: agent-diagrams
description: Unified architecture and technical diagrams agent for this skill pack. Use when Codex should create Mermaid diagrams, C4 views, or visual technical communication artifacts, with optional lightweight generated-support artifacts, through one local entry point.
---

# Agent Diagrams

Provide a single public entry point for technical diagrams and architecture
visualization work.

Act as a router plus executor: choose the smallest set of diagram modes needed,
sequence them well, and avoid loading irrelevant guidance.

## Invocation Contract

Invoke this skill directly as `$agent-diagrams` whenever the prompt is about
Mermaid diagrams, C4 diagrams, system visualization, or architecture
communication artifacts.

## Quick Start

- "make a Mermaid diagram":
  `diagram-foundation`, then `mermaid-diagrams`
- "make a C4 context diagram":
  `diagram-foundation`, then `c4-context`
- "make a C4 container diagram":
  `diagram-foundation`, then `c4-container`
- "make a component-level diagram":
  `diagram-foundation`, then `c4-component`
- "make a code-level dependency view":
  `diagram-foundation`, then `c4-code`
- "generate lightweight supporting artifacts":
  `diagram-foundation`, then `artifact-support`

## Reference

Use these references as needed:

- `references/skill-map.md`
- `references/request-recipes.md`
