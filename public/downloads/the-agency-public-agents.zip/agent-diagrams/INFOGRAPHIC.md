# Diagrams Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for DIAGRAMS inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Product and Design department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: DIAGRAMS
- Subtitle: Technical diagram specialist for Mermaid, C4, and system visuals
- Commands:
  - /agent-diagrams
  - $agent-diagrams
- One-line value:
  The diagram specialist for Mermaid, C4, and architecture communication artifacts. Turns complex systems into clearer visual reasoning and handoff material.
- Capabilities:
  - Mermaid diagrams
  - C4 views
  - architecture visuals
  - technical communication
- How it works:
  - reads the visualization need
  - chooses the smallest useful diagram lanes
  - shapes the diagram around the real handoff goal
  - returns a clearer visual artifact
- Best used when:
  - you need a clear system diagram instead of more descriptive prose
  - an architecture review or handoff would benefit from a visual model
  - the task calls for Mermaid, C4, or lightweight generated support artifacts
- Bottom summary:
  diagram-foundation, mermaid-diagrams, c4-context, c4-container, artifact-support
- Footer note:
  You ask for the outcome. Diagrams makes the structure legible.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
