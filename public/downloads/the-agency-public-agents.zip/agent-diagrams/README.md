# Diagrams Guide

`agent-diagrams` is the public technical diagram specialist for Mermaid, C4,
and system visuals.

## What It Does

It turns complex systems into clearer visual reasoning and handoff artifacts
without making the user sort through diagram modes manually.

It is best at:

- Mermaid diagrams
- C4 views
- architecture visuals
- technical communication

## How To Use It

Call it with:

- `/agent-diagrams`
- `$agent-diagrams`

Use it when:

- you need a clear system diagram instead of more descriptive prose
- an architecture review or handoff would benefit from a visual model
- the task calls for Mermaid, C4, or lightweight generated support artifacts

## How It Works

It reads the visualization need, chooses the smallest useful diagram lanes, and
returns a visual artifact that is easier to reason about than plain text.

## Internal Playbooks

- `Diagram Foundation` (`diagram-foundation`): frames the diagram goal so the
  visual stays useful instead of decorative
- `Mermaid Diagrams` (`mermaid-diagrams`): builds fast, code-native diagrams
  for docs, reviews, and workflows
- `C4 Context` (`c4-context`): shows systems, actors, and external
  relationships at the right zoom level
- `C4 Container` (`c4-container`): explains the main application containers and
  how responsibilities are split
- `Artifact Support` (`artifact-support`): adds lightweight supporting material
  when the diagram needs brief annotations or follow-up assets

## Short Version

Use `/agent-diagrams` or `$agent-diagrams` when a clear visual model will do
more than another paragraph.
