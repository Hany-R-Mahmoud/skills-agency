# Agent Product Guide

`agent-product` is the public product strategy and delivery decision-making
entry point in this skill pack.

## What It Does

It helps shape product strategy, prioritization, feedback synthesis, delivery
plans, workflow operations, experiments, trend research, and behavioral product
decisions through one public surface.

It is best at:

- product strategy
- prioritization and planning
- feedback synthesis
- delivery and workflow operations
- experiment design
- trend and behavioral product decisions

## How To Use It

Call it with:

- `/agent-product`
- `$agent-product`

Use it when:

- the request is about product strategy, opportunity framing, or roadmap
  direction
- you need prioritization, sprint planning, or delivery planning with explicit
  tradeoffs
- the work depends on feedback synthesis, experiments, workflow governance, or
  retention-oriented product design

## How It Works

It reads the product decision, starts from `product-foundation`, chooses the
smallest useful supporting modes, and returns one cohesive product artifact.

## Internal Playbooks

- `Product Foundation` (`product-foundation`): shared product framing and
  decision hygiene
- `Product Core` (`product-core`): strategy, PRD framing, roadmap logic, and
  success metrics
- `Sprint Prioritization` (`sprint-prioritization`): backlog, ranking, and
  sequencing tradeoffs
- `Feedback Synthesis` (`feedback-synthesis`): turns user input into clearer
  product signals
- `Delivery Management` (`delivery-management`): shapes execution packets,
  scope, and stakeholder alignment
- `Workflow Operations` (`workflow-operations`): handles Jira, release hygiene,
  and process governance
- `Experiment Tracking` (`experiment-tracking`): adds hypotheses, rollout
  logic, and decision thresholds
- `Trend Research` (`trend-research`): brings in market and competitor signals
- `Behavioral Nudges` (`behavioral-nudges`): supports activation, engagement,
  and retention design

## Short Version

Use `/agent-product` or `$agent-product` when the core question is what to do,
why to do it, and how to sequence it safely.
