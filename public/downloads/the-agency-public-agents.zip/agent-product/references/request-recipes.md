# Request Recipes

Use this file when the user describes a product outcome instead of naming a
specific internal mode.

## Core Product Work

- "write the PRD":
  start with `product-foundation`; add `product-core`
- "shape the roadmap":
  start with `product-foundation`; add `product-core`
- "assess this opportunity":
  start with `product-foundation`; add `product-core`; sometimes add
  `trend-research`

## Prioritization

- "what should we build next":
  start with `product-foundation`; add `sprint-prioritization`
- "plan the sprint":
  start with `product-foundation`; add `sprint-prioritization`
- "rank these features":
  start with `product-foundation`; add `sprint-prioritization`

## Delivery And Operations

- "turn this into a project plan":
  start with `product-foundation`; add `delivery-management`
- "break this into tasks":
  start with `product-foundation`; add `delivery-management`
- "align stakeholders and timeline":
  start with `product-foundation`; add `delivery-management`
- "clean up the Jira or release workflow":
  start with `product-foundation`; add `workflow-operations`
- "make this delivery process traceable":
  start with `product-foundation`; add `workflow-operations`

## Experiments

- "design the experiment":
  start with `product-foundation`; add `experiment-tracking`
- "evaluate this A/B test":
  start with `product-foundation`; add `experiment-tracking`
- "track rollout and go/no-go":
  start with `product-foundation`; add `experiment-tracking`

## Feedback And Evidence

- "synthesize this feedback":
  start with `product-foundation`; add `feedback-synthesis`
- "what are users asking for":
  start with `product-foundation`; add `feedback-synthesis`
- "turn feedback into recommendations":
  start with `product-foundation`; add `feedback-synthesis`; often add
  `product-core`

## Market And Behavior

- "research the market":
  start with `product-foundation`; add `trend-research`
- "what trends matter":
  start with `product-foundation`; add `trend-research`
- "improve activation or retention":
  start with `product-foundation`; add `behavioral-nudges`
- "design better nudges":
  start with `product-foundation`; add `behavioral-nudges`

## Guardrail

Do not map vague prompts to every product mode. Pick the most likely primary
mode, then add only the supporting modes needed to finish the job well.
