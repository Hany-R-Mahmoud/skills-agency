# Skill Map

Use this file to route a request to the minimum useful subset of the internal
product modes bundled inside `agent-product`.

## Foundation

- `product-foundation`: shared problem framing, decision hygiene, evidence
  standards, and artifact-shaping rules

Always start with `product-foundation`.

## Product Modes

- `product-core`: strategy, PRDs, opportunity framing, roadmap logic, launch
  thinking, and success metrics
- `sprint-prioritization`: backlog triage, sequencing, scoring frameworks,
  scope control, and sprint planning
- `feedback-synthesis`: theme extraction, quote clustering, pain-point
  synthesis, voice-of-customer distillation, and recommendation framing
- `delivery-management`: project shaping, task breakdowns, stakeholder
  alignment, timelines, portfolio coordination, and execution packets
- `workflow-operations`: Jira-linked delivery hygiene, release-safe workflows,
  SOP-minded process design, and operational traceability
- `experiment-tracking`: hypothesis design, rollout monitoring, result
  interpretation, and experiment portfolio decisions
- `trend-research`: market shifts, competitor signals, emerging trends,
  opportunity scanning, and timing implications
- `behavioral-nudges`: activation flows, engagement loops, low-friction prompts,
  retention mechanics, and user-beneficial intervention design

## Recommended Bundles

- Write a strategy brief or PRD:
  `product-foundation`, then `product-core`
- Prioritize a sprint or backlog:
  `product-foundation`, then `sprint-prioritization`
- Turn raw feedback into action:
  `product-foundation`, then `feedback-synthesis`, optionally `product-core`
- Plan a delivery effort:
  `product-foundation`, then `delivery-management`, optionally
  `sprint-prioritization`
- Improve workflow or release discipline:
  `product-foundation`, then `workflow-operations`, optionally
  `delivery-management`
- Design or review an experiment:
  `product-foundation`, then `experiment-tracking`, optionally `product-core`
- Research market direction:
  `product-foundation`, then `trend-research`, optionally `product-core`
- Improve activation or retention:
  `product-foundation`, then `behavioral-nudges`, often with
  `feedback-synthesis`

## Anti-Pattern

Do not activate every product mode just because a request touches "strategy."
Choose the smallest useful bundle that can produce a coherent result.
