---
name: behavioral-nudges
description: Design user-beneficial nudges, activation loops, and low-friction behavior interventions.
path: skills/agent-product/modes/behavioral-nudges/PLAYBOOK.md
tags:
  - product
  - behavior
  - activation
---

# Behavioral Nudges

## Scope

Use this mode for activation, retention, momentum-building prompts, progress
loops, and low-friction behavioral product interventions.

## Instructions

- Prefer one clear next step over a pile of notifications.
- Reduce cognitive load before adding motivation mechanics.
- Design nudges to help users reach their own goals, not just the product's
  short-term metrics.
- Respect timing, channel fit, and user control.
- Make opt-out paths and user trust explicit parts of the design.

## Typical Outputs

- nudge strategy
- prompt sequence
- intervention logic
- trust and opt-out guidance
- success metrics for behavior change
