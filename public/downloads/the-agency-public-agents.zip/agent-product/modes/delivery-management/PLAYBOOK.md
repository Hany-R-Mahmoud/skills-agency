---
name: delivery-management
description: Turn product goals into realistic delivery plans, task packets, timelines, and stakeholder alignment artifacts.
path: skills/agent-product/modes/delivery-management/PLAYBOOK.md
tags:
  - product
  - delivery
  - project-management
---

# Delivery Management

## Scope

Use this mode for project planning, task decomposition, stakeholder alignment,
timeline framing, portfolio coordination, and execution packets that connect
product intent to real delivery.

## Instructions

- Translate goals and specs into concrete work units without inflating scope.
- Keep plans realistic about dependencies, time, and coordination cost.
- Prefer smaller, reviewable work packets over vague milestone prose.
- Make risks, blockers, and decision points explicit.
- Preserve clarity between committed work, proposed work, and nice-to-have
  additions.

## Typical Outputs

- delivery plan
- project packet
- task breakdown
- milestone or timeline summary
- stakeholder alignment notes
