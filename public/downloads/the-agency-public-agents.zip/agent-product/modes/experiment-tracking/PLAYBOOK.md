---
name: experiment-tracking
description: Design experiments, track execution, and turn results into clear product decisions.
path: skills/agent-product/modes/experiment-tracking/PLAYBOOK.md
tags:
  - product
  - experiments
  - validation
---

# Experiment Tracking

## Scope

Use this mode for A/B test design, hypothesis framing, rollout tracking,
experiment monitoring, result interpretation, and go/no-go decision support.

## Instructions

- Start with the hypothesis, success metric, and guardrails.
- Define what counts as a decision, not just what counts as data.
- Make rollout safety and rollback conditions explicit.
- Separate statistical or observational evidence from product judgment.
- Capture learnings so future experiments do not restart from scratch.

## Typical Outputs

- experiment brief
- hypothesis and metric plan
- rollout checklist
- result summary
- go/no-go recommendation
