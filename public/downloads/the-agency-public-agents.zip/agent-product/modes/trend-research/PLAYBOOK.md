---
name: trend-research
description: Research market direction, competitive shifts, and emerging signals that matter for product strategy.
path: skills/agent-product/modes/trend-research/PLAYBOOK.md
tags:
  - product
  - trends
  - market
---

# Trend Research

## Scope

Use this mode for market scans, competitive intelligence, emerging trend
analysis, opportunity timing, and strategic product implications.

## Instructions

- Focus on signals that could materially affect product decisions.
- Prefer high-quality sources and recent evidence when the space is changing.
- Separate observed signals from forecasted implications.
- Avoid trend-chasing without linking the signal back to user value or
  strategic fit.
- End with what the team should watch, test, adopt, or ignore.

## Typical Outputs

- trend brief
- competitive map
- opportunity scan
- timing assessment
- recommended watchlist or action set
