---
name: product-core
description: Shape product strategy, PRDs, initiative framing, roadmap logic, and launch thinking.
path: skills/agent-product/modes/product-core/PLAYBOOK.md
tags:
  - product
  - strategy
  - prd
---

# Product Core

## Scope

Use this mode for product strategy, PRDs, initiative framing, roadmap choices,
opportunity assessments, non-goals, and success metrics.

## Instructions

- Start with the user pain, business objective, and evidence for why this
  matters now.
- Define goals and non-goals before solution detail.
- Make success metrics concrete and time-bound when possible.
- Name open questions, dependencies, and launch risks explicitly.
- Prefer concise, shippable product documents over bloated templates.

## Typical Outputs

- product brief
- PRD
- opportunity assessment
- roadmap rationale
- launch framing and success metrics
