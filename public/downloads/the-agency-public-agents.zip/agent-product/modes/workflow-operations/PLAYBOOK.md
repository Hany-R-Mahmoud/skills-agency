---
name: workflow-operations
description: Define delivery hygiene, Jira-linked workflow rules, release-safe process design, and operational traceability.
path: skills/agent-product/modes/workflow-operations/PLAYBOOK.md
tags:
  - product
  - workflow
  - operations
---

# Workflow Operations

## Scope

Use this mode for Jira or ticket hygiene, release process rules, Git-delivery
traceability, SOP-style workflow design, and operational guardrails that make
product delivery more reliable and auditable.

## Instructions

- Add process only when it improves clarity, safety, or reviewability.
- Keep workflow rules concrete enough to execute under delivery pressure.
- Treat traceability as a quality tool, not empty ceremony.
- Make handoff boundaries and review expectations explicit.
- Separate repository-specific rules from generally reusable workflow guidance.

## Typical Outputs

- workflow policy
- Jira delivery packet
- release process notes
- branch or review guidance
- SOP-style operational checklist
