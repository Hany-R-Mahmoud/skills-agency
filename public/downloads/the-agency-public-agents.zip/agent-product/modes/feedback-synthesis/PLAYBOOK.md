---
name: feedback-synthesis
description: Turn raw customer and user input into themes, implications, and product recommendations.
path: skills/agent-product/modes/feedback-synthesis/PLAYBOOK.md
tags:
  - product
  - feedback
  - synthesis
---

# Feedback Synthesis

## Scope

Use this mode for collecting, clustering, and interpreting feedback from users,
support, reviews, research, or community channels.

## Instructions

- Distinguish loud feedback from representative feedback.
- Group inputs into themes, pains, requests, and contextual signals.
- Preserve a few strong quotes when they sharpen the recommendation.
- Separate symptom reports from underlying product problems.
- End with product implications, not just categorized notes.

## Typical Outputs

- feedback theme summary
- pain-point clusters
- representative quotes
- recommendation set
- confidence and signal-strength notes
