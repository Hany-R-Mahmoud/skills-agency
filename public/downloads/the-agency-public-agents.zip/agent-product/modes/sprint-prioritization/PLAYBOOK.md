---
name: sprint-prioritization
description: Rank work, control scope, and turn product goals into realistic sprint or backlog priorities.
path: skills/agent-product/modes/sprint-prioritization/PLAYBOOK.md
tags:
  - product
  - prioritization
  - sprint
---

# Sprint Prioritization

## Scope

Use this mode for sprint planning, backlog ranking, prioritization frameworks,
scope tradeoffs, sequencing, and capacity-aware product choices.

## Instructions

- Clarify the product goal before ranking items.
- Use an explicit prioritization lens such as value, effort, risk, and timing.
- Call out dependencies, blockers, and scope creep risk.
- Prefer a realistic, well-justified cut over an optimistic overloaded sprint.
- Distinguish must-ship work from nice-to-have work.

## Typical Outputs

- prioritized backlog
- sprint recommendation
- scoring table
- sequencing rationale
- scope tradeoff summary
