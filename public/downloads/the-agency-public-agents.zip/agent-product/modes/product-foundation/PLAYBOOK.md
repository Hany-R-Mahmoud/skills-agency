---
name: product-foundation
description: Shared foundation for product framing, evidence standards, and decision-ready artifacts inside agent-product.
path: skills/agent-product/modes/product-foundation/PLAYBOOK.md
tags:
  - product
  - foundation
  - strategy
  - decision
---

# Product Foundation

## Scope

Use this playbook first for `agent-product` tasks. It sets the baseline for
problem framing, evidence handling, tradeoff clarity, and output shaping before
any specialized mode is applied.

## Instructions

- Lead with the problem, not the proposed feature.
- Identify the decision that needs to be made before expanding the artifact.
- Separate facts, assumptions, hypotheses, and recommendations.
- Prefer decision-ready product artifacts over ceremonial process output.
- Make tradeoffs explicit:
  - user value
  - business value
  - implementation cost
  - risk
- Decide whether the task is primarily:
  - product strategy
  - prioritization
  - delivery planning
  - workflow governance
  - experimentation
- State the confidence level behind important calls.

## Context Gathering Protocol

Gather only what materially affects the product decision:

- user segment or persona
- product surface or workflow
- business goal or metric
- current pain point or opportunity
- constraints, dependencies, or timeline
- available evidence such as feedback, analytics, or market signal
- delivery constraints, workflow rules, or operating cadence

If context is missing, make a reasonable assumption and label it clearly unless
the risk of guessing is high.

## Quality Checks

- Is the problem statement clear?
- Are the tradeoffs legible?
- Is the recommendation grounded in evidence rather than momentum?
- Would a team know what to do next from this artifact?
