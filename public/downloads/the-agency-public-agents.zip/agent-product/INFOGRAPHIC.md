# Agent Product Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for AGENT PRODUCT inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Product and Design department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: AGENT PRODUCT
- Subtitle: Product strategy and delivery decision-making specialist
- Commands:
  - /agent-product
  - $agent-product
- One-line value:
  Shapes product strategy, roadmap choices, feedback synthesis, sprint priorities, delivery plans, workflow operations, experiment tracking, trend analysis, and behavioral intervention design through one public entry point.
- Capabilities:
  - product strategy
  - prioritization and planning
  - feedback synthesis
  - delivery and workflow operations
  - experiments and trend research
  - behavioral product design
- How it works:
  - reads the product decision
  - starts with product-foundation
  - routes to the smallest useful internal playbooks
  - returns one cohesive product artifact
- Best used when:
  - the request is about strategy, roadmap direction, or initiative framing
  - you need prioritization, sprint planning, or delivery planning with explicit tradeoffs
  - the work depends on feedback synthesis, experiments, workflow governance, or retention design
- Bottom summary:
  product-foundation, product-core, sprint-prioritization, feedback-synthesis, delivery-management, workflow-operations, experiment-tracking, trend-research, behavioral-nudges
- Footer note:
  You ask for the outcome. Agent Product chooses the right decision lane.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
