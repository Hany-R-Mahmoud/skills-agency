---
name: agent-product
description: Unified product strategy and delivery decision-making entry point for this skill pack. Use when Codex should shape product strategy, roadmap choices, feedback synthesis, sprint priorities, delivery plans, workflow operations, experiment tracking, trend analysis, or behavioral intervention design through one local entry point.
path: .codex/skills/agent-product/SKILL.md
tags:
  - agent
  - product
  - strategy
  - prioritization
  - research
---

# Agent Product

Provide a single public entry point for this repository's product work. Act as
a router plus executor: choose the smallest set of internal product modes
needed, sequence them well, and avoid loading irrelevant guidance.

Do not treat every imported product specialty as a public picker entry. Keep
the public surface thin and move specialized behavior into private modes and
references.

This skill is independent. It should stand on its own as the product surface
for requests about strategy, prioritization, feedback, discovery, delivery
planning, workflow governance, experiments, and behavioral product decisions.

## Invocation Contract

Invoke this skill directly as `$agent-product` whenever the prompt is about:

- product strategy, opportunity framing, or roadmap direction
- PRDs, initiative framing, success metrics, or launch planning
- sprint planning, backlog triage, sequencing, or prioritization tradeoffs
- feedback synthesis, theme extraction, or voice-of-customer analysis
- delivery planning, project coordination, scope shaping, or stakeholder
  alignment
- Jira-linked workflow rules, delivery operations, release hygiene, or process
  governance
- experiment design, rollout tracking, hypothesis validation, or go/no-go
  analysis
- trend research, market signals, or competitive product intelligence
- behavioral intervention design, nudges, activation prompts, or retention
  mechanics

When explicitly invoked, do not ask the user to choose internal modes unless
there is a real strategic tradeoff. Infer the likely path from the prompt, map
it to the minimum useful mode set, and proceed.

The user should not need to know or name the internal modes. Treat them as
private implementation details.

## Use This Skill For

- shaping product strategy from ambiguous problems and competing inputs
- writing or refining PRDs, opportunity briefs, roadmap summaries, and launch
  plans
- prioritizing features, backlog items, or sprint scope using explicit
  frameworks
- synthesizing feedback from users, support, reviews, and research into action
- scanning trends, competitors, and market shifts for product implications
- turning product goals into delivery plans, task breakdowns, and realistic
  execution packets
- managing workflow discipline, Jira traceability, or process quality where it
  materially affects delivery
- designing and tracking experiments with explicit hypotheses and decision gates
- designing nudge systems, activation loops, or low-friction behavior changes

## Do Not Use This Skill For

- code implementation tasks where the main need is editing software
- pure visual or frontend design work
- generic research tasks with no meaningful product decision to support
- broad project orchestration when the main need is generic delegation rather
  than product or delivery judgment

## Quick Start

If the request sounds like one of these, use the matching route immediately:

- "define the product strategy or PRD":
  `product-foundation`, then `product-core`
- "prioritize the sprint or backlog":
  `product-foundation`, then `sprint-prioritization`
- "synthesize what users are saying":
  `product-foundation`, then `feedback-synthesis`
- "plan delivery or break work into execution":
  `product-foundation`, then `delivery-management`
- "fix the workflow, Jira hygiene, or release process":
  `product-foundation`, then `workflow-operations`
- "design or evaluate an experiment":
  `product-foundation`, then `experiment-tracking`
- "analyze the market or trends":
  `product-foundation`, then `trend-research`
- "design nudges or activation":
  `product-foundation`, then `behavioral-nudges`

If the request mixes several of these, choose one primary mode and add only the
minimum supporting modes needed to finish the job coherently.

## Core Workflow

1. Inspect the request and classify it:
   - strategy and goals
   - roadmap or requirement shaping
   - backlog and sprint prioritization
   - customer or user feedback synthesis
   - delivery planning and coordination
   - workflow governance and process hygiene
   - experiment design and decision tracking
   - market and trend research
   - behavior and retention design
2. Load `modes/product-foundation/PLAYBOOK.md` first for shared product framing
   and decision hygiene.
3. Choose the minimum supporting modes from `references/skill-map.md` and
   `references/request-recipes.md`.
4. Execute in a sane order:
   - define the problem and decision
   - gather only the evidence that materially changes the call
   - make tradeoffs explicit
   - produce the product artifact
   - name residual risk and the next validation step
5. Keep the output cohesive. If multiple modes are used, resolve conflicts
   instead of stacking contradictory advice.

## Automatic Routing Rule

When the prompt contains product intent but does not specify a mode:

- infer the dominant product intent from the request
- choose one primary mode
- add only the minimum supporting modes needed
- continue without asking the user to pick from internal skills

Escalate only when the prompt genuinely points to incompatible outcomes, such
as "maximize short-term revenue" and "optimize entirely for long-term trust"
without any stated priority.

## Routing Rules

Default to these bundles:

- Strategy, PRD, or roadmap framing:
  `product-foundation` plus `product-core`; add `trend-research` or
  `feedback-synthesis` when the evidence base needs strengthening
- Sprint or backlog decisions:
  `product-foundation` plus `sprint-prioritization`; add `product-core` when
  initiative goals need clarification
- Feedback-driven product decisions:
  `product-foundation` plus `feedback-synthesis`; add `product-core` when the
  output must become a recommendation or PRD
- Delivery plans, task packets, or stakeholder alignment:
  `product-foundation` plus `delivery-management`; add
  `sprint-prioritization` when sequencing or scope tradeoffs matter
- Jira, release discipline, or process operations:
  `product-foundation` plus `workflow-operations`; add
  `delivery-management` when the workflow change is tied to a concrete project
- Experiment design and rollout decisions:
  `product-foundation` plus `experiment-tracking`; add `product-core` or
  `behavioral-nudges` when the experiment is tied to a larger product bet
- Market or competitor-driven product decisions:
  `product-foundation` plus `trend-research`; add `product-core` when the
  output needs strategy or roadmap framing
- Activation, engagement, or retention work:
  `product-foundation` plus `behavioral-nudges`; add `feedback-synthesis` when
  the nudge design should be grounded in user signal

If a request is narrow, stay narrow. Do not pull in trends, feedback, sprint
planning, delivery governance, and nudges by default when one product lane is
enough.

Prefer a primary mode and at most 2-4 supporting modes for most tasks.

## Conflict Resolution

Some modes pull in opposite directions. Resolve them deliberately:

- `product-core` vs `sprint-prioritization`:
  clarify the product objective first, then optimize the sprint around it
- `trend-research` vs `feedback-synthesis`:
  prefer direct user evidence for near-term product decisions; use trend
  signals to shape medium-term bets
- `delivery-management` vs `workflow-operations`:
  use `delivery-management` for execution planning and stakeholder movement;
  use `workflow-operations` for repeatable process rules, traceability, and
  release hygiene
- `experiment-tracking` vs intuition:
  prefer explicit hypotheses, guardrails, and decision thresholds over vague
  "let's test it" language
- `behavioral-nudges` vs trust:
  prefer transparent, user-beneficial nudges over manipulative growth tactics
- `fast prioritization` vs weak evidence:
  move quickly when needed, but label confidence clearly and note what should be
  validated next

## Default Execution Standards

Regardless of which modes are selected:

- lead with the problem, not the requested solution
- separate facts, assumptions, hypotheses, and decisions
- make tradeoffs explicit instead of burying them in prose
- optimize for user value, business fit, and implementation realism together
- prefer smaller, decision-ready artifacts over bloated process documents
- use process and workflow rigor only when it improves delivery clarity or
  safety
- attach success metrics or validation expectations whenever practical

## User Request Translation

Users often describe outcomes, not modes. Translate intent like this:

- "write the PRD" usually means `product-core`
- "what should we build next" usually means `sprint-prioritization`
- "what are customers really asking for" usually means `feedback-synthesis`
- "how should we run this project" usually means `delivery-management`
- "how should this Jira or release workflow work" usually means
  `workflow-operations`
- "how do we structure this experiment" usually means `experiment-tracking`
- "what trends matter here" usually means `trend-research`
- "how do we improve engagement or retention" usually means
  `behavioral-nudges`

If the prompt mixes several product desires, prioritize in this order unless
the user says otherwise:

1. clarify the problem and desired outcome
2. ground the decision in the strongest available evidence
3. make the tradeoff and prioritization logic legible
4. produce the smallest useful product artifact
5. define the next measurement or validation step

## Output Shape

Match the task:

- For strategy or planning work:
  summarize the chosen modes, then present the framework, rationale, and next
  product moves
- For prioritization work:
  present the ranking logic, tradeoffs, and recommended sequence
- For delivery planning work:
  present the plan, dependencies, owners or work units, and the main execution
  risks
- For synthesis work:
  present themes, evidence, implications, and recommended actions

Always name the modes you chose when that helps the user understand why the
result was structured a certain way.

## Reference

Use these references as needed:

- `references/skill-map.md`: compact map of all internal modes
- `references/request-recipes.md`: common user phrasing to mode bundles

Read only the relevant entries rather than reloading every internal mode in
full.
