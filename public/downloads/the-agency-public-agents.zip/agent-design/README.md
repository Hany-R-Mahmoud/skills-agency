# Agent Design Guide

`agent-design` is the public design entry point for this skill pack.

It helps a developer turn a design request into the right design artifact without
having to know which internal playbook to pick first.

Think of it as:

- a router for design work
- a translator from messy requests into the right design lane
- a lightweight design partner for strategy, structure, storytelling, and
  visual direction

## What It Does

Use `agent-design` when the work is primarily about design thinking or design
artifacts, not production UI code.

It is built to help with:

- brand systems and identity direction
- UX research plans and synthesis
- UX architecture, flows, and information structure
- UI systems, tokens, and handoff guidance
- visual storytelling and campaign concepts
- inclusive visual direction and anti-bias review
- image prompting and art direction
- delight, personality, and playful interaction concepts

## How It Works

`agent-design` stays intentionally thin.

It does not try to do everything in one generic blob. Instead, it follows a
small routing system:

1. Read the request and identify the real design problem.
2. Start with `design-foundation`.
3. Pick the smallest useful set of internal playbooks.
4. Produce one cohesive output instead of stacking disconnected advice.

That means the developer usually only needs to say:

```text
$agent-design <what you want>
```

The skill then decides which internal mode should lead the work.

## Internal Playbooks

These are private implementation playbooks inside `agent-design`.
Most developers should not need to call them directly, but knowing what they do
makes the skill easier to steer.

| Playbook | What it is for | Typical output |
|---|---|---|
| `design-foundation` | Shared setup for context, constraints, artifact shape, and quality checks | Framing, assumptions, artifact choice, handoff shape |
| `brand-system` | Brand strategy, identity direction, voice, and consistency rules | Brand foundation, tone rules, visual identity, do/don'ts |
| `ux-research` | Research planning, synthesis, personas, journeys, testing | Research plan, participant criteria, scripts, findings |
| `ux-architecture` | UX structure, flows, states, and wireframe logic | Flows, IA, state maps, screen logic |
| `ui-systems` | Tokens, components, theming, responsive rules, implementation handoff | Token system, component rules, handoff checklist |
| `visual-storytelling` | Narrative-driven design, campaigns, storyboards, visual sequencing | Story concept, scene list, sequencing, channel adaptations |
| `inclusive-visuals` | Representation quality, cultural fidelity, accessibility, anti-bias guidance | QA checklist, countermeasures, inclusive direction |
| `image-direction` | Image prompting, shot design, visual prompting frameworks | Master prompt, variants, negative prompts, iteration plan |
| `delight` | Personality, charm, microcopy, playful moments | Delight strategy, microcopy ideas, interaction notes |

## Default Routing Logic

This is the practical shortcut map:

- Brand creation or refresh:
  `design-foundation` + `brand-system`
- Research planning or synthesis:
  `design-foundation` + `ux-research`
- Product flow or UX structure:
  `design-foundation` + `ux-architecture`
- Design system or handoff:
  `design-foundation` + `ui-systems`
- Campaign or narrative concept:
  `design-foundation` + `visual-storytelling`
- Inclusive visual review:
  `design-foundation` + `inclusive-visuals`
- Image prompt work:
  `design-foundation` + `image-direction`
- Personality or delight work:
  `design-foundation` + `delight`

It may add one supporting playbook when needed, but the system is biased toward
small bundles, not mode sprawl.

## Command Sheet

There is no separate slash-command system inside `agent-design`.

The intended interface is plain-language prompting through the public entry
point:

```text
$agent-design <request>
```

### Quick Prompts By Outcome

Use these as copy-ready starters.

#### Brand And Identity

```text
$agent-design create a simple brand system for our product, including positioning, tone, color direction, and clear do/don't rules.
```

```text
$agent-design refresh our current identity without losing trust and clarity. Keep it modern, warm, and implementation-friendly.
```

#### UX Research

```text
$agent-design plan lightweight user research for this onboarding flow and show what questions we need answered before redesigning it.
```

```text
$agent-design turn these findings into a short persona summary, journey map, and design implications.
```

#### UX Architecture

```text
$agent-design turn this feature idea into a UX flow with states, edge cases, and a developer-friendly screen structure.
```

```text
$agent-design help me structure this dashboard so the hierarchy is clearer and the empty, loading, and error states are explicit.
```

#### UI Systems

```text
$agent-design define a UI system for this product with tokens, component rules, theming guidance, and responsive behavior notes.
```

```text
$agent-design prepare a design handoff for developers covering components, states, variants, and accessibility requirements.
```

#### Visual Storytelling

```text
$agent-design turn this product story into a visual narrative with a beginning, middle, end, and channel adaptation ideas.
```

```text
$agent-design create a campaign concept that feels clear, modern, and emotionally strong without becoming generic.
```

#### Inclusive Visuals

```text
$agent-design review this visual direction for inclusion, representation quality, and cultural realism, then give me a QA checklist.
```

```text
$agent-design improve this image brief so it avoids stereotypes, tokenism, clone faces, and vague diversity language.
```

#### Image Direction

```text
$agent-design write a strong image prompt framework for this scene, including subject, setting, lighting, composition, style, and negative constraints.
```

```text
$agent-design refine this visual prompt into a cleaner art direction package with platform variants and iteration guidance.
```

#### Delight And Personality

```text
$agent-design add personality to this product experience through microcopy, loading states, and subtle moments of delight.
```

```text
$agent-design make this flow feel warmer and more memorable without hurting clarity, accessibility, or brand fit.
```

## If You Want To Hint At Internal Playbooks

Normally you should not need this, but it can help when you want tighter
steering.

Examples:

```text
$agent-design use a brand-system lens to define the identity for this developer tool.
```

```text
$agent-design approach this as ux-architecture first, then add only enough ui-systems guidance for implementation handoff.
```

```text
$agent-design use image-direction with inclusive-visuals guardrails for this campaign prompt set.
```

This works because the skill already treats internal playbooks as routing
targets.

## What A Developer Gets From It

The main value of `agent-design` is not just "design ideas." It gives a
developer a better way to structure design work so the result is easier to act
on.

Useful outcomes include:

- faster translation from rough product idea to a usable design artifact
- better prompts for design-heavy conversations with AI
- cleaner handoff material for implementation
- fewer vague design outputs and more system-shaped guidance
- stronger inclusion and accessibility as part of design correctness
- clearer separation between strategy, structure, storytelling, and styling
- less need to remember which specialized playbook exists

## What It Is Good At

- taking fuzzy requests and turning them into the right design lane
- staying narrow instead of loading every design specialty
- producing handoff-friendly outputs
- mixing expression with guardrails
- protecting clarity, inclusion, accessibility, and brand fit

## What It Is Not For

Do not reach for `agent-design` when the real task is:

- editing production frontend code
- debugging implementation bugs
- backend or architecture work with no meaningful design layer
- generic research that is not design-led

For those cases, route to a more appropriate agent.

## Best-Practice Prompting Tips

- Say what artifact you want if you know it:
  `research plan`, `brand system`, `flow`, `handoff`, `prompt set`, `storyboard`
- Mention the audience or surface:
  `landing page`, `admin dashboard`, `onboarding`, `campaign`, `mobile app`
- Mention constraints that matter:
  `must feel on-brand`, `needs accessibility coverage`, `developer handoff needed`
- If context is missing, the skill will often make a reasonable assumption, but
  higher-risk work benefits from a little more framing

## Short Version

If you only want the practical rule:

```text
Use $agent-design when the work is about design thinking or design artifacts.
It will start with design-foundation, choose the smallest useful internal
playbook set, and return something another designer or developer can actually
use.
```
