# Agent Design Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for AGENT DESIGN inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Product and Design department coral or rose accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: AGENT DESIGN
- Subtitle: Design strategy and artifact specialist
- Commands:
  - /agent-design
  - $agent-design
- One-line value:
  Turns design goals into clear, usable outputs without making you choose the internal playbook yourself.
- Capabilities:
  - brand systems
  - UX research
  - UX architecture
  - UI systems and handoff
  - visual storytelling
  - inclusive visuals
  - image direction
  - delight and personality
- How it works:
  - understands the design request
  - starts with design foundation
  - routes to the smallest useful internal playbooks
  - returns one cohesive design artifact
- Best used when:
  - you need design thinking, not implementation
  - you want a developer-friendly design artifact
  - you need structure, clarity, and stronger direction
- Bottom summary:
  design-foundation, brand-system, ux-research, ux-architecture, ui-systems, visual-storytelling, inclusive-visuals, image-direction, delight
- Footer note:
  You ask for the outcome. Agent Design chooses the right internal lane.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
