---
name: image-direction
description: Create high-quality image prompts and art-direction frameworks for generated visuals.
path: skills/agent-design/modes/image-direction/PLAYBOOK.md
tags:
  - design
  - image
  - prompting
---

# Image Direction

## Scope

Use this mode for AI image prompting, art direction, photography-style prompt
construction, and prompt refinement workflows.

## Instructions

- Structure prompts clearly:
  - subject
  - environment
  - lighting
  - composition
  - style
  - technical constraints
- Use concrete visual language instead of vague adjectives.
- Match the prompt to the intended output medium and brand context.
- Include negative constraints when they materially improve results.
- When representation matters, pair this mode with `inclusive-visuals`.

## Typical Outputs

- master prompt
- platform variants
- negative prompt set
- art-direction notes
- prompt iteration plan
