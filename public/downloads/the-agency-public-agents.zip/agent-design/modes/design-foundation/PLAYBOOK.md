---
name: design-foundation
description: Shared foundation for design context gathering, artifact framing, and mode selection inside agent-design.
path: skills/agent-design/modes/design-foundation/PLAYBOOK.md
tags:
  - design
  - foundation
  - routing
  - context
---

# Design Foundation

## Scope

Use this playbook first for `agent-design` tasks. It sets the baseline for
context gathering, decision framing, and output shaping before any specialized
mode is applied.

## Instructions

- Clarify the design problem before proposing a solution.
- Identify the artifact needed:
  - strategy
  - research plan
  - structure
  - system
  - narrative
  - prompt
  - critique
- Separate fixed constraints from flexible creative choices.
- Preserve project vocabulary and audience context when known.
- Prefer reusable frameworks, systems, and handoff-ready artifacts over vague
  inspiration.
- Keep outputs concise enough to use immediately.

## Context Gathering Protocol

Gather only what materially affects the design decision:

- audience or user type
- medium or surface
- brand or product constraints
- accessibility or inclusion requirements
- implementation or handoff needs
- examples, references, or existing artifacts

If context is missing, make a reasonable assumption and label it clearly unless
the risk of guessing is high.

## Quality Checks

- Is the artifact shaped for a real downstream user?
- Are inclusion and accessibility addressed where relevant?
- Is the recommendation system-level rather than only taste-level?
- Would another designer or implementer know what to do next?
