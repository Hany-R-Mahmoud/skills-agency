---
name: ux-research
description: Plan, synthesize, and operationalize UX research for design decisions.
path: skills/agent-design/modes/ux-research/PLAYBOOK.md
tags:
  - design
  - ux
  - research
---

# UX Research

## Scope

Use this mode for research plans, interview or testing strategy, personas,
journey maps, and insight synthesis that inform design work.

## Instructions

- Start with research questions and decision stakes before choosing methods.
- Prefer the lightest method that can answer the real product question.
- Include accessibility and inclusive participant coverage by default.
- Distinguish observed evidence from interpretation and recommendation.
- Translate findings into specific design actions, not just research summaries.

## Typical Outputs

- research plan
- participant criteria
- interview or usability script
- persona or journey-map summary
- findings and design implications
