---
name: brand-system
description: Build or refine brand foundations, identity systems, and consistency rules.
path: skills/agent-design/modes/brand-system/PLAYBOOK.md
tags:
  - design
  - brand
  - identity
---

# Brand System

## Scope

Use this mode for brand strategy, identity systems, voice definition, and
consistency rules that govern how a product or organization presents itself.

## Instructions

- Define purpose, positioning, audience, and differentiators before visual
  decisions.
- Treat voice, color, typography, imagery, and interaction style as one system.
- Balance consistency with enough flexibility for different channels and use
  cases.
- Call out accessibility and cultural fit for brand choices.
- Include guardrails that help teams stay on-brand without freezing the system.

## Typical Outputs

- brand foundation summary
- positioning and messaging pillars
- visual identity direction
- voice and tone rules
- brand do/don't guidance
