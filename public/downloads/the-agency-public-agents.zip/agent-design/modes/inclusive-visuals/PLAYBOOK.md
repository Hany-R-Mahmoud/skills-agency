---
name: inclusive-visuals
description: Improve representation quality, cultural fidelity, and anti-bias constraints in designed or generated visuals.
path: skills/agent-design/modes/inclusive-visuals/PLAYBOOK.md
tags:
  - design
  - inclusion
  - representation
---

# Inclusive Visuals

## Scope

Use this mode when visuals need stronger representation quality, accessibility,
cultural grounding, or anti-bias prompt constraints.

## Instructions

- Treat representation as a design domain, not a cosmetic afterthought.
- Specify identity, environment, and physical context precisely enough to avoid
  stereotypes and generic defaults.
- Call out common model failures such as clone faces, tokenism, fake cultural
  text, and implausible visual physics.
- Prefer dignity, agency, and contextual realism over symbolic shorthand.
- Add review criteria that another person can use to verify the output.

## Typical Outputs

- inclusive art-direction notes
- bias countermeasures
- negative prompt guidance
- visual QA checklist
- cultural or accessibility review notes
