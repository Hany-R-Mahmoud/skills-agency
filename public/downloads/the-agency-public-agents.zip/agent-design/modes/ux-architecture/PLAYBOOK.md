---
name: ux-architecture
description: Turn concepts and requirements into UX structure, flows, and implementation-ready design logic.
path: skills/agent-design/modes/ux-architecture/PLAYBOOK.md
tags:
  - design
  - ux
  - architecture
---

# UX Architecture

## Scope

Use this mode for information architecture, user flows, screen logic, wireframe
structure, content hierarchy, and design-ready implementation guidance.

## Instructions

- Translate goals into clear tasks, states, and decision paths.
- Define structure before styling.
- Make empty, loading, error, and edge states explicit.
- Prefer simple flows with legible hierarchy over clever interaction tricks.
- Keep handoff language concrete enough for implementers and designers to use
  directly.

## Typical Outputs

- flow outline
- information architecture
- wireframe-ready section breakdown
- state map
- implementation guidance for structure and interaction
