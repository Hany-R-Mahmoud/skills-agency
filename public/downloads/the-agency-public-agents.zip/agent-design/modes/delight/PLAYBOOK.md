---
name: delight
description: Add personality, playful moments, and memorable charm without harming clarity or accessibility.
path: skills/agent-design/modes/delight/PLAYBOOK.md
tags:
  - design
  - delight
  - personality
---

# Delight

## Scope

Use this mode for playful interaction concepts, microcopy personality,
celebratory moments, and purposeful whimsy that adds emotional lift.

## Instructions

- Make every delightful element serve a functional or emotional purpose.
- Keep delight subordinate to clarity, usability, and accessibility.
- Match the level of playfulness to the brand and context.
- Prefer subtle, repeatable charm over noisy gimmicks.
- Provide reduced-motion or low-distraction alternatives when relevant.

## Typical Outputs

- personality strategy
- microcopy concepts
- celebratory or loading-state ideas
- micro-interaction notes
- delight do/don't guidance
