---
name: visual-storytelling
description: Create narrative-driven design concepts, campaigns, and visual communication systems.
path: skills/agent-design/modes/visual-storytelling/PLAYBOOK.md
tags:
  - design
  - storytelling
  - narrative
---

# Visual Storytelling

## Scope

Use this mode for campaign concepts, storyboards, narrative arcs, explainer
structures, data stories, and emotionally coherent visual communication.

## Instructions

- Give the story a clear beginning, middle, and end.
- Make the audience, tension, and payoff explicit.
- Use hierarchy and pacing to guide attention deliberately.
- Keep the narrative aligned with brand and audience realities.
- Prefer meaning and clarity over decorative complexity.

## Typical Outputs

- narrative concept
- storyboard or scene list
- visual metaphor direction
- channel adaptation notes
- content sequencing guidance
