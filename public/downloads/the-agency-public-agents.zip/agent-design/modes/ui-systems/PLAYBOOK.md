---
name: ui-systems
description: Define tokens, components, theming, and design handoff systems.
path: skills/agent-design/modes/ui-systems/PLAYBOOK.md
tags:
  - design
  - ui
  - system
---

# UI Systems

## Scope

Use this mode for design tokens, component rules, theming, responsive behavior,
and developer-ready design handoff artifacts.

## Instructions

- Build the system before over-specifying individual screens.
- Prefer reusable tokens, patterns, and component states over bespoke styling.
- Include accessibility requirements as foundation rules, not add-ons.
- Make responsive behavior and theming explicit.
- Optimize for implementation clarity and maintainability.

## Typical Outputs

- token system
- component guidelines
- state and variant rules
- responsive behavior notes
- handoff checklist or implementation spec
