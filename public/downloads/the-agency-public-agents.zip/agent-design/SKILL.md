---
name: agent-design
description: Unified design strategy and artifact creation entry point for this skill pack. Use when Codex should shape brand systems, UX structure, research, visual direction, storytelling, inclusive representation, image prompting, or delight work through one local entry point.
path: .codex/skills/agent-design/SKILL.md
tags:
  - agent
  - design
  - brand
  - ux
  - storytelling
---

# Agent Design

Provide a single public entry point for this repository's non-code design work.
Act as a router plus executor: choose the smallest set of internal design modes
needed, sequence them well, and avoid loading irrelevant guidance.

Do not treat every imported design specialty as a public picker entry. Keep the
public surface thin and move specialized behavior into private modes and
references.

## Invocation Contract

Invoke this skill directly as `$agent-design` whenever the prompt is about:

- brand direction, identity systems, or design-language definition
- UX research plans, personas, journey maps, or validation strategy
- UX structure, information architecture, or design-ready implementation specs
- UI systems, components, tokens, and design handoff artifacts
- visual storytelling, campaign concepts, or narrative-driven design assets
- inclusive representation guidance for generated or designed visuals
- AI image prompting, art direction, or visual prompt refinement
- delight, personality, and playful interaction concepts at the design level

When explicitly invoked, do not ask the user to choose internal modes unless
there is a real strategic tradeoff. Infer the likely path from the prompt, map
it to the minimum useful mode set, and proceed.

The user should not need to know or name the internal modes. Treat them as
private implementation details.

## Use This Skill For

- creating or refining a brand system, identity direction, or design language
- planning or synthesizing UX research and turning findings into design action
- turning requirements into UX architecture, flows, structure, and handoff
- designing UI systems, tokens, components, and implementation-ready guidance
- creating storyboards, visual narratives, campaign concepts, or content arcs
- crafting inclusive visual direction and anti-bias constraints
- writing strong image-generation prompts or prompt frameworks
- adding delight and personality without losing clarity, accessibility, or fit

## Do Not Use This Skill For

- frontend implementation work where the main task is editing production UI code
- generic engineering tasks with no meaningful design, brand, or UX component
- backend-only architecture or debugging work
- broad research tasks that are not primarily design-driven

## Quick Start

If the request sounds like one of these, use the matching route immediately:

- "create or refresh our brand":
  `design-foundation`, then `brand-system`
- "plan or analyze user research":
  `design-foundation`, then `ux-research`
- "turn this concept into UX structure":
  `design-foundation`, then `ux-architecture`
- "define the interface system":
  `design-foundation`, then `ui-systems`
- "tell this story visually":
  `design-foundation`, then `visual-storytelling`
- "make these visuals inclusive and culturally grounded":
  `design-foundation`, then `inclusive-visuals`
- "write prompts for images":
  `design-foundation`, then `image-direction`
- "add delight or personality":
  `design-foundation`, then `delight`

If the request mixes several of these, choose one primary mode and add only the
minimum supporting modes needed to finish the job coherently.

## Core Workflow

1. Inspect the request and classify it:
   - brand and identity
   - research and insight
   - structure and UX architecture
   - UI system and handoff
   - narrative and visual concepting
   - inclusive visual guidance
   - image-prompt direction
   - delight and personality
2. Load `modes/design-foundation/PLAYBOOK.md` first for shared design
   principles and context gathering.
3. Choose the minimum supporting modes from `references/skill-map.md` and
   `references/request-recipes.md`.
4. Execute in a sane order:
   - understand context and constraints
   - define direction
   - create the design artifact
   - pressure-test for inclusion, clarity, and fit
   - prepare handoff guidance when needed
5. Keep the output cohesive. If multiple modes are used, resolve conflicts
   instead of stacking contradictory advice.

## Automatic Routing Rule

When the prompt contains design intent but does not specify a mode:

- infer the dominant design intent from the request
- choose one primary mode
- add only the minimum supporting modes needed
- continue without asking the user to pick from internal skills

Escalate only when the prompt genuinely points to incompatible outcomes, such
as "make it much more playful" and "remove all personality," or "invent a new
brand language" while also "preserving every current brand rule."

## Routing Rules

Default to these bundles:

- Brand creation or refresh:
  `design-foundation` plus `brand-system`; add `visual-storytelling` when the
  request needs campaigns or narrative expression
- Research-first design work:
  `design-foundation` plus `ux-research`; add `ux-architecture` when the next
  step is structure and flows
- Product or flow structure:
  `design-foundation` plus `ux-architecture`; add `ui-systems` when the output
  needs component or token guidance
- Design system or handoff:
  `design-foundation` plus `ui-systems`; add `brand-system` when identity fit
  matters
- Campaign, concept, or presentation-style design:
  `design-foundation` plus `visual-storytelling`; add `brand-system` or
  `image-direction` when needed
- Inclusive visual review:
  `design-foundation` plus `inclusive-visuals`; add `image-direction` for AI
  generation prompts
- Image prompt work:
  `design-foundation` plus `image-direction`; add `inclusive-visuals` or
  `brand-system` when needed
- Delight and personality work:
  `design-foundation` plus `delight`; add `brand-system` when tone consistency
  matters

If a request is narrow, stay narrow. Do not pull in brand, story, research, and
prompting work by default when a single design lane is enough.

Prefer a primary mode and at most 2-4 supporting modes for most tasks.

## Conflict Resolution

Some modes pull in opposite directions. Resolve them deliberately:

- `brand-system` vs `delight`:
  protect the core identity first, then add personality inside the approved
  range
- `ux-research` vs `fast concepting`:
  prefer research when the risk of guessing is meaningful; otherwise label the
  concept as provisional
- `ui-systems` vs `visual-storytelling`:
  use `ui-systems` for durable product patterns and `visual-storytelling` for
  narrative or campaign expression
- `inclusive-visuals` vs loose aesthetic shorthand:
  prefer explicit representation constraints over vague mood language

## Default Execution Standards

Regardless of which modes are selected:

- inspect provided materials and nearby project context before proposing a
  direction
- separate facts, assumptions, and design preferences
- treat accessibility and inclusive representation as part of correctness
- prefer design systems, structures, and reusable patterns over one-off flair
- make handoff artifacts easy for another designer or implementer to use
- use examples when they explain faster than prose

## User Request Translation

Users often describe outcomes, not modes. Translate intent like this:

- "help me define the brand" usually means `brand-system`
- "how should we validate this flow" usually means `ux-research`
- "turn this into wireframes or structure" usually means `ux-architecture`
- "design the system or components" usually means `ui-systems`
- "make this more compelling visually" usually means `visual-storytelling`
- "make sure representation is correct" usually means `inclusive-visuals`
- "write prompts for this look" usually means `image-direction`
- "give it more personality" usually means `delight`

If the prompt mixes several design desires, prioritize in this order unless the
user says otherwise:

1. preserve problem-solution clarity
2. protect inclusion, accessibility, and representation quality
3. preserve brand and system fit
4. improve expressive quality and story
5. add delight and stylistic ambition

## Output Shape

Match the task:

- For strategy or planning work:
  summarize the chosen modes, then present the framework, rationale, and next
  design moves
- For artifact creation:
  provide the artifact directly with concise usage or handoff notes
- For critique work:
  group issues by impact, then provide concrete improvements

Always name the modes you chose when that helps the user understand why the
result was structured a certain way.

## Reference

Use these references as needed:

- `references/skill-map.md`: compact map of all internal modes
- `references/request-recipes.md`: common user phrasing to mode bundles

Read only the relevant entries rather than reloading every internal mode in
full.
