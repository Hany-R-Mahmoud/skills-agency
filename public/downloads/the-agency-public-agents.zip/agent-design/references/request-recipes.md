# Request Recipes

Use this file when the user describes a design outcome instead of naming a
specific internal mode.

## Brand And Identity

- "create our brand system":
  start with `design-foundation`; add `brand-system`
- "refresh our identity":
  start with `design-foundation`; add `brand-system`; sometimes add
  `visual-storytelling`
- "make sure this feels on-brand":
  start with `design-foundation`; add `brand-system`

## Research And UX

- "plan research for this":
  start with `design-foundation`; add `ux-research`
- "turn findings into personas or journeys":
  start with `design-foundation`; add `ux-research`
- "structure this flow":
  start with `design-foundation`; add `ux-architecture`
- "give developers a UX foundation":
  start with `design-foundation`; add `ux-architecture`; often add
  `ui-systems`

## UI Systems

- "design the components or tokens":
  start with `design-foundation`; add `ui-systems`
- "prepare handoff specs":
  start with `design-foundation`; add `ui-systems`
- "define theming and visual rules":
  start with `design-foundation`; add `ui-systems`; sometimes add
  `brand-system`

## Narrative And Visuals

- "tell this story visually":
  start with `design-foundation`; add `visual-storytelling`
- "make this campaign more compelling":
  start with `design-foundation`; add `visual-storytelling`
- "write prompts for visuals":
  start with `design-foundation`; add `image-direction`
- "make these visuals inclusive":
  start with `design-foundation`; add `inclusive-visuals`
- "give this more personality":
  start with `design-foundation`; add `delight`

## Guardrail

Do not map vague prompts to every design mode. Pick the most likely primary
mode, then add only the supporting modes needed to finish the job well.
