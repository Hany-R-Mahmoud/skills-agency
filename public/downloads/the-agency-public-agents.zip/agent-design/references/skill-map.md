# Skill Map

Use this file to route a request to the minimum useful subset of the internal
design modes bundled inside `agent-design`.

## Foundation

- `design-foundation`: shared context gathering, design constraints,
  artifact-shaping rules, and handoff expectations

Always start with `design-foundation`.

## Design Modes

- `brand-system`: brand foundation, identity systems, voice, and consistency
- `ux-research`: research plans, personas, journeys, testing, and insight
  synthesis
- `ux-architecture`: information architecture, flows, wireframe logic, and
  design-ready structure
- `ui-systems`: design tokens, component systems, theming, and implementation
  handoff
- `visual-storytelling`: storyboards, narrative systems, campaign concepts, and
  information storytelling
- `inclusive-visuals`: anti-bias representation constraints, cultural fidelity,
  accessibility, and review checklists for visuals
- `image-direction`: image-prompt engineering, art direction, shot structure,
  and prompt refinement
- `delight`: playful details, personality, microcopy concepts, and purposeful
  moments of charm

## Recommended Bundles

- Build a brand system:
  `design-foundation`, then `brand-system`
- Plan or synthesize research:
  `design-foundation`, then `ux-research`
- Turn a concept into structure:
  `design-foundation`, then `ux-architecture`, optionally `ui-systems`
- Create a design system or handoff:
  `design-foundation`, then `ui-systems`, optionally `brand-system`
- Create a campaign or narrative concept:
  `design-foundation`, then `visual-storytelling`, optionally
  `image-direction`
- Improve representation quality:
  `design-foundation`, then `inclusive-visuals`, often with
  `image-direction`
- Write image prompts:
  `design-foundation`, then `image-direction`, optionally
  `inclusive-visuals`
- Add delight:
  `design-foundation`, then `delight`, optionally `brand-system`

## Anti-Pattern

Do not activate every design mode just because a request touches "design."
Choose the smallest useful bundle that can produce a coherent result.
