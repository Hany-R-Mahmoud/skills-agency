# Full public agent pack

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-architect`
- `agent-co-pilot`
- `agent-composer`
- `agent-data-ai`
- `agent-debugging`
- `agent-diagrams`
- `agent-docs`
- `agent-history`
- `agent-impeccable`
- `agent-implementer`
- `agent-ops`
- `agent-orchestrator`
- `agent-performance`
- `agent-pilot`
- `agent-researcher`
- `agent-reviewer`
- `agent-security`
- `agent-stitch`
- `agent-tester`
- `backend-and-language-engineering`
- `coordination-playbook`
- `debugging-and-diagnostics`
- `document-files`
- `documentation-and-doc-ops`
- `frontend-react-and-next`
- `fullstack-engineering`
- `interface-and-design`
- `mcp-development`
- `openai-docs`
- `platform-engineering`
- `research-and-reasoning`
- `review-and-pr-operations`
- `security-engineering`
- `systems-architecture`
- `testing-and-verification`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
