# Full public agent pack

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-architect`
- `agent-co-pilot`
- `agent-composer`
- `agent-data-ai`
- `agent-debugging`
- `agent-diagrams`
- `agent-docs`
- `agent-history`
- `agent-impeccable`
- `agent-implementer`
- `agent-ops`
- `agent-orchestrator`
- `agent-performance`
- `agent-pilot`
- `agent-researcher`
- `agent-reviewer`
- `agent-security`
- `agent-stitch`
- `agent-tester`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
