# Impeccable Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for IMPECCABLE inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Product and Design department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: IMPECCABLE
- Subtitle: Frontend UI and design specialist for polish, redesign, and UX quality
- Commands:
  - /agent-impeccable
  - $agent-impeccable
- One-line value:
  The unified frontend design facade. Routes design, layout, typography, accessibility, polish, critique, and production hardening through one public entry point.
- Capabilities:
  - UI redesign
  - design-system fit
  - frontend polish
  - accessibility-aware refinement
- How it works:
  - reads the UI problem
  - chooses the smallest useful design lanes
  - sharpens structure, readability, and feel
  - returns one cohesive refinement path
- Best used when:
  - you are redesigning or refining a page, flow, or product surface
  - the UI needs stronger taste, clarity, responsiveness, or production polish
  - you want one public design agent instead of choosing among many internal modes
- Bottom summary:
  frontend-design, arrange, typeset, colorize, polish
- Footer note:
  You ask for the outcome. Impeccable lifts the finish.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
