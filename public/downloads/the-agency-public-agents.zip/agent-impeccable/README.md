# Impeccable Guide

`agent-impeccable` is the public frontend UI and design specialist for polish,
redesign, and UX quality.

## What It Does

It routes redesign, layout, typography, accessibility, critique, and polish
through one public entry point so the UI can improve without mode hunting.

It is best at:

- UI redesign
- design-system fit
- frontend polish
- accessibility-aware refinement

## How To Use It

Call it with:

- `/agent-impeccable`
- `$agent-impeccable`

Use it when:

- you are redesigning or refining a page, flow, or product surface
- the UI needs stronger taste, clarity, responsiveness, or production polish
- you want one public design agent instead of choosing among many internal
  modes

## How It Works

It reads the UI problem, chooses the smallest useful design lanes, and returns
one cohesive refinement path instead of scattered taste advice.

## Internal Playbooks

- `Frontend Design` (`frontend-design`): provides the shared design foundation
  before narrower UI modes are chosen
- `Arrange` (`arrange`): improves layout structure, spacing, and screen
  composition
- `Typeset` (`typeset`): strengthens typography hierarchy, rhythm, and
  readability
- `Colorize` (`colorize`): tunes palette decisions and visual contrast while
  preserving system fit
- `Polish` (`polish`): adds production-level refinement once the core structure
  is already sound

## Short Version

Use `/agent-impeccable` or `$agent-impeccable` when the interface needs to look
and feel better, not just function.
