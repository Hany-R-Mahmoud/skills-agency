---
name: media-ideation
description: Generate or shape supporting visual concepts and media ideas that reinforce a UI direction without replacing actual interface design work.
---

Use this mode when visual ideation or generated support assets help clarify the
product direction.

## Workflow

1. Confirm the media job:
   - concept exploration
   - supporting imagery for an existing UI direction
   - illustration, photography, motion, or storyboard ideation
2. Anchor the work to the product:
   - audience
   - brand tone
   - target surface
   - what the asset needs to support
3. Choose the lightest useful output:
   - concept directions
   - prompt architecture
   - negative constraints
   - review checklist
4. Add a review gate before treating the asset as usable:
   - brand fit
   - representation quality
   - technical plausibility
   - usefulness to the interface

## Prompt Structure

When generated imagery or video is part of the ideation, structure prompts in a
stable order:

- subject and action
- setting and contextual specificity
- lighting, color, and mood
- camera, framing, or motion behavior
- style references or medium
- explicit exclusions or negative constraints

Prefer concrete constraints over vague adjectives. "Warm late-afternoon side
light with visible material texture" is stronger than "beautiful cinematic
lighting."

## Inclusive Representation Guardrails

When people or culturally specific settings appear in generated media:

- avoid generic "diverse team" shorthand; specify the actual human scene
- favor dignified, lived-in context over stock-photo symbolism
- block common artifact patterns explicitly:
  - clone faces
  - gibberish signage or fake cultural text
  - distorted hands, mobility aids, or accessories
  - geographically inaccurate architecture or styling
- treat identity as context that needs specificity, not decorative metadata

For motion concepts, define stable physical behavior when it matters:

- fabric and hair movement
- mobility aid consistency
- lighting continuity
- crowd or background variation

## Output Shapes

Prefer one of these compact outputs:

- `Concept directions`: 2-3 options with tone, visual language, and product fit
- `Prompt architecture`: a reusable prompt broken into sections
- `Constraint pack`: negative prompts and no-go patterns
- `Review gate`: a short checklist for deciding whether the asset is usable

## Review Gate

Before endorsing a generated asset, check:

1. Does it reinforce the chosen interface direction rather than compensate for
   weak product design?
2. Does it fit the brand's tone and level of ambition?
3. If people are shown, do they feel specific, respectful, and non-tokenized?
4. Are there visible generation artifacts or implausible details?
5. Would this still be useful if translated into code, layout, or product copy?

## Guardrails

- the interface still carries the product, not the supporting media
- generated visuals should reinforce the chosen design system
- do not use media ideation as a shortcut around weak layout or UX decisions
- do not introduce vendor-specific prompt syntax unless the user needs a
  platform-targeted output
- do not confuse image taste with product correctness; generated media is a
  supporting artifact, not proof that the design works
