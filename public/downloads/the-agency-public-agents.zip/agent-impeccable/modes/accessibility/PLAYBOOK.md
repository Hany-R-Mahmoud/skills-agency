---
name: accessibility
description: Improve accessibility, WCAG alignment, semantic structure, keyboard usability, and assistive-technology compatibility without sacrificing the product's visual language.
---

## MANDATORY PREPARATION

Use the frontend-design skill first and follow the Context Gathering Protocol.
Additionally gather: supported platforms, accessibility expectations, and any
known compliance bar.

---

Use this mode when inclusive interaction quality is a first-order concern.

## Focus Areas

- semantic HTML before ARIA patching
- keyboard reachability and logical focus order
- visible focus treatment
- screen reader naming and announcements
- color contrast and non-color affordances
- reduced motion and zoom resilience

## Verification Flow

When the task includes auditing or validating accessibility, use this order:

1. automated baseline scan
2. keyboard-only navigation pass
3. screen-reader spot check on the highest-risk flows
4. component-level review for custom interactive patterns

## Manual Checkpoints

- keyboard traversal across global navigation, dialogs, forms, and custom widgets
- screen-reader naming for controls, landmarks, headings, and dynamic changes
- component-specific checks for menus, tabs, carousels, tables, and other
  custom interaction patterns
- remediation priority split:
  - immediate: critical or serious blockers
  - short-term: meaningful usability friction
  - ongoing: lower-risk polish and system cleanup

## Guardrails

- do not fix accessibility by degrading the core product experience
- do not add ARIA where native semantics already solve the problem
- do not treat accessibility as a postscript after major UX decisions
- do not rely on automated scanners alone when custom interactions or dynamic
  content are involved
