# Historian Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for HISTORIAN inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Research and Continuity department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: HISTORIAN
- Subtitle: Continuity and handoff specialist across chats, sessions, and tools
- Commands:
  - /agent-history
  - $agent-history
- One-line value:
  Exports a conversation, workstream, or project state into a structured briefing for a new chat, session, or AI tool without losing the decisions that matter.
- Capabilities:
  - context export
  - handoff briefings
  - decision continuity
  - resume prompts
- How it works:
  - reads the workstream
  - chooses the smallest useful continuity lanes
  - preserves the decisions and paths that matter
  - returns a clean handoff packet
- Best used when:
  - you need to continue work in another chat, tool, or future session
  - a long conversation needs to be compressed into a clean continuity pack
  - you want decisions, commands, paths, and blockers preserved without the chatter
- Bottom summary:
  briefing-template, context-manager, learned-patterns
- Footer note:
  You ask for the outcome. Historian preserves the thread.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
