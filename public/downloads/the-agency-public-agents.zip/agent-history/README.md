# Historian Guide

`agent-history` is the continuity and handoff specialist across chats,
sessions, and tools.

## What It Does

It exports a conversation, workstream, or project state into a structured
briefing so work can continue elsewhere without losing the decisions that
matter.

It is best at:

- context export
- handoff briefings
- decision continuity
- resume prompts

## How To Use It

Call it with:

- `/agent-history`
- `$agent-history`

Use it when:

- you need to continue work in another chat, tool, or future session
- a long conversation needs to be compressed into a clean continuity pack
- you want decisions, commands, paths, and blockers preserved without the
  chatter

## How It Works

It reads the workstream, chooses the smallest useful continuity lanes, and
returns a handoff packet that another AI or teammate can pick up fast.

## Internal Playbooks

- `Briefing Template` (`briefing-template`): structures the continuity pack so
  another AI can resume without guessing
- `Context Manager` (`context-manager`): preserves critical state, user
  preferences, and durable identifiers
- `Learned Patterns` (`learned-patterns`): captures durable lessons worth
  reusing across future runs

## Short Version

Use `/agent-history` or `$agent-history` when the work needs to move but the
context cannot be lost.
