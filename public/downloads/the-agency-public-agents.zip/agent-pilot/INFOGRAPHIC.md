# Pilot Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for PILOT inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Command Center department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: PILOT
- Subtitle: Primary lead for coordinated feature work and gated execution
- Commands:
  - /agent-pilot
  - $agent-pilot
- One-line value:
  The default lead workflow for most meaningful delivery. Expands from a lean implementation pass to a gated multi-specialist sequence when the risk, ambiguity, or blast radius calls for it.
- Capabilities:
  - multi-agent coordination
  - workflow intensity selection
  - quality gate management
  - delivery routing
- How it works:
  - reads the request
  - selects the right delivery intensity
  - routes through the smallest useful specialist sequence
  - returns one coordinated path to done
- Best used when:
  - the work spans multiple files or disciplines and needs active coordination
  - implementation, review, and testing all matter before closure
  - you want one lead agent that can scale up without changing the public entry point
- Bottom summary:
  shared-team-contract, coordination-playbook, quality-gates, fullstack-engineering, platform-engineering
- Footer note:
  You ask for the outcome. Pilot scales the workflow to match the risk.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
