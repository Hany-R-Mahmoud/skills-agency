# Shared Team Contract

Use this contract across `agent-co-pilot` and `agent-pilot`
when work is delegated or staged.

## Goal

Keep multi-agent work predictable by standardizing:
- file ownership
- minimal artifacts
- specialist return format
- closeout synthesis
- context retrieval discipline
- milestone summaries

## Ownership Rules

- Give each writing specialist a distinct file scope whenever possible.
- If two specialists must touch the same file, sequence them instead of running
  them in parallel.
- Prefer read-only specialists for review, testing strategy, research, docs
  planning, and architecture framing.
- State file scope explicitly whenever implementation is delegated.

## Iterative Retrieval Rules

- Do not preload large file sets into a worker unless they are clearly needed.
- Start each delegated task with the minimum context required to act.
- Let the worker retrieve more context in small steps:
  - inspect initial files
  - identify the next missing file or signal
  - retrieve only that next slice
  - stop when confidence is sufficient
- Prefer at most 2-3 retrieval rounds before either:
  - acting with the gathered evidence
  - escalating that the task is under-specified

This keeps delegated work focused and reduces token waste from speculative
context loading.

## Minimal Artifact Set

Create only the artifacts that materially help the task.

- `plan`
  - goal
  - constraints
  - selected path
  - main risks
- `tasks`
  - task id
  - owner
  - file scope
  - dependency
  - status
- `review`
  - findings
  - severity
  - open questions
- `verification`
  - checks run
  - outcomes
  - gaps
  - residual risk
- `status`
  - executive summary
  - progress
  - issues and risks
  - stakeholder actions
  - next decision or checkpoint

For lite tasks, a short in-memory summary may replace written artifacts.

## Milestone Summaries

At meaningful boundaries, the lead should produce a brief milestone summary
instead of dragging the entire prior thread forward.

Good boundaries include:
- after exploration
- after proposal or task breakdown
- after implementation
- after review or verification

Each milestone summary should include:
- current understanding
- decisions made
- active file scope
- remaining risks
- next step

Use milestone summaries as the Codex equivalent of strategic compaction.

For longer changes, prefer a checkpoint cadence over one final verification
burst:
- plan or explore
- implement
- checkpoint
- verify
- checkpoint again before the next risky phase

Checkpoints should capture only what the next phase needs:
- current verification status
- notable changes since the last checkpoint
- blocking issues
- the next intended move

When automation or workflow hooks are part of the plan, record whether each one
is:
- a blocking preflight check
- a non-blocking follow-up action
- intentionally skipped for this run

That keeps staged work legible and avoids accidental dependence on a hook that
was only meant as a convenience.

## Specialist Return Format

Every delegated specialist should return:
- `summary`
- `status`
- `files_touched` or `file_scope`
- `risks`
- `next_step`

Recommended status values:
- `completed`
- `blocked`
- `needs_review`
- `needs_verification`
- `needs_decision`

## Synthesis Rules

The lead should close the loop with:
- what path was chosen
- which specialists or domain skills were used
- what was verified
- what remains risky or unresolved
- what stakeholders or collaborators need to do next, if anyone

Do not mark a task complete based only on confident prose. Prefer evidence,
checks, and concrete file outcomes.

## Learned Patterns

When the same preference, correction, or routing rule repeats across tasks,
promote it into a durable reference instead of relying on session memory.

Use
[`learned-patterns.md`](/Users/hanyramadan/.codex/skills/agent-pilot/references/learned-patterns.md)
for stable patterns that should survive across future work.
