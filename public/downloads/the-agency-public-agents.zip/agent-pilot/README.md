# Pilot Guide

`agent-pilot` is the primary lead workflow for coordinated feature work and
gated execution.

## What It Does

It is the default team lead for meaningful delivery and can scale from a lean
implementation pass to a multi-specialist sequence when the risk demands it.

It is best at:

- multi-agent coordination
- workflow intensity selection
- quality gate management
- delivery routing

## How To Use It

Call it with:

- `/agent-pilot`
- `$agent-pilot`

Use it when:

- the work spans multiple files or disciplines and needs active coordination
- implementation, review, and testing all matter before the task is done
- you want one lead agent that can scale up without changing the public entry
  point

## How It Works

It reads the request, decides the right execution intensity, pulls the smallest
useful specialist sequence, and keeps the delivery path cohesive.

## Internal Playbooks

- `Shared Team Contract` (`shared-team-contract`): defines ownership, artifact
  shape, and synthesis rules for coordinated delivery
- `Coordination Playbook` (`coordination-playbook`): routes the right
  specialist sequence without exposing that complexity to the user
- `Quality Gate Patterns` (`quality-gates`): makes review, verification,
  security, and docs checks explicit instead of implied
- `Fullstack Engineering` (`fullstack-engineering`): keeps cross-layer
  implementation grounded when the feature reaches beyond one surface
- `Platform Engineering` (`platform-engineering`): handles infra or
  deployment-sensitive turns without leaving the lead workflow

## Short Version

Use `/agent-pilot` or `$agent-pilot` when the task needs one lead who can
coordinate implementation, review, and validation without changing tools.
