# Composer Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for COMPOSER inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Product and Design department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: COMPOSER
- Subtitle: Skill and browser-agent composition specialist
- Commands:
  - /agent-composer
  - $agent-composer
- One-line value:
  The builder for new skills, browser-capable agents, Playwright-aware workflows, and local packaging patterns. Keeps public surfaces thin while the internal system grows deeper.
- Capabilities:
  - skill composition
  - browser-agent design
  - Playwright workflows
  - packaging strategy
- How it works:
  - reads the packaging problem
  - chooses the smallest useful composition lanes
  - keeps the public surface thin
  - returns one coherent entry point with deeper internal structure
- Best used when:
  - you are creating or refining a skill, agent, or automation workflow
  - a browser-capable or Playwright-style execution model needs to be designed cleanly
  - you want to package imported ideas without bloating the public picker surface
- Bottom summary:
  composition-standards, skill-architecture, browser-automation, playwright-execution, packaging
- Footer note:
  You ask for the outcome. Composer packages it cleanly.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
