# Composer Guide

`agent-composer` is the public entry point for composing new skills,
browser-capable agents, and packaging patterns.

## What It Does

It helps turn imported ideas into clean public surfaces while keeping the
internal system deeper than the picker.

It is best at:

- skill composition
- browser-agent design
- Playwright workflows
- packaging strategy

## How To Use It

Call it with:

- `/agent-composer`
- `$agent-composer`

Use it when:

- you are creating or refining a skill, agent, or automation workflow
- a browser-capable or Playwright-style execution model needs to be designed
  cleanly
- you want to package imported ideas without bloating the public picker surface

## How It Works

It reads the packaging problem, chooses the smallest useful composition lanes,
and returns one coherent public entry point with the right internal depth
behind it.

## Internal Playbooks

- `Composition Standards` (`composition-standards`): applies the local house
  style so new agents feel native instead of imported
- `Skill Architecture` (`skill-architecture`): shapes one coherent public entry
  point with the right internal lanes behind it
- `Browser Automation` (`browser-automation`): designs stateful browser
  workflows with explicit navigation, waits, and capture
- `Playwright Execution` (`playwright-execution`): adds Playwright-capable
  interaction patterns when browser precision matters
- `Packaging` (`packaging`): prepares metadata, manifests, references, and the
  reusable shape of the finished agent

## Short Version

Use `/agent-composer` or `$agent-composer` when the real job is packaging a
capability cleanly, not just describing it.
