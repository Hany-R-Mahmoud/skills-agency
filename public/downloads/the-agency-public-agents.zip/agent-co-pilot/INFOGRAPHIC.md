# Co-Pilot Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for CO-PILOT inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Command Center department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: CO-PILOT
- Subtitle: Lean coordinator for small, obvious, low-risk tasks
- Commands:
  - /agent-co-pilot
  - $agent-co-pilot
- One-line value:
  The lightest team lead on the floor. Keeps orchestration overhead low, delegates only when it clearly helps, and is built for quick wins that still deserve a little structure.
- Capabilities:
  - lightweight routing
  - small-task coordination
  - fast handoff discipline
  - minimal verification
- How it works:
  - reads the request
  - keeps context tight
  - routes through the smallest useful internal playbooks
  - returns a lean execution path
- Best used when:
  - the task is small, isolated, and already easy to understand
  - you want one focused implementer and maybe a quick validation pass
  - a full gated workflow would create more ceremony than value
- Bottom summary:
  coordination-playbook, context-efficiency, frontend-react-and-next, testing-and-verification
- Footer note:
  You ask for the outcome. Co-Pilot keeps the route light.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
