# Co-Pilot Guide

`agent-co-pilot` is the lightweight coordination entry point for small, obvious,
low-risk tasks.

## What It Does

It keeps orchestration overhead low and helps move simple work forward without
turning it into a full multi-agent ceremony.

It is best at:

- lightweight routing
- small-task coordination
- fast handoff discipline
- minimal verification

## How To Use It

Call it with:

- `/agent-co-pilot`
- `$agent-co-pilot`

Use it when:

- the task is small, isolated, and already easy to understand
- you want one focused implementer and maybe a quick validation pass
- a full gated workflow would create more ceremony than value

## How It Works

It reads the request, keeps the context small, pulls only the internal
playbooks that matter, and returns a lean execution path.

## Internal Playbooks

- `Coordination Playbook` (`coordination-playbook`): keeps small-task routing
  tight so delegation stays helpful instead of heavy
- `Context Efficiency` (`context-efficiency`): trims the working set down to
  only what is needed for a fast move
- `Frontend React and Next` (`frontend-react-and-next`): supports common UI and
  app-level changes without a larger coordination stack
- `Testing and Verification` (`testing-and-verification`): adds only the
  lightest useful validation before the task closes

## Short Version

Use `/agent-co-pilot` or `$agent-co-pilot` when the task is straightforward and
you want just enough structure to stay clean.
