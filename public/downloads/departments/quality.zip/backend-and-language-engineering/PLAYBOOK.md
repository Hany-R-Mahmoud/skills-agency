---
name: backend-and-language-engineering
description: Implement backend or general application code in TypeScript, JavaScript, Python, NestJS, and CLI environments. Use for language-specific patterns, typed APIs, CLI tools, and server-side implementation.
path: skills/backend-and-language-engineering/PLAYBOOK.md
tags:
  - typescript
  - javascript
  - python
  - nestjs
  - cli
---

# Backend And Language Engineering

## Scope
Use this skill for language-specific implementation in JS, TS, Python, NestJS,
and CLI tooling.

## Instructions
- Identify the runtime and framework first, then apply the language-specific
  rules instead of mixing patterns across ecosystems.
- Prefer strict typing, clear interfaces, and explicit error handling.
- Keep CLI behavior predictable with good argument parsing, exit semantics, and
  user-facing messages.
- For backend work, define contracts and validation before wiring business
  logic.

## Sub-skill: Language and framework selection
- Use TypeScript for typed application code, Python for Python-native systems,
  NestJS for modular backend delivery, and CLI patterns when the product is a
  command-line interface.

## Notes
- Use `systems-architecture` when the work is still at design/spec level.
- Use `fullstack-engineering` when the task spans backend plus UI or data
  layers.
