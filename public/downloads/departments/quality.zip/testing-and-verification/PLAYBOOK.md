---
name: testing-and-verification
description: Plan, write, run, and validate tests across unit, integration, E2E, and release-readiness workflows. Use for TDD, quality gates, browser testing, and completion verification.
path: skills/testing-and-verification/PLAYBOOK.md
tags:
  - testing
  - tdd
  - playwright
  - verification
  - qa
---

# Testing And Verification

## Scope
Use this skill for test strategy, test authoring, test execution, browser
automation, and verification before claiming completion.

## Instructions
- Decide the testing mode first: unit, integration, E2E, browser verification,
  regression guard, or release-readiness check.
- Cover both happy paths and failure paths.
- Prefer behavior-oriented tests over implementation-detail tests.
- Mock external dependencies when needed, but keep contract coverage for the
  real boundary.
- Do not claim a fix is complete until verification evidence exists.

## Sub-skill: Test design
- Use TDD when implementing bug fixes or features where the failure can be
  captured first.
- Document coverage gaps and residual risks when full verification is not
  practical.

## Sub-skill: Browser and E2E validation
- Use browser automation for UI verification where rendered behavior matters.
- Capture logs, runtime errors, and screenshots when that evidence changes the
  conclusion.

## Notes
- Pair with `debugging-and-diagnostics` when failures are not yet understood.
- Pair with `frontend-react-and-next` or `fullstack-engineering` when the task
  includes implementation.
