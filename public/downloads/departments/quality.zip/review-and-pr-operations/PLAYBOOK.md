---
name: review-and-pr-operations
description: Run code review and PR workflows end to end, from checklist-based review to comment handling and PR summaries. Use for local or PR reviews, reviewer feedback triage, and automated review orchestration.
path: skills/review-and-pr-operations/PLAYBOOK.md
tags:
  - code-review
  - pr
  - coderabbit
  - review-comments
  - summary
---

# Review And PR Operations

## Scope
Use this skill for code review, PR review operations, reviewer feedback triage,
PR summaries, and multi-agent review workflows.

## Instructions
- Lead with findings, not recap. Prioritize correctness, regressions, risks,
  and missing validation.
- Classify the review mode first: local diff review, branch review, remote PR
  review, reviewer-comment response, or PR summary generation.
- Use focused checklists for the affected area: general code quality,
  architecture, frontend concerns, or security-sensitive changes.
- When review feedback is unclear or questionable, validate it technically
  before applying it.
- Keep review outputs actionable with path, impact, and concrete fix guidance.

## Sub-skill: PR review orchestration
- Support fast local review, CodeRabbit-assisted review, and multi-agent review
  workflows.
- De-duplicate findings across review sources before reporting.

## Sub-skill: Comment handling and summaries
- Address review comments with evidence, not performative agreement.
- Generate concise PR summaries only after the change set is understood.

## Notes
- This skill governs review and PR operations, not test implementation.
- Pair with `testing-and-verification` when new findings require validation.
