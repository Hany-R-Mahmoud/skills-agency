---
name: interface-and-design
description: Design and critique user interfaces, design systems, and visual theming for web products. Use for UX direction, UI review, brand guidance, and reusable theme decisions.
path: skills/interface-and-design/PLAYBOOK.md
tags:
  - ux
  - ui
  - design
  - theme
  - brand
---

# Interface And Design

## Scope
Use this skill for UI and UX critique, brand-aware design direction, web
interface checklists, and reusable theme decisions.

## Instructions
- Start with the purpose, audience, and product context before making visual
  recommendations.
- Push toward deliberate, differentiated design choices instead of generic UI
  defaults.
- Keep accessibility, readability, and interaction quality as non-negotiable.
- When reviewing UI, ground feedback in concrete issues: semantics, focus,
  contrast, hierarchy, motion, forms, and navigation.

## Sub-skill: Design direction
- Choose a clear visual direction and make typography, color, spacing, and
  motion serve that direction.
- Keep brand guidance and reusable theme decisions explicit.

## Sub-skill: Interface review
- Review with a checklist mindset for accessibility, UX quality, and
  implementation-fit.

## Notes
- Use `visual-artifacts` for posters, branded visuals, or motion artifacts that
  are not product UI.
- Use `frontend-react-and-next` when the main task is implementation.
