---
name: debugging-and-diagnostics
description: Investigate bugs, regressions, telemetry failures, and runtime issues with hypothesis-driven debugging. Use for root-cause analysis, leak audits, runtime bundle issues, and targeted fixes.
path: skills/debugging-and-diagnostics/PLAYBOOK.md
tags:
  - debugging
  - diagnostics
  - runtime
  - telemetry
  - leaks
---

# Debugging And Diagnostics

## Scope
Use this skill for bug investigation, regression analysis, runtime diagnostics,
error telemetry work, and memory or lifecycle leak audits.

## Instructions
- Reproduce first. If the issue is not reproducible, focus on narrowing the
  conditions and collecting evidence.
- Gather complete error text, stack traces, logs, environment details, and
  reproduction steps before changing code.
- Test one hypothesis at a time and keep the evidence for or against it.
- When runtime-bundle or tracing issues are involved, inspect the actual build
  artifacts and route traces instead of guessing from symptoms.

## Sub-skill: Runtime and telemetry issues
- Mirror CI or production-adjacent environment variables when reproducing CI
  failures.
- For runtime-bundle regressions, inspect trace files and emitted chunks rather
  than relying on source assumptions.

## Sub-skill: Leak audits
- Audit listeners, disposables, timers, subscriptions, and cleanup paths.
- Add regression safeguards after fixing the root cause.

## Notes
- Remove temporary debug code before finalizing.
- Pair with `testing-and-verification` once the likely fix is identified.
