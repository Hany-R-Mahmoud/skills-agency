---
name: systems-architecture
description: Design or modernize application, API, database, and service architecture. Use for system boundaries, data models, migration strategy, specifications, and platform-level design decisions.
path: skills/systems-architecture/PLAYBOOK.md
tags:
  - architecture
  - api
  - database
  - specs
  - migration
---

# Systems Architecture

## Scope
Use this skill for application architecture, API and schema design, feature
specification, modernization strategy, and service boundary decisions.

## Instructions
- Start by clarifying the problem shape: greenfield design, refactor,
  migration, spec extraction, or architecture review.
- Identify the main boundaries: clients, services, data stores, integrations,
  ownership, and failure domains.
- Define public interfaces explicitly: APIs, events, contracts, schemas, and
  persistence models.
- Prefer designs that improve change isolation, observability, and testability.
- Record migration constraints, compatibility requirements, and rollback shape
  for any structural change.

## Sub-skill: API and contract design
- Model resources, operations, pagination, errors, and versioning choices.
- Choose REST, GraphQL, RPC, or event-driven patterns based on caller needs and
  operational constraints.

## Sub-skill: Data and service design
- Define data ownership and consistency boundaries before picking storage.
- Use explicit service boundaries for microservice work; avoid accidental
  distributed systems.

## Sub-skill: Specs and modernization
- Extract current behavior before rewriting undocumented systems.
- For migration work, define the target state, intermediate states, and the
  safest cutover path.

## Notes
- Pair with `platform-engineering` for cloud or deployment design.
- Pair with `fullstack-engineering` when the task includes implementation.
