---
name: security-engineering
description: Review or implement application and infrastructure security controls. Use for auth, input validation, AppSec reviews, and security audit findings.
path: skills/security-engineering/PLAYBOOK.md
tags:
  - security
  - auth
  - appsec
  - audit
  - validation
---

# Security Engineering

## Scope
Use this skill for secure implementation, code or infrastructure security
review, and evidence-based security audits.

## Instructions
- Classify the work first: preventive implementation, focused review, or broad
  audit.
- Prioritize auth, authorization, input validation, secret handling, data
  exposure, and infrastructure attack surface.
- Treat findings as evidence-based claims. Include impact and remediation, not
  just labels.
- Prefer least privilege, defense in depth, and explicit validation at trust
  boundaries.

## Sub-skill: Secure implementation
- Protect auth paths, user input, crypto usage, and sensitive data storage.
- Do not hardcode secrets or trust client-side validation alone.

## Sub-skill: Review and audit
- Check code paths, dependencies, configuration, and runtime exposure.
- Group findings by severity and remediation urgency.

## Notes
- Pair with `platform-engineering` for infra-heavy reviews.
- Pair with `review-and-pr-operations` for PR-focused reporting.
