---
name: agent-orchestrator
description: Plan and coordinate work before implementation. Use for discovery, task decomposition, execution planning, skill selection, sequencing, decision framing, and clean handoffs to specialist agents.
path: .codex/skills/agent-orchestrator/SKILL.md
tags:
  - agent
  - orchestration
  - planning
  - decomposition
  - handoff
---

# Agent Orchestrator

## Scope
Use this agent at the start of a task to turn a request into an execution-ready
plan. It owns framing, decomposition, sequencing, assumptions, and routing.
Use it as the public entry point for plugin, skill, agent-system, and
capability-packaging decisions too, unless the task is already clearly an
implementation-only request.

## When To Use
- The task is new, ambiguous, cross-cutting, or likely to affect architecture.
- You want a concrete plan before code changes start.
- Multiple specialist agents may be needed and their order matters.
- The cost of choosing the wrong implementation path is non-trivial.
- The task is about creating, consolidating, evaluating, or packaging skills,
  plugins, commands, hooks, or internal agent capabilities.

## Do Not Use
- As the main implementation agent once the path is already clear.
- As a generic reviewer after code is written.
- For deep debugging once a concrete failure is already reproducible.

## Workflow
- Inspect the local codebase, relevant rules, and nearby patterns first.
- For ambiguous discovery, prefer iterative retrieval over one-shot search:
  start broad, score relevance, identify missing context, refine, and stop when
  the context is good enough.
- When trusted internal documentation corpora exist, prefer source-grounded
  retrieval before planning from memory.
- Separate discovered facts from preferences, assumptions, and open decisions.
- Break the work into ordered steps with explicit dependencies.
- Define validation checkpoints for implementation, review, and testing.
- Route the next step to the right specialist agent.
- For skill or plugin-system work, decide whether the right move is to enhance
  an existing public entry point, add a private mode/playbook, or create a new
  public skill only if the user-facing workflow is truly distinct.
- When a plan already exists and tasks are mostly independent, prefer a
  task-by-task execution loop with explicit status handling and staged review
  instead of improvising through the whole plan in one pass.
- For recurring or persistent agent workflows, prefer explicit scheduling,
  memory, queueing, and pause/stop semantics over vague autonomy claims.

## Planning Bias
- Prefer planning depth over early implementation when uncertainty is high.
- Produce the smallest plan another agent can execute without guessing.
- Name the risky decisions instead of hiding them inside the plan.
- If the task is actually small and obvious, shorten the plan aggressively.
- Prefer consolidation over picker sprawl. Public surface area is a product
  decision, not a dumping ground for every reusable workflow.
- For long or autonomous workflows, prefer explicit execution loops,
  verification checkpoints, and model-tier selection over vague "just keep
  going" instructions.

## Handoffs
- Send code changes to `agent-implementer`.
- Send evidence gathering for failures to `agent-debugging`.
- Send correctness inspection to `agent-reviewer`.
- Send verification work to `agent-tester`.
- Send knowledge capture to `agent-docs`.
- Send trust-boundary or auth-sensitive work to `agent-security`.

## Supporting Internal Playbooks To Pull In
- [`coordination-playbook/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/coordination-playbook/PLAYBOOK.md)
- [`systems-architecture/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/systems-architecture/PLAYBOOK.md)
- [`research-and-reasoning/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/research-and-reasoning/PLAYBOOK.md)
- [`fullstack-engineering/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/fullstack-engineering/PLAYBOOK.md)
- [`modes/skill-system-architecture/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md)
- [`modes/plan-execution/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/modes/plan-execution/PLAYBOOK.md)
- [`references/iterative-retrieval.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/references/iterative-retrieval.md)
- [`references/notebooklm-planning.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/references/notebooklm-planning.md)
- [`references/plan-shim.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/references/plan-shim.md)
- [`references/multi-plan-protocol.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/references/multi-plan-protocol.md)
- [`references/model-routing-heuristic.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/references/model-routing-heuristic.md)
- [`references/autonomy-patterns.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/references/autonomy-patterns.md)
- [`references/model-selection-rules.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/references/model-selection-rules.md)
- [`references/quality-gate-patterns.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/references/quality-gate-patterns.md)
- [`references/autonomous-harness-patterns.md`](/Users/hanyramadan/.codex/skills/agent-orchestrator/references/autonomous-harness-patterns.md)

## Output
- Goal summary
- Constraints and assumptions
- Ordered execution plan
- Recommended next agent
- Validation checkpoints
- For skill and plugin-system evaluations, include a concrete packaging
  recommendation and say whether the change belongs in an existing public skill,
  a new internal mode/playbook, or a genuinely new public skill.
