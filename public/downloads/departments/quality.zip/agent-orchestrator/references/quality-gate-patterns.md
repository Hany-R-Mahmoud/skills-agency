# Quality Gate Patterns

Use this reference when a workflow needs structured gates before work is treated
as complete.

## Purpose
Prevent premature completion by separating "code exists" from "the work is
 actually done well enough."

## Gate Design

### Gate types
- spec compliance
- code quality
- verification and tests
- security checks when trust boundaries matter
- release readiness for larger changes

Use defense in depth when safety or reliability matters:
- input validation
- prompt or instruction hardening
- execution constraints and permission boundaries
- output checks or filtering
- cost ceilings and circuit breakers
- audit logging when traceability matters

### Single source discipline
- If the workflow has a dispatch matrix, phase map, or gate table, treat it as
  the only source of execution order.
- Commands, prompts, and wrapper docs may select a mode, but they should not
  silently define a second competing sequence.
- When multiple artifacts mention the same workflow, keep one normative source
  and make the rest point back to it.

### Gate ordering
- First verify the right thing was built.
- Then verify it was built well.
- Then verify it behaves correctly in execution.
- For design-heavy or high-risk tasks, require phase-gate clarity before
  implementation starts:
  - what unlocks the next phase
  - what still blocks it
  - what evidence counts as enough

### Severity blocking
- Define which severities block completion.
- Make residual risk explicit when lower-severity issues are deferred.
- Do not silently carry forward high-risk findings.

### Domain-specific gates
- For specialized domains, do not rely on generic evaluation alone.
- Require domain-appropriate criteria, disclaimers, and guardrails when the
  workflow touches regulated, high-stakes, or trust-sensitive areas.
- Treat missing domain guardrails as a real gate failure, not as optional
  polish.

### Reviewer independence
- Prefer independent review passes for different concerns when the task is
  important enough.
- Keep reviewer goals distinct so feedback is not redundant.

## Practical Guidance
- Use the minimum number of gates that still controls risk.
- Avoid theatrical gate inflation on small tasks.
- Make the pass/fail criteria legible before the work starts.
- When a plan relies on new imported guidance, challenge the strongest new
  claim before closing the planning phase.
- Prefer a short contradiction check over a long validation ceremony: what
  would change the chosen route if the new claim were stale, local-only, or
  only partially true?
