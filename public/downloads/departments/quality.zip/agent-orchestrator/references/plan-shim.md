# Plan Shim

Use this reference when the user needs a fast, execution-ready plan before any
implementation begins.

## Output Shape

- objective
- constraints
- ordered phases
- dependencies
- decision points
- validation checkpoints

## Rules

- planning only; do not start coding inside the plan step
- break work into phases that another agent can execute without guessing
- stop after the plan unless execution was explicitly requested
