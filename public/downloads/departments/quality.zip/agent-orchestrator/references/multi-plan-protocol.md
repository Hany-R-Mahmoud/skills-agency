# Multi-Plan Protocol

Use this reference when the work is large enough to require phased planning
rather than one flattened implementation plan.

## Pattern

- decompose into bounded phases
- define stop-loss boundaries between phases
- verify each phase before entering the next
- keep later phases flexible when earlier evidence may change the route

## Guardrails

- do not over-specify distant phases when near-term uncertainty is high
- do not let planning quietly turn into execution
