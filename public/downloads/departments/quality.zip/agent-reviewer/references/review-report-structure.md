# Review Report Structure

Use this reference when the review should be reported with more structure and
repeatability.

## Preferred Sections

- overview of scope reviewed
- findings grouped by severity
- each finding anchored to file and line when possible
- validation gaps or missing evidence
- residual risk

## Bias

- findings first, summary second
- separate correctness issues from style or preference comments
- keep the report scannable and decision-oriented
