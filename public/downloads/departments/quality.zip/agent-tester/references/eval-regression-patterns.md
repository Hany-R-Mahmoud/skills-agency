# Eval Regression Patterns

Use this reference when verification is closer to capability evaluation than
traditional test execution.

## Pattern

- define the capability under test explicitly
- keep a regression set of representative examples
- compare against prior behavior, not just current intuition
- report both wins and regression risk

## Useful Eval Loop

When the work is non-trivial or the behavior is somewhat nondeterministic, use
this lightweight loop:

1. define the capability and success criteria before coding
2. evaluate the current implementation against those criteria
3. report evidence, score, and remaining risk

Keep the artifacts compact:
- capability definition
- regression examples or baseline
- evaluation result

When the workflow is reusable, give the regression scenarios stable names such
as `eval-001`, `eval-002`, or domain-specific identifiers. Keep each scenario
small, legible, and tied to one behavior class rather than bundling many ideas
into one giant eval.

Useful scenario families include:

- structure or wiring checks
- integration pattern checks
- error-handling checks
- recurring or scheduled workflow checks
- end-to-end success-path checks

## Validation Phase

After defining scenarios, run a short validation phase instead of assuming the
examples themselves are enough:

- validate the shape of the artifact or workflow under test
- validate critical configuration, inputs, or dependencies
- validate the end-to-end behavior
- record which failures are structural versus behavioral

Prefer one compact checklist over a sprawling benchmark ceremony.

## Packaging Parity Gate

When the deliverable is a packaged plugin, extension, binary, or multi-host
integration, add a parity gate before closure or release.

A useful parity gate checks:

- imports versus the packaged file list
- vendored or generated assets versus what runtime code actually imports
- dry-run pack output versus expected runtime files
- one cheap smoke test against the packaged artifact, not just source mode

This catches "works locally, fails after packaging" regressions that ordinary
source-level tests often miss.

## Metrics To Use Carefully

- Use `pass@k` when multiple attempts are realistic and you care whether the
  workflow succeeds within a bounded number of runs.
- Use consecutive-pass expectations for critical paths that should be stable,
  not just occasionally successful.
- Prefer code-based or command-based graders over model judgment when a
  deterministic check is available.
- Do not compare flattering benchmark numbers across mismatched metrics. Keep
  retrieval, classification, and end-to-end task accuracy clearly separated.
- If a stronger number was reached by inspecting specific failures and tuning to
  them, mark it as tuned or overfit evidence rather than the default headline.

## Storage Bias

- Keep eval definitions versioned with the code or task artifact they validate.
- Treat evals as evidence for closure, not as a second planning document.
- If the loop becomes reusable across tasks, promote the pattern into a
  reference before expanding any public skill text.

## Benchmark Contract

When a reusable benchmark or heavier eval flow exists, define a stable contract
instead of a loose collection of commands:

- canonical entrypoints such as `preflight`, `smoke`, `full`, `score`, and
  `report`
- deterministic profile or dataset identifiers where reproducibility matters
- explicit artifact outputs and expected file locations
- clear error codes or failure categories for common setup problems

Prefer one obvious validation path over several equivalent but drifting
invocation styles.

When a workflow benefits from staged verification, a useful contract is:

- `preflight`: cheap structural and setup checks
- `smoke`: minimal representative scenarios
- `full`: broader regression set when needed
- `score`: summarize pass/fail or quantitative results
- `report`: emit the compact evidence artifact

## Benchmark Integrity

- Preserve the honest baseline alongside any tuned or assisted result.
- Label whether a result is:
  - raw or baseline
  - tuned on a dev set
  - assisted by an external model or reranker
  - held out and generalizable
- If public messaging needs one number, prefer the most honest reproducible
  figure over the most impressive one.
- When comparing to other systems, note metric and split differences instead of
  implying a direct head-to-head if one does not exist.
