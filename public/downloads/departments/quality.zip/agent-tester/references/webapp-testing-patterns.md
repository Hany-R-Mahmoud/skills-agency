# Webapp Testing Patterns

Use this reference for browser-level validation of local web applications.

## Core Pattern
- Reconnaissance first, interaction second.
- Let the rendered application reveal the selectors and state before writing
  assertions or click flows.

## Practical Flow
1. Load the page and wait for the relevant state to settle.
2. Inspect the rendered DOM, visible UI, or screenshot output.
3. Identify robust selectors from the live page.
4. Perform actions with those selectors.
5. Re-check visible outcomes, logs, or screenshots.

## Guidance
- For dynamic apps, wait for meaningful readiness before inspection.
- Prefer robust selectors based on roles, text, labels, and stable attributes.
- Use screenshots and DOM inspection when the page structure is unclear.
- Treat browser logs and failed interactions as debugging evidence, not just
  test failures.
- Keep automation scripts focused on the scenario under test.
