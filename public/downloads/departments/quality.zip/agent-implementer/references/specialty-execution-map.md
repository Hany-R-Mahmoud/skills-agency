# Specialty Execution Map

This reference captures the best agent-layer benefit we can take from broad,
specialized skill packs such as `jeffallan/claude-skills` without turning
`agent-implementer` into many public picker entries.

## Purpose

Use this map when implementation work is clear, but domain depth matters. It
helps `agent-implementer` stay a single public execution agent while still
borrowing stronger specialty heuristics behind the scenes.

## Implementation Depth Areas

- **Backend APIs and services**
  - lean on stronger contract discipline, boundary clarity, and migration-aware
    change planning
- **Framework-specific delivery**
  - preserve framework conventions instead of forcing generic patterns
- **CLI and automation work**
  - keep commands reproducible, idempotent where possible, and easy to verify
- **Database and persistence changes**
  - treat schema impact, rollback, and data correctness as first-class
- **Infrastructure-adjacent code**
  - coordinate with `agent-ops` when the change crosses from app code into
    deployment or environment ownership
- **AI and retrieval features**
  - coordinate with `agent-data-ai` when prompt flow, retrieval, or evaluation
    quality materially shapes the implementation

## Routing Rule

When a task is still primarily "implement the change" but needs deeper domain
knowledge, keep ownership in `agent-implementer` and pull specialized guidance
from the relevant public sibling agent or internal playbook. Do not create a
new public implementer for every language or framework.

## Anti-Pattern

Do not mirror every external specialty skill as a separate local agent. Keep
one execution entry point and enrich it with references like this one.
