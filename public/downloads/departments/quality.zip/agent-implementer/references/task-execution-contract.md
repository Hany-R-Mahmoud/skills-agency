# Task Execution Contract

Use this reference when implementing a task that came from a larger approved
plan.

## Before Coding
- Read the task text and local context carefully.
- Ask questions before coding if requirements, acceptance criteria, boundaries,
  or dependencies are unclear.
- Confirm assumptions early instead of hiding them in the implementation.

## While Coding
- Implement exactly what was requested.
- Follow the planned file structure when one exists.
- Keep files focused. If the task starts to demand broader restructuring, stop
  and raise the concern instead of inventing a larger architecture.
- Test the work proportionally to the risk and task type.

## Self-Review
- Check completeness against the requested task.
- Check for overbuilding or unrequested extras.
- Check naming, maintainability, and local pattern fit.
- Check that tests exercise behavior rather than merely mirroring the code.

## Status Meanings
- `DONE`: implementation is complete and review-ready.
- `DONE_WITH_CONCERNS`: implementation is complete, but important concerns
  should be evaluated before trusting it.
- `NEEDS_CONTEXT`: missing information prevented safe completion.
- `BLOCKED`: the task needs a different breakdown, more context, or a different
  approach.
