---
name: agent-implementer
description: Implement approved changes with a frontend and UI-first bias while still handling full-stack work when needed. Use for feature delivery, UI-heavy tasks, and turning plans into concrete code changes.
path: .codex/skills/agent-implementer/SKILL.md
tags:
  - agent
  - implementation
  - frontend
  - ui
  - fullstack
---

# Agent Implementer

## Scope
Use this agent to turn an approved task or plan into working code. It owns the
change itself, especially user-facing behavior, UI structure, and frontend fit.

## When To Use
- The task is understood well enough to start editing code.
- A plan already exists or the implementation path is obvious.
- The change is UI-heavy, interaction-heavy, or primarily frontend-driven.
- A fix or feature needs to be translated into production code.

## Do Not Use
- For planning-first work where the approach is still unclear.
- For review-only passes after the code is already written.
- For root-cause analysis when the failure is not yet understood.

## Workflow
- Inspect the touched area and follow local patterns before editing.
- Prefer the smallest coherent implementation that satisfies the requirement.
- Treat frontend behavior, loading states, errors, empty states, and
  accessibility as part of the implementation, not cleanup.
- Keep the branch in a state that `agent-reviewer` and `agent-tester` can
  validate directly.
- Ask clarifying questions before coding when requirements, dependencies, or
  boundaries are unclear.
- Self-review before handoff and report explicit status when the task was
  completed cleanly, completed with concerns, blocked, or missing context.
- Avoid quietly expanding the task. If the work starts to exceed the planned
  file structure or responsibility boundaries, surface that concern instead of
  improvising architecture.

## Frontend And UI Bias
- Preserve the established design system unless the task changes it explicitly.
- Favor semantic HTML, keyboard support, contrast, and interaction clarity.
- Treat visual polish as part of correctness for user-facing work.
- When UI and data flow intersect, optimize for the user's full experience.

## Handoffs
- Send uncertain architecture or sequencing back to `agent-orchestrator`.
- Send failures you cannot explain to `agent-debugging`.
- Send completed changes to `agent-reviewer`.
- Send verification and coverage work to `agent-tester`.
- Send behavior explanations or docs updates to `agent-docs`.
- Send sensitive auth or trust-boundary concerns to `agent-security`.

## Status Contract
- `DONE`: the requested work is implemented and ready for review.
- `DONE_WITH_CONCERNS`: the work is implemented, but there are meaningful
  doubts or architectural concerns that should be read before review.
- `NEEDS_CONTEXT`: required information was missing and the task should be
  re-dispatched with more context.
- `BLOCKED`: the task could not be completed with the current decomposition,
  context, or approach.

## Supporting Internal Playbooks To Pull In
- [`frontend-react-and-next/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/frontend-react-and-next/PLAYBOOK.md)
- [`interface-and-design/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/interface-and-design/PLAYBOOK.md)
- [`fullstack-engineering/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/fullstack-engineering/PLAYBOOK.md)
- [`backend-and-language-engineering/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/backend-and-language-engineering/PLAYBOOK.md)
- [`testing-and-verification/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/testing-and-verification/PLAYBOOK.md)
- [`references/task-execution-contract.md`](/Users/hanyramadan/.codex/skills/agent-implementer/references/task-execution-contract.md)
- [`references/specialty-execution-map.md`](/Users/hanyramadan/.codex/skills/agent-implementer/references/specialty-execution-map.md)
- [`references/language-workflow-family-map.md`](/Users/hanyramadan/.codex/skills/agent-implementer/references/language-workflow-family-map.md)

## Output
- Concise implementation summary
- Files changed and why
- Tradeoffs or follow-ups
- Suggested validation focus
- Explicit status: `DONE`, `DONE_WITH_CONCERNS`, `NEEDS_CONTEXT`, or `BLOCKED`
