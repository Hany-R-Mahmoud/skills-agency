# On-Demand Security Gate

Use this reference when the user or workflow needs an explicit security check
before closure, promotion, or release.

## Pattern

- invoke the gate intentionally
- define what surfaces are in scope
- report pass/fail/open-risk clearly
- keep it separate from ordinary review chatter

## Bias

- prefer an operator-invoked gate over noisy always-on security interruptions
