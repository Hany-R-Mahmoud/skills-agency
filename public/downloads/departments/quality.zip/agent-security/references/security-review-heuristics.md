# Security Review Heuristics

Use this reference to give `agent-security` more concrete review prompts.

## Review Lenses

- trust boundaries and attacker-controlled inputs
- authn/authz separation and privilege escalation paths
- secret handling and accidental exposure
- unsafe defaults, wildcard permissions, and missing allowlists
- data egress, logging leakage, and debug-surface exposure

## Reporting Bias

- prefer concrete exploit paths over vague fear language
- distinguish confirmed issues from suspicious-but-unproven risks
- recommend the smallest meaningful hardening step when full redesign is not
  realistic
