---
name: documentation-and-doc-ops
description: Create or revise developer-facing docs, API specs, docstrings, and structured internal updates. Use for markdown docs, code documentation, API portals, editorial cleanup, and collaborative documentation workflows.
path: skills/documentation-and-doc-ops/PLAYBOOK.md
tags:
  - docs
  - markdown
  - docstrings
  - openapi
  - api-docs
  - internal-comms
---

# Documentation And Doc Ops

## Scope
Use this skill for repository documentation, API documentation, inline code
documentation, structured internal updates, and collaborative doc drafting.

## Instructions
- Start by identifying the document type: repo docs, API docs, docstrings,
  internal update, or collaborative draft.
- Audit current behavior and source files before editing prose.
- For markdown docs, keep the writing direct, specific, and globally readable.
- Use active voice, sentence case headings, descriptive links, and meaningful
  examples.
- For API documentation, detect the framework first and choose the right format:
  OpenAPI, framework-native docs, doc portal config, or code examples.
- For code documentation, document public APIs, parameter types, errors,
  examples, and behavior that is not obvious from code.
- For collaborative drafting, turn the request into a structured outline before
  writing the final text.
- For internal communications, optimize for audience, decision context, status,
  risks, and next steps.

## Sub-skill: Editorial standards
- Use concise US English, avoid hype, and distinguish requirements from
  recommendations.
- Prefer short explanatory paragraphs before lists.
- Remove stale references, dead sections, and table-of-contents boilerplate
  unless it is essential.

## Sub-skill: API and code documentation
- Ask for doc format preference only when the target format is ambiguous.
- Detect the implementation framework before choosing OpenAPI, JSDoc, or
  framework-specific patterns.
- Validate examples against the actual codebase whenever possible.
- Include coverage gaps and follow-up doc tasks when the source is incomplete.

## Sub-skill: Internal updates
- Lead with the main outcome or ask.
- Preserve factual status, blockers, owners, dates, and explicit next steps.
- Keep executive-facing updates compressed and operational updates specific.

## Notes
- Remove project-specific naming or policy language inherited from source
  skills unless it still applies in this repo.
- If the task is only about generating `.docx`, `.pdf`, `.pptx`, or spreadsheet
  files, use `document-files` instead.
