---
name: coordination-playbook
description: Coordinate multi-step agent workflows, internal playbook selection, and skill-authoring strategy. Use for task decomposition, routing design, and choosing the smallest effective internal capability set.
path: skills/coordination-playbook/PLAYBOOK.md
tags:
  - orchestration
  - task-decomposition
  - skills
  - evaluation
  - planning
---

# Coordination Playbook

## Scope
Use this internal playbook for multi-step workflow design, choosing the right
internal capabilities, and creating or improving skills themselves.

## Instructions
- Break complex goals into ordered steps with explicit dependencies and
  validation points.
- Prefer the smallest effective skill set instead of loading many overlapping
  skills.
- When creating or improving a skill, define trigger conditions, workflow,
  output expectations, and an evaluation loop.
- Preserve context explicitly across long-running workflows.

## Sub-skill: Task decomposition
- Separate discoverable facts from preference decisions.
- Structure plans so that another agent can execute them without guessing.

## Sub-skill: Skill creation
- Treat metadata quality as a trigger-design problem.
- Evaluate skills with realistic prompts before treating them as done.

## Notes
- Remove assumptions about unavailable systems or tools unless the repo
  explicitly provides them.
