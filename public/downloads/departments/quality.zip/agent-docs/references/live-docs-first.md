# Live Docs First

Use this reference when answering documentation-heavy questions that depend on
current library or platform behavior.

## Pattern

- ask for the exact library, version, or surface when it matters
- prefer live primary docs over stale memory
- keep the final answer minimal and actionable
- state uncertainty explicitly when docs are incomplete or ambiguous
