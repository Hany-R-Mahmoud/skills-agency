---
name: fullstack-engineering
description: Build features that span frontend, API, and persistence layers as one delivery unit. Use when the task needs coordinated UI, backend, and data-flow implementation.
path: skills/fullstack-engineering/PLAYBOOK.md
tags:
  - fullstack
  - ui
  - api
  - database
  - feature
---

# Fullstack Engineering

## Scope
Use this skill when a feature crosses frontend, backend, and data boundaries and
needs to be delivered as one coherent unit.

## Instructions
- Map the full request first: UI behavior, backend contract, persistence needs,
  auth or policy constraints, and validation.
- Sequence work by dependency, but keep end-to-end behavior visible throughout.
- Prefer narrow, testable contracts between layers.
- Validate the whole user-facing flow, not just each layer in isolation.

## Sub-skill: Integrated delivery
- Coordinate API shape, client state, persistence semantics, and error handling
  together.
- Make assumptions at layer boundaries explicit.

## Notes
- Use `systems-architecture` if the request is still deciding system design.
- Use `testing-and-verification` for detailed test planning and execution.
