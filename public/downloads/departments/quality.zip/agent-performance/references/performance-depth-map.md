# Performance Depth Map

Use this reference to enrich `agent-performance` with deeper DB, query, and
system investigation heuristics.

## Database And Query Performance

- inspect query shape, indexes, cardinality, and access patterns together
- separate one slow query from systemic data-model problems
- treat caching as a tradeoff, not a reflex

## Investigation Bias

- profile before rewriting
- distinguish CPU, IO, lock contention, network, and render causes
- measure the user-visible outcome, not just microbench improvements
