---
name: research-and-reasoning
description: Perform deep research, synthesis, and adversarial reasoning to validate plans and claims. Use for fact-finding, tradeoff analysis, pre-mortems, and challenge reviews.
path: skills/research-and-reasoning/PLAYBOOK.md
tags:
  - research
  - synthesis
  - reasoning
  - pre-mortem
  - challenge
---

# Research And Reasoning

## Scope
Use this skill for deep information gathering, synthesis, challenge reviews, and
tradeoff validation.

## Instructions
- Separate evidence gathering from judgment.
- Verify claims with multiple sources or independent signals when the topic is
  uncertain or unstable.
- Use adversarial reasoning to test assumptions, identify blind spots, and
  pressure-test plans.
- Make the reasoning legible: what is known, what is inferred, and what remains
  uncertain.

## Sub-skill: Research
- Use targeted search and source filtering for fact-finding and synthesis.
- Prefer primary sources when accuracy matters.

## Sub-skill: Challenge review
- Run pre-mortems, devil’s-advocate checks, and alternative-path comparisons
  when decisions have meaningful downside.

## Notes
- Use this skill to strengthen decisions, not to stall action unnecessarily.
