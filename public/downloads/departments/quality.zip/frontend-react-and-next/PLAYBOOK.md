---
name: frontend-react-and-next
description: Build and review web UI in React and Next.js using performant composition and modern framework patterns. Use for React components, Next.js App Router, cache components, Ant Design, and frontend architecture.
path: skills/frontend-react-and-next/PLAYBOOK.md
tags:
  - react
  - nextjs
  - cache-components
  - ant-design
  - frontend
---

# Frontend React And Next

## Scope
Use this skill for React and Next.js implementation, review, performance
patterns, composition patterns, and Ant Design usage.

## Instructions
- Identify the framework context first: plain React, Next.js App Router,
  Cache Components mode, or Ant Design integration.
- Prefer TypeScript, accessible markup, and clear component boundaries.
- Use composition to reduce boolean-prop sprawl and avoid monolithic
  components.
- Apply performance rules intentionally: parallelize async work, reduce bundle
  cost, minimize unnecessary re-renders, and stream async UI where appropriate.
- If Next.js Cache Components are enabled, treat caching and Suspense boundaries
  as core implementation decisions rather than post-processing.

## Sub-skill: React and composition
- Use modern React patterns, explicit variants, and clear data flow.
- Avoid overusing memoization; apply it where render cost or identity churn is
  meaningful.

## Sub-skill: Next.js specifics
- Distinguish static, cached, and dynamic boundaries.
- Prefer code-level caching patterns over legacy config-based thinking.

## Sub-skill: Design systems
- Follow the established component library and token system when Ant Design is
  in play.

## Notes
- This skill is for React and Next.js web work. Use `mobile-engineering` for
  React Native or native mobile tasks.
