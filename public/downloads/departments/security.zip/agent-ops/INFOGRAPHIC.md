# Ops Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for OPS inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Security and Platform department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: OPS
- Subtitle: Infrastructure, deployment, CI/CD, and incident operations specialist
- Commands:
  - /agent-ops
  - $agent-ops
- One-line value:
  The public entry point for deployment systems, cloud infrastructure, Kubernetes, Terraform, incident handling, and production troubleshooting.
- Capabilities:
  - CI/CD
  - cloud infrastructure
  - incident response
  - Terraform and Kubernetes
- How it works:
  - reads the operational problem
  - chooses the smallest useful ops lanes
  - keeps operator control and risk visible
  - returns a practical path for infra or production work
- Best used when:
  - a deployment, build pipeline, or production operation needs direct attention
  - you are working on cloud infra, Terraform, Kubernetes, or operational troubleshooting
  - rollback, operator control, and incident risk need to stay explicit
- Bottom summary:
  ops-foundation, deployment-operations, cloud-infrastructure, terraform-operations, incident-operations
- Footer note:
  You ask for the outcome. Ops keeps production risk visible.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
