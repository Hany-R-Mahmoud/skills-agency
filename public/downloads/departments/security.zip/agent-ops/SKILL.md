---
name: agent-ops
description: Unified operations, deployment, and infrastructure agent for this skill pack. Use when Codex should handle CI/CD, cloud infrastructure, Kubernetes, Terraform, incident handling, or operational troubleshooting through one local entry point.
---

# Agent Ops

Provide a single public entry point for this repository's infrastructure and
operations work.

Act as a router plus executor: choose the smallest set of ops modes needed,
sequence them well, and avoid loading irrelevant guidance.

## Invocation Contract

Invoke this skill directly as `$agent-ops` whenever the prompt is about
deployment systems, CI/CD, cloud or Kubernetes operations, Terraform, incident
handling, or production troubleshooting.

When explicitly invoked, do not ask the user to choose internal modes unless
there is a real strategic tradeoff. Infer the likely path from the prompt and
proceed.

## Quick Start

- "fix deployment / CI":
  `ops-foundation`, then `deployment-operations`
- "design or update cloud infra":
  `ops-foundation`, then `cloud-infrastructure`
- "work with Terraform":
  `ops-foundation`, then `terraform-operations`
- "work with Kubernetes":
  `ops-foundation`, then `kubernetes-operations`
- "production issue or incident":
  `ops-foundation`, then `incident-operations`
- "debug an ops problem":
  `ops-foundation`, then `ops-troubleshooting`

## Core Workflow

1. Inspect the request and classify it:
   - deployment pipeline
   - cloud architecture
   - infrastructure as code
   - cluster operations
   - incident response
   - ops debugging
2. Load `modes/ops-foundation/PLAYBOOK.md` first.
3. Choose the minimum supporting modes from the references.
4. Keep output explicit about risk, rollback, and operator control.

## Reference

Use these references as needed:

- `references/skill-map.md`
- `references/request-recipes.md`
- `references/ops-depth-map.md`
