---
name: deployment-operations
description: Work on CI/CD pipelines, release flows, container delivery, and deployment safety.
---

Focus on pipeline correctness, environment promotion, rollback, and release
visibility.
