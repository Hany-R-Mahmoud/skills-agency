---
name: cloud-infrastructure
description: Design or evolve cloud infrastructure with explicit environment boundaries, cost awareness, and operational fit.
---

Focus on environment topology, network boundaries, managed services, and
operational tradeoffs.
