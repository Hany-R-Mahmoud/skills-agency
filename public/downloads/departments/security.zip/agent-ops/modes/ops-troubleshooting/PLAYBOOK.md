---
name: ops-troubleshooting
description: Diagnose operational failures using logs, environment state, deployment history, and service health signals.
---

Focus on narrowing the failure path, proving the trigger, and preserving the
evidence trail.
