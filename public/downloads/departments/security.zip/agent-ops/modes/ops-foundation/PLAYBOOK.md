---
name: ops-foundation
description: Shared foundation for safe operations work, explicit state discovery, rollback awareness, and operator control.
---

Use this playbook before any other `agent-ops` mode.

## Rules

- discover the current environment and deployment state before changing it
- make rollback and blast radius explicit
- prefer reversible changes and clear operator checkpoints
- treat credentials, secrets, and prod writes as high-risk by default
