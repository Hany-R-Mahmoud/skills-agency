---
name: incident-operations
description: Coordinate production incident handling with containment, communication, recovery, and clear operator ownership.
---

Focus on containment first, then diagnosis, then recovery and follow-up.

## Workflow

1. Declare the incident clearly:
   - severity
   - affected surface
   - operator owner
   - current customer impact
2. Stabilize before optimizing:
   - contain blast radius
   - preserve evidence
   - choose the safest recovery path
3. Keep communication on a visible cadence:
   - initial status
   - regular updates during active response
   - explicit resolution notice
4. Close with follow-up:
   - what happened
   - what changed service health
   - what should be hardened next

## Severity Cues

- `SEV1`: broad user impact, major revenue or availability risk, or no safe
  workaround
- `SEV2`: serious degradation with partial workaround or narrower blast radius
- `SEV3`: limited impact, degraded subsystem, or contained operational issue

## Guardrails

- containment and rollback are usually safer than heroic live debugging
- do not bury customer impact behind technical detail
- do not treat the incident as complete until communication and follow-up are
  explicit
