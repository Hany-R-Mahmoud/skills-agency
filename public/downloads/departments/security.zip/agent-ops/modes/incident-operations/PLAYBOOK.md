---
name: incident-operations
description: Coordinate production incident handling with containment, communication, recovery, and clear operator ownership.
---

Focus on containment first, then diagnosis, then recovery and follow-up.
