---
name: terraform-operations
description: Handle Terraform-driven infrastructure safely with state awareness, module discipline, and plan-first execution.
---

Focus on module boundaries, state risk, drift, imports, and change safety.
