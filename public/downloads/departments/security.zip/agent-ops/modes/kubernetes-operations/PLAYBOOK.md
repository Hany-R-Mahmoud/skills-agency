---
name: kubernetes-operations
description: Work on Kubernetes workloads, cluster operations, deployment strategy, and GitOps-compatible patterns.
---

Focus on manifests, rollout safety, observability hooks, and runtime behavior.
