# Request Recipes

- "Fix the deployment":
  start with `ops-foundation`; add `deployment-operations`
- "Set up or change cloud infra":
  start with `ops-foundation`; add `cloud-infrastructure`
- "Update Terraform":
  start with `ops-foundation`; add `terraform-operations`
- "Work on Kubernetes":
  start with `ops-foundation`; add `kubernetes-operations`
- "Handle this incident":
  start with `ops-foundation`; add `incident-operations`
- "Why did production or staging break?":
  start with `ops-foundation`; add `ops-troubleshooting`
