# Skill Map

Use this file to route a request to the minimum useful subset of the internal
operations modes bundled inside `agent-ops`.

## Foundation

- `ops-foundation`: `modes/ops-foundation/PLAYBOOK.md`, shared operational
  safety, state discovery, and rollback-aware execution framing

Always start with `ops-foundation`.

## Modes

- `deployment-operations`: `modes/deployment-operations/PLAYBOOK.md`, CI/CD and
  release workflows
- `cloud-infrastructure`: `modes/cloud-infrastructure/PLAYBOOK.md`, cloud
  architecture and environment topology
- `terraform-operations`: `modes/terraform-operations/PLAYBOOK.md`,
  infrastructure as code patterns and state-aware changes
- `kubernetes-operations`: `modes/kubernetes-operations/PLAYBOOK.md`, cluster,
  workloads, and GitOps-oriented ops concerns
- `incident-operations`: `modes/incident-operations/PLAYBOOK.md`, incident
  containment, coordination, and recovery
- `ops-troubleshooting`: `modes/ops-troubleshooting/PLAYBOOK.md`, logs,
  environment drift, deployment breakage, and operational debugging
