# Ops Depth Map

Use this reference to deepen `agent-ops` with cloud, IaC, and deployment
patterns adapted from broader ops skill packs.

## Cloud Infrastructure

- make environment boundaries explicit
- separate control plane choices from app-runtime concerns
- favor operable defaults over maximal flexibility

## Infrastructure As Code

- prefer plan-first, reviewable changes
- call out state risk, drift, and import complexity
- keep modules composable but not abstract for abstraction's sake

## Deployment And Release

- make rollback and blast radius visible
- bias toward reproducible release workflows
- treat observability and health checks as part of deployment correctness
