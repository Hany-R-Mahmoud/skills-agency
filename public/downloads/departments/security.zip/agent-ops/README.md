# Ops Guide

`agent-ops` is the public infrastructure, deployment, CI/CD, and incident
operations specialist.

## What It Does

It helps with deployment systems, cloud infrastructure, Kubernetes, Terraform,
incident handling, and production troubleshooting through one entry point.

It is best at:

- CI/CD
- cloud infrastructure
- incident response
- Terraform and Kubernetes

## How To Use It

Call it with:

- `/agent-ops`
- `$agent-ops`

Use it when:

- a deployment, build pipeline, or production operation needs direct attention
- you are working on cloud infra, Terraform, Kubernetes, or operational
  troubleshooting
- rollback, operator control, and incident risk need to stay explicit

## How It Works

It reads the operational problem, chooses the smallest useful ops lanes, and
returns an operator-friendly path that keeps risk visible.

## Internal Playbooks

- `Ops Foundation` (`ops-foundation`): classifies the operational problem before
  deeper infra lanes are selected
- `Deployment Operations` (`deployment-operations`): handles CI/CD, release
  pipelines, and production rollout discipline
- `Cloud Infrastructure` (`cloud-infrastructure`): shapes cloud resource
  decisions and deployment topology
- `Terraform Operations` (`terraform-operations`): guides infra-as-code changes
  with operator control and safer review
- `Incident Operations` (`incident-operations`): supports production triage,
  rollback reasoning, and response clarity

## Short Version

Use `/agent-ops` or `$agent-ops` when the work is operational, infra-heavy, or
production-sensitive.
