# Skill Map

Use this file to route a request to the minimum useful subset of the internal
composition lanes bundled inside `agent-composer`.

## Foundation

- `foundation`: `references/composition-standards.md`, shared local standards,
  import hygiene, and public-surface rules

Always start with `foundation`.

## Composition Lanes

- `skill-architecture`: define the purpose, scope, routing model, and local
  shape of a new skill
- `skill-scaffolding`: create the concrete files such as `SKILL.md`,
  `agents/openai.yaml`, and routing references
- `packaging`: tune naming, descriptions, metadata, examples, and user-facing
  invocation language
- `consolidation`: collapse overlapping upstream ideas into one stronger local
  public entry point
- `attached-skill-synthesis`: inspect multiple attached or referenced
  `SKILL.md` files, extract their durable capabilities, and synthesize one
  native local `agent-*` shape
- `skill-evaluation`: add lightweight benchmarking, test-prompt, or quality
  heuristics when reuse matters
- `repo-evolution`: run a dry-run-first import-and-compare pass to improve
  existing local skills from external repos without bloating public surfaces

Use when the problem is mostly about what the skill should be and how it should
be packaged.

## Browser Lanes

- `browser-automation`: structure the browser workflow, state handling, and
  evidence capture using `references/browser-composition.md`
- `playwright-execution`: express the execution model in Playwright-capable
  terms such as context, selectors, waits, screenshots, downloads, and auth
  state
- `delivery`: harden the skill for recurring use, safer defaults, and clearer
  verification

Use when the skill must browse, test, scrape, sign in, fill forms, or capture
artifacts from a web app.

## Recommended Bundles

- Build a new local skill:
  `foundation`, then `skill-architecture`, `skill-scaffolding`, `packaging`
- Build a new `agent-*` from attached `SKILL.md` files:
  `foundation`, then `attached-skill-synthesis`, `consolidation`,
  `skill-architecture`, `skill-scaffolding`, `packaging`
- Turn external repos into one local agent:
  `foundation`, then `consolidation`, `skill-architecture`, `packaging`
- Turn external repos into improvements for existing local skills:
  `foundation`, then `repo-evolution`, `consolidation`, `skill-evaluation`,
  `packaging`
- Add browser capability:
  `foundation`, then `browser-automation`, `playwright-execution`
- Ship a reusable browser agent:
  `foundation`, then `browser-automation`, `playwright-execution`, `delivery`
- Pressure-test a reusable skill:
  `foundation`, then `skill-evaluation`, optionally `delivery`

## Anti-Pattern

Do not activate every lane just because the skill could theoretically use them.
Choose the smallest useful bundle.
