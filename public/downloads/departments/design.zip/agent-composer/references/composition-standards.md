# Composition Standards

Use this file as the shared foundation for `agent-composer`.

## Primary Goal

Create local skills that feel native to this repository even when the source
ideas come from larger or noisier upstream skill packs.

## Core Rules

- Prefer one coherent public entry point over many narrow picker entries.
- Pull in only the strongest upstream ideas; do not mirror foreign trees by
  default.
- Convert product-specific jargon into local, reusable language.
- Keep the public `SKILL.md` short enough to route well, but concrete enough to
  execute.
- Move complexity into references, private modes, templates, or scripts.

## Local Shape

When creating a new public skill, prefer this shape:

- `SKILL.md` as the main entry point
- `agents/openai.yaml` for interface metadata
- `references/` for routing maps, recipes, and opinionated standards
- `modes/` only when private execution branches are large enough to justify
  separate playbooks

Keep the public surface thin:

- public entrypoints should route, gate, and explain
- dense workflow rules, templates, and checklists should live in references or
  playbooks
- each durable reference or template should have one clear owner instead of
  being copied across skills, agents, and commands

## Attached SKILL.md To Agent Contract

When the user asks to create a new `agent-*` from attached or referenced
`SKILL.md` files:

- Inspect every source `SKILL.md` and extract:
  - durable capabilities
  - trigger phrases
  - workflow steps
  - guardrails and anti-patterns
  - reusable examples, templates, or checks
- Compare the requested agent against existing local `agent-*` skills before
  writing files. Enhance an existing public agent if the new capability is not
  user-visible and distinct.
- Normalize the target name to `agent-<domain>` unless the user explicitly
  requires another valid local name. For example, prefer `agent-backend` over
  `agent0backend`.
- Create a concise public `SKILL.md` with frontmatter, scope, invocation or use
  criteria, do-not-use guidance, workflow, routing or handoffs, references, and
  output shape.
- Create `agents/openai.yaml` with display name, short description, default
  prompt, and implicit-invocation policy when the agent should be discoverable.
- Add `references/skill-map.md` and `references/request-recipes.md` when the
  source skills imply multiple internal lanes or common request phrasings.
- Add `modes/*/PLAYBOOK.md` only for large private execution branches that
  would make the public `SKILL.md` too dense.
- Preserve exact source names in references only when useful for future lookup;
  keep the public skill language normalized to the local agent taxonomy.
- Report what was kept, compressed, omitted, and why.

## Import Hygiene

When adapting external skills or repos:

- keep the capability, not the clutter
- remove marketplace-facing or vendor-specific framing
- preserve strong execution patterns, examples, and guardrails
- collapse overlapping concepts into fewer internal lanes
- avoid verbatim copying when a concise local rewrite is stronger
- preserve exact upstream names in references or notes when they matter for
  fidelity, verification, or future lookup
- keep public skill language normalized to the local taxonomy instead of
  leaking upstream naming into the main routing surface
- when the upstream file is large, contradictory, or over-mixed, resolve
  contradictions before splitting it into local references
- prefer deleting imported redundant guidance over reorganizing it more neatly
  inside the local repo

Use this quick triage when deciding what survives import:

- `expert`: genuinely non-obvious local value, preserve it
- `activation`: brief reminder or checklist value, compress it
- `redundant`: obvious or already-covered material, drop it

## Evaluation Bias

If the skill will be reused often, include lightweight evaluation guidance:

- what good requests look like
- how to judge whether the route was correct
- what should remain private vs public
- which browser flows or templates are risky enough to verify explicitly
- which imported claims are strong enough to treat as fact versus cautionary
  guidance

When a workflow introduces scripts or CLI entrypoints, prefer a canonical
validation contract:

- one obvious smoke entrypoint
- clear aliases if needed, but only one implementation path
- explicit completion criteria for parity, verification, and doc sync

## Anti-Pattern

Do not create a new public skill just because the upstream repo had a distinct
folder. Public surface area is part of product design.

Common workflow anti-patterns are often a better import than another command or
mode. Prefer short explicit "do not do this" guidance when it helps prevent:

- multi-agent orchestration for work that fits one agent
- vague prompts with no structure, schema, or clear outcome
- context dumping instead of selective retrieval
- tool sprawl without ownership, descriptions, or retry safety
- "it seems to work" closure without evaluation or verification
- contradiction-preserving cleanup where bloated upstream guidance gets split
  into smaller files without first removing conflicts or dead weight
