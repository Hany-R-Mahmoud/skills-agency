# Department pack for command

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-co-pilot`
- `agent-debugging`
- `agent-docs`
- `agent-impeccable`
- `agent-implementer`
- `agent-orchestrator`
- `agent-pilot`
- `agent-reviewer`
- `agent-security`
- `agent-tester`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
