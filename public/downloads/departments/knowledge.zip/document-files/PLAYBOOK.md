---
name: document-files
description: Create, read, edit, convert, and restyle office-style document files including `.docx`, `.pdf`, `.pptx`, and spreadsheets. Use when the primary deliverable or source artifact is a document file rather than code.
path: skills/document-files/PLAYBOOK.md
tags:
  - docx
  - pdf
  - pptx
  - xlsx
  - csv
  - documents
---

# Document Files

## Scope
Use this skill when the main input or output is a document file: Word, PDF,
presentation, or spreadsheet.

## Instructions
- Determine the target format first: `.docx`, `.pdf`, `.pptx`, `.xlsx`,
  `.xlsm`, `.csv`, or `.tsv`.
- Preserve formatting-sensitive requirements such as page numbers, headings,
  speaker notes, tables, charts, comments, form fields, watermarks, or tracked
  changes.
- If converting between formats, call out any fidelity risks before writing.
- Keep structured data in spreadsheets, presentational narrative in slides, and
  long-form formatted prose in Word or PDF outputs.

## Sub-skill: Word and PDF workflows
- Support creation, extraction, editing, replacement, merging, splitting,
  watermarking, OCR, and form operations.
- Maintain headings, layout, and readable pagination when generating documents.

## Sub-skill: Presentation workflows
- Treat any slide deck, presentation, or `.pptx` request as a presentation-file
  task even if the user mainly wants extracted content.
- Preserve slide order, layouts, notes, and comments when updating decks.

## Sub-skill: Spreadsheet workflows
- Treat spreadsheet cleaning, restructuring, formulas, charts, and tabular
  conversions as spreadsheet-file work when the deliverable is tabular.
- Keep formulas, headers, and sheet semantics explicit.

## Notes
- If the user wants artifact styling or themed visuals, coordinate with
  `interface-and-design` or `visual-artifacts`.
- If the deliverable is prose in markdown or repo docs, use
  `documentation-and-doc-ops` instead.
