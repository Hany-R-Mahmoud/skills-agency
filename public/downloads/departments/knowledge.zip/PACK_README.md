# Department pack for knowledge

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-data-ai`
- `agent-docs`
- `agent-history`
- `agent-implementer`
- `agent-orchestrator`
- `agent-researcher`
- `agent-reviewer`
- `agent-tester`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
