# Department pack for knowledge

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-data-ai`
- `agent-docs`
- `agent-history`
- `agent-implementer`
- `agent-orchestrator`
- `agent-researcher`
- `agent-reviewer`
- `agent-tester`
- `backend-and-language-engineering`
- `coordination-playbook`
- `debugging-and-diagnostics`
- `document-files`
- `documentation-and-doc-ops`
- `frontend-react-and-next`
- `fullstack-engineering`
- `interface-and-design`
- `research-and-reasoning`
- `review-and-pr-operations`
- `security-engineering`
- `systems-architecture`
- `testing-and-verification`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
