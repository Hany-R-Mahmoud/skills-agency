---
name: model-evaluation-support
description: Use optional external model-backed capabilities to support evaluation, comparison, or artifact generation for AI workflows without making vendor tooling the center of the system design.
---

Use this mode when external model access helps evaluate prompts, outputs, or
media-dependent AI workflows.

## Guardrails

- keep vendor-specific helpers optional
- use them to support evaluation, not to hide weak system design
