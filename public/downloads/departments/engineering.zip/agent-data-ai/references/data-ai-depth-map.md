# Data AI Depth Map

Use this reference to deepen `agent-data-ai` with stronger RAG,
prompt-engineering, and ML workflow heuristics.

## RAG And Retrieval

- retrieval quality depends on corpus hygiene, chunking, indexing, and query
  shaping together
- evaluate recall and grounding, not just whether the answer sounds fluent

## Prompt Systems

- treat prompts as versioned system assets, not throwaway strings
- define regression examples for prompts that matter operationally

## ML Workflows

- distinguish experimentation, training, and serving responsibilities clearly
- make data freshness, feedback loops, and evaluation cadence explicit
