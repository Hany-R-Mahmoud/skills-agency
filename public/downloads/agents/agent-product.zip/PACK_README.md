# Agent pack for agent-product

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-product`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
