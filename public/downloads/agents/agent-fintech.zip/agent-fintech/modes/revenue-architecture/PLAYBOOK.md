---
name: revenue-architecture
description: Shape sales motion, pipeline strategy, proposals, and deal structure.
path: skills/agent-fintech/modes/revenue-architecture/PLAYBOOK.md
tags:
  - fintech
  - sales
  - revenue
---

# Revenue Architecture

## Scope

Use this mode for sales discovery, account strategy, proposal narratives,
pipeline analysis, deal coaching, and revenue-motion design.

## Instructions

- Start with buyer problem, urgency, and qualification before solution detail.
- Treat pipeline quality as more important than pipeline volume.
- Make deal risks explicit: weak discovery, no economic buyer, unclear process,
  thin champion, or poor technical fit.
- Prefer concrete next-step guidance over generic sales motivation.
- Connect technical fit and commercial fit back to business outcomes.

## Typical Outputs

- discovery plan
- deal strategy
- pipeline diagnosis
- proposal narrative
- next-step revenue plan
