---
name: growth-marketing
description: Plan acquisition, marketing channels, paid media, and scalable growth systems.
path: skills/agent-fintech/modes/growth-marketing/PLAYBOOK.md
tags:
  - fintech
  - growth
  - marketing
---

# Growth Marketing

## Scope

Use this mode for channel strategy, paid-media planning, content distribution,
growth loops, audience targeting, and acquisition system design.

## Instructions

- Match channel choice to audience behavior and economics, not trendiness.
- Prefer repeatable channel logic over one-off hacks.
- Make CAC, payback, and incrementality assumptions explicit.
- Respect platform-specific behavior instead of copying content or campaign
  structure blindly across channels.
- Keep creative, targeting, and budget strategy connected.

## Typical Outputs

- channel plan
- paid-media strategy
- growth loop design
- audience and message map
- budget allocation rationale
