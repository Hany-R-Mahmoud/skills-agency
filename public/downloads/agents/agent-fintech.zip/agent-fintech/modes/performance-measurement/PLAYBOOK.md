---
name: performance-measurement
description: Audit and improve tracking, attribution, media performance, and commercial analytics.
path: skills/agent-fintech/modes/performance-measurement/PLAYBOOK.md
tags:
  - fintech
  - measurement
  - attribution
---

# Performance Measurement

## Scope

Use this mode for tracking design, attribution logic, paid-media audits, funnel
analytics, dashboard planning, and measurement reliability checks.

## Instructions

- Bad tracking is worse than missing tracking if it drives wrong decisions.
- Start by checking whether the numbers are trustworthy before optimizing from
  them.
- Separate reporting convenience from causal confidence.
- Prioritize the measurements that directly affect spend, bidding, and
  commercial decisions.
- Call out where attribution is directional rather than definitive.

## Typical Outputs

- tracking audit
- attribution review
- media audit
- measurement plan
- dashboard or KPI framework
