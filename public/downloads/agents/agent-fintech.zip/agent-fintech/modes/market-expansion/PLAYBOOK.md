---
name: market-expansion
description: Plan cross-border go-to-market, localization, and region-specific channel strategy.
path: skills/agent-fintech/modes/market-expansion/PLAYBOOK.md
tags:
  - fintech
  - expansion
  - localization
---

# Market Expansion

## Scope

Use this mode for market entry strategy, cross-border growth planning,
localization, regional channel adaptation, and expansion sequencing.

## Instructions

- Treat localization as operating-model adaptation, not just translation.
- Match platform, message, and funnel design to local user behavior.
- Separate structural market differences from temporary channel trends.
- Make resource requirements and execution complexity explicit.
- Prefer a phased market-entry sequence over all-at-once expansion.

## Typical Outputs

- market entry brief
- localization strategy
- channel adaptation plan
- phased expansion roadmap
- expansion risk notes
