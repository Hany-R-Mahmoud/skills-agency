---
name: fintech-foundation
description: Shared foundation for commercial framing, financial tradeoffs, and risk-aware decision support inside agent-fintech.
path: skills/agent-fintech/modes/fintech-foundation/PLAYBOOK.md
tags:
  - fintech
  - foundation
  - business
  - strategy
---

# Fintech Foundation

## Scope

Use this playbook first for `agent-fintech` tasks. It sets the baseline for
business framing, evidence handling, and output shaping before any specialized
mode is applied.

## Instructions

- Lead with the business decision, not the tactic.
- Separate facts, assumptions, projections, and recommendations.
- Make revenue, margin, cash, and risk implications legible when relevant.
- Prefer decision-ready artifacts over broad commercial brainstorming.
- State confidence clearly when data quality, attribution, or market evidence
  is weak.

## Context Gathering Protocol

Gather only what materially affects the call:

- business model and offer
- target segment or buyer
- channel or market in question
- revenue goal, efficiency goal, or financial constraint
- measurement quality and source reliability
- regulatory, tax, or platform-policy considerations

If context is missing, make a reasonable assumption and label it clearly unless
the risk of guessing is high.

## Quality Checks

- Is the decision clearly stated?
- Are the key tradeoffs visible?
- Is the recommendation grounded in evidence rather than channel folklore?
- Would an operator know what to do next?
