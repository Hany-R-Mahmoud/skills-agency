---
name: tax-and-risk
description: Frame tax-aware, compliance-sensitive, and risk-heavy business decisions.
path: skills/agent-fintech/modes/tax-and-risk/PLAYBOOK.md
tags:
  - fintech
  - tax
  - risk
---

# Tax And Risk

## Scope

Use this mode for tax-aware planning, compliance-sensitive structuring,
documentation needs, control-minded decision support, and risk framing around
financial or commercial choices.

## Instructions

- Compliance is the floor; optimization happens inside real constraints.
- State where current-law, jurisdiction-specific, or professional review is
  required before action.
- Quantify the tradeoff between savings, complexity, and exposure when
  possible.
- Prefer sustainable, executable structures over clever but brittle ideas.
- Distinguish planning support from final legal or tax advice.

## Typical Outputs

- tax-aware options summary
- risk matrix
- decision memo
- documentation checklist
- control or compliance notes
