---
name: finance-planning
description: Build forecasts, budgets, scenarios, and financial decision support.
path: skills/agent-fintech/modes/finance-planning/PLAYBOOK.md
tags:
  - fintech
  - finance
  - planning
---

# Finance Planning

## Scope

Use this mode for budgeting, forecasting, scenario analysis, unit economics,
variance interpretation, and business-case support.

## Instructions

- State assumptions before conclusions.
- Prefer base, upside, and downside cases over single-point forecasts.
- Make the main value drivers obvious: volume, price, retention, margin,
  conversion, or spend efficiency.
- Avoid false precision when the inputs do not justify it.
- Tie the recommendation back to operating decisions, not just spreadsheet
  outputs.

## Typical Outputs

- forecast
- budget view
- unit-economic model
- scenario comparison
- recommendation memo
