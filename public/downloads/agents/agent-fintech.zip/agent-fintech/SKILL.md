---
name: agent-fintech
description: Unified revenue, growth, and finance decision-making entry point for this skill pack. Use when Codex should shape sales strategy, marketing and paid media plans, measurement systems, financial analysis, tax-aware planning, or market expansion through one local entry point.
path: .codex/skills/agent-fintech/SKILL.md
tags:
  - agent
  - fintech
  - revenue
  - growth
  - finance
---

# Agent Fintech

Provide a single public entry point for this repository's revenue, growth, and
finance work. Act as a router plus executor: choose the smallest set of
internal modes needed, sequence them well, and avoid loading irrelevant
guidance.

Do not treat every imported sales, finance, paid-media, or marketing specialty
as a public picker entry. Keep the public surface thin and move specialized
behavior into private modes and references.

This skill is independent. It should stand on its own as the surface for
commercial strategy, acquisition, measurement, financial planning, and
risk-aware business decisions.

## Invocation Contract

Invoke this skill directly as `$agent-fintech` whenever the prompt is about:

- sales motion, pipeline strategy, proposals, discovery, or deal shaping
- marketing strategy, channel mix, content distribution, or growth planning
- paid media planning, audit, tracking, attribution, or budget allocation
- funnel performance, lifecycle metrics, or commercial measurement systems
- financial analysis, forecasting, budgeting, unit economics, or planning
- tax-aware planning, compliance-sensitive structuring, or risk-aware financial
  decisions
- market expansion, cross-border go-to-market, or localized growth strategy

When explicitly invoked, do not ask the user to choose internal modes unless
there is a real strategic tradeoff. Infer the likely path from the prompt, map
it to the minimum useful mode set, and proceed.

The user should not need to know or name the internal modes. Treat them as
private implementation details.

## Use This Skill For

- shaping revenue strategy across sales, acquisition, retention, and finance
- designing sales processes, discovery plans, proposal narratives, or pipeline
  interventions
- planning marketing and paid acquisition with explicit channel and budget
  logic
- auditing or improving tracking, attribution, funnel measurement, and growth
  reporting
- building forecasts, budgets, scenario models, and unit-economic views for
  decision support
- evaluating tax-aware or compliance-sensitive business decisions at a planning
  level
- adapting go-to-market strategy for new markets, including region-specific
  channel behavior and localization

## Do Not Use This Skill For

- product implementation or software engineering tasks
- pure design work with no commercial or financial decision attached
- legal advice presented as final counsel instead of planning support
- generic research tasks with no meaningful revenue, growth, or finance outcome

## Quick Start

If the request sounds like one of these, use the matching route immediately:

- "shape the sales motion or deal":
  `fintech-foundation`, then `revenue-architecture`
- "plan marketing or paid growth":
  `fintech-foundation`, then `growth-marketing`
- "audit tracking, media, or attribution":
  `fintech-foundation`, then `performance-measurement`
- "build the forecast or financial view":
  `fintech-foundation`, then `finance-planning`
- "think through taxes, controls, or compliance-sensitive finance":
  `fintech-foundation`, then `tax-and-risk`
- "plan expansion into a new market":
  `fintech-foundation`, then `market-expansion`

If the request mixes several of these, choose one primary mode and add only the
minimum supporting modes needed to finish the job coherently.

## Core Workflow

1. Inspect the request and classify it:
   - revenue motion and pipeline
   - growth and acquisition
   - measurement and attribution
   - financial planning and modeling
   - tax and risk-sensitive structuring
   - market expansion and localization
2. Load `modes/fintech-foundation/PLAYBOOK.md` first for shared business
   framing, evidence discipline, and risk handling.
3. Choose the minimum supporting modes from `references/skill-map.md` and
   `references/request-recipes.md`.
4. Execute in a sane order:
   - define the business decision
   - gather the evidence that materially changes the call
   - make tradeoffs explicit
   - produce the commercial or financial artifact
   - name residual risk and the next validation step
5. Keep the output cohesive. If multiple modes are used, resolve conflicts
   instead of stacking contradictory advice.

## Automatic Routing Rule

When the prompt contains revenue, growth, or finance intent but does not
specify a mode:

- infer the dominant commercial intent from the request
- choose one primary mode
- add only the minimum supporting modes needed
- continue without asking the user to pick from internal skills

Escalate only when the prompt genuinely points to incompatible outcomes, such
as "maximize near-term acquisition volume" and "optimize entirely for cash
preservation" without any stated priority.

## Routing Rules

Default to these bundles:

- Sales strategy, proposal shaping, or pipeline diagnosis:
  `fintech-foundation` plus `revenue-architecture`; add
  `performance-measurement` when the decision depends on funnel or pipeline
  data
- Growth strategy, channel planning, or paid-media direction:
  `fintech-foundation` plus `growth-marketing`; add
  `performance-measurement` when attribution or tracking confidence matters
- Tracking audits, attribution fixes, or commercial analytics:
  `fintech-foundation` plus `performance-measurement`; add
  `growth-marketing` or `revenue-architecture` when the measurement issue is
  tied to a channel or sales motion
- Forecasts, budgets, business cases, or unit economics:
  `fintech-foundation` plus `finance-planning`; add
  `performance-measurement` when operating metrics drive the model
- Tax-aware or control-sensitive planning:
  `fintech-foundation` plus `tax-and-risk`; add `finance-planning` when the
  issue includes financial modeling or scenario comparison
- New-market or cross-border expansion:
  `fintech-foundation` plus `market-expansion`; add `growth-marketing`,
  `revenue-architecture`, or `tax-and-risk` as needed

If a request is narrow, stay narrow. Do not pull in sales, media, tax, and
finance modes by default when one lane is enough.

Prefer a primary mode and at most 2-4 supporting modes for most tasks.

## Conflict Resolution

Some modes pull in opposite directions. Resolve them deliberately:

- `growth-marketing` vs `finance-planning`:
  test for efficient growth, not just top-line expansion; make payback and cash
  assumptions explicit
- `revenue-architecture` vs `performance-measurement`:
  do not redesign the motion before confirming what the data actually says
- `tax-and-risk` vs speed:
  move quickly when possible, but flag where current-law verification or expert
  review is required before acting
- `market-expansion` vs copy-paste GTM:
  prefer market-native adaptation over channel reuse without localization

## Default Execution Standards

Regardless of which modes are selected:

- separate facts, assumptions, hypotheses, and recommendations
- lead with the decision and the business consequence
- make unit economics, margin, and cash implications legible when relevant
- treat attribution and tracking quality as part of decision quality
- avoid false precision in forecasts or market sizing
- use compliance, tax, and platform-policy guidance to reduce risk, not to
  overstate certainty

## User Request Translation

Users often describe outcomes, not modes. Translate intent like this:

- "how do we close this deal" usually means `revenue-architecture`
- "how do we grow this channel" usually means `growth-marketing`
- "can we trust this tracking or ROAS" usually means
  `performance-measurement`
- "build the model or budget" usually means `finance-planning`
- "what are the tax or compliance implications" usually means `tax-and-risk`
- "how do we enter this market" usually means `market-expansion`

If the prompt mixes several commercial desires, prioritize in this order unless
the user says otherwise:

1. clarify the business goal and constraint
2. ground the call in reliable measurement or evidence
3. make the revenue, margin, and risk tradeoffs explicit
4. produce the smallest useful decision artifact
5. define the next validation or execution step

## Output Shape

Match the task:

- For strategy work:
  summarize the chosen modes, then present the framework, rationale, and next
  business moves
- For analysis work:
  present the drivers, assumptions, scenarios, and recommendation
- For audits:
  present the highest-impact findings first, then specific fixes

Always name the modes you chose when that helps the user understand why the
result was structured a certain way.

## Reference

Use these references as needed:

- `references/skill-map.md`: compact map of all internal modes
- `references/request-recipes.md`: common user phrasing to mode bundles

Read only the relevant entries rather than reloading every internal mode in
full.
