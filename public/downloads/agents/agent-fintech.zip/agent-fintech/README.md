# Agent Fintech Guide

`agent-fintech` is the public revenue, growth, and finance decision-making
entry point in this skill pack.

## What It Does

It helps shape sales strategy, marketing plans, paid media, measurement
systems, financial analysis, tax-aware planning, and market expansion through
one public surface.

It is best at:

- sales and revenue strategy
- marketing and paid growth
- measurement and attribution
- finance planning and modeling
- tax-aware and risk-aware planning
- market expansion

## How To Use It

Call it with:

- `/agent-fintech`
- `$agent-fintech`

Use it when:

- the request is about revenue motion, growth, paid media, funnel performance,
  or attribution
- you need forecasts, budgets, unit economics, or finance planning
- the work includes tax-aware planning, compliance-sensitive decisions, or
  market expansion

## How It Works

It reads the business decision, starts from `fintech-foundation`, chooses the
smallest useful supporting modes, and returns one cohesive commercial or
financial artifact.

## Internal Playbooks

- `Fintech Foundation` (`fintech-foundation`): shared business framing,
  evidence discipline, and risk handling
- `Revenue Architecture` (`revenue-architecture`): sales motion, pipeline
  strategy, and deal shaping
- `Growth Marketing` (`growth-marketing`): channel mix, growth planning, and
  paid acquisition direction
- `Performance Measurement` (`performance-measurement`): attribution, tracking,
  and commercial analytics
- `Finance Planning` (`finance-planning`): models, forecasts, budgets, and
  unit economics
- `Tax and Risk` (`tax-and-risk`): tax-aware and compliance-sensitive planning
- `Market Expansion` (`market-expansion`): localized go-to-market and new
  market strategy

## Short Version

Use `/agent-fintech` or `$agent-fintech` when the decision is commercial,
growth-related, or finance-shaped rather than implementation-shaped.
