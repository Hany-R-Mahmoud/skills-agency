# Skill Map

Use this file to route a request to the minimum useful subset of the internal
business modes bundled inside `agent-fintech`.

## Foundation

- `fintech-foundation`: shared business framing, evidence standards, commercial
  tradeoff rules, and risk handling

Always start with `fintech-foundation`.

## Modes

- `revenue-architecture`: sales discovery, proposals, deal strategy, account
  planning, pipeline diagnostics, and commercial motion design
- `growth-marketing`: marketing strategy, paid media, channel planning, content
  distribution, growth loops, and acquisition logic
- `performance-measurement`: tracking, attribution, media audits, funnel
  analytics, pipeline measurement, and reporting confidence
- `finance-planning`: budgeting, forecasting, business cases, unit economics,
  scenario models, and planning support
- `tax-and-risk`: tax-aware planning, controls, compliance-sensitive decisions,
  and risk framing
- `market-expansion`: cross-border GTM, localization strategy, regional channel
  behavior, and expansion sequencing

## Recommended Bundles

- Shape a sales or deal strategy:
  `fintech-foundation`, then `revenue-architecture`
- Plan growth or paid media:
  `fintech-foundation`, then `growth-marketing`, often with
  `performance-measurement`
- Audit performance or tracking:
  `fintech-foundation`, then `performance-measurement`
- Build a forecast or business case:
  `fintech-foundation`, then `finance-planning`
- Review tax-aware or risk-sensitive choices:
  `fintech-foundation`, then `tax-and-risk`, often with `finance-planning`
- Plan market entry:
  `fintech-foundation`, then `market-expansion`, often with
  `growth-marketing`

## Anti-Pattern

Do not activate every commercial mode just because a request touches revenue.
Choose the smallest useful bundle that can produce a coherent result.
