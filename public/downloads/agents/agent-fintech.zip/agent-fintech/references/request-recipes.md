# Request Recipes

Use this file when the user describes a commercial or financial outcome instead
of naming a specific internal mode.

## Revenue

- "help with discovery or the sales call":
  start with `fintech-foundation`; add `revenue-architecture`
- "shape the proposal or deal":
  start with `fintech-foundation`; add `revenue-architecture`
- "analyze the pipeline":
  start with `fintech-foundation`; add `revenue-architecture`; often add
  `performance-measurement`

## Growth

- "plan paid media":
  start with `fintech-foundation`; add `growth-marketing`
- "grow this channel":
  start with `fintech-foundation`; add `growth-marketing`
- "audit the ad account":
  start with `fintech-foundation`; add `performance-measurement`; often add
  `growth-marketing`

## Measurement

- "fix tracking or attribution":
  start with `fintech-foundation`; add `performance-measurement`
- "can we trust these numbers":
  start with `fintech-foundation`; add `performance-measurement`
- "build the dashboard or measurement plan":
  start with `fintech-foundation`; add `performance-measurement`

## Finance

- "build the forecast":
  start with `fintech-foundation`; add `finance-planning`
- "analyze the budget or unit economics":
  start with `fintech-foundation`; add `finance-planning`
- "compare scenarios":
  start with `fintech-foundation`; add `finance-planning`

## Tax, Risk, And Expansion

- "what are the tax implications":
  start with `fintech-foundation`; add `tax-and-risk`
- "how should we structure this from a compliance angle":
  start with `fintech-foundation`; add `tax-and-risk`
- "how do we enter this market":
  start with `fintech-foundation`; add `market-expansion`
- "localize this for China":
  start with `fintech-foundation`; add `market-expansion`

## Guardrail

Do not map vague prompts to every mode. Pick the most likely primary mode, then
add only the supporting modes needed to finish the job well.
