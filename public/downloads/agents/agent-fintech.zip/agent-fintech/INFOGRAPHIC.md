# Agent Fintech Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for AGENT FINTECH inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the department accent that best matches the website placement for this commercial strategy specialist
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: AGENT FINTECH
- Subtitle: Revenue, growth, and finance decision-making specialist
- Commands:
  - /agent-fintech
  - $agent-fintech
- One-line value:
  Shapes sales strategy, marketing and paid media plans, measurement systems, financial analysis, tax-aware planning, and market expansion through one public entry point.
- Capabilities:
  - sales and revenue strategy
  - marketing and paid growth
  - measurement and attribution
  - finance planning and modeling
  - tax-aware and risk-aware planning
  - market expansion
- How it works:
  - reads the business decision
  - starts with fintech-foundation
  - routes to the smallest useful internal playbooks
  - returns one cohesive commercial or financial artifact
- Best used when:
  - the request is about revenue motion, growth, paid media, funnel performance, or attribution
  - you need forecasts, budgets, unit economics, or finance planning
  - the work includes tax-aware planning, compliance-sensitive decisions, or market expansion
- Bottom summary:
  fintech-foundation, revenue-architecture, growth-marketing, performance-measurement, finance-planning, tax-and-risk, market-expansion
- Footer note:
  You ask for the outcome. Agent Fintech chooses the right business lane.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
