# Config Risk Escalation

Use this reference when a general review uncovers risk in prompts, hooks, tool
permissions, integration configs, or assistant runtime settings.

## Escalate To `agent-security` When
- findings involve secrets, credentials, or tokens
- tool permissions appear broader than the task requires
- hooks or command templates may allow injection
- MCP or external integrations weaken trust boundaries
- risky bypass flags or unsafe defaults are part of the change

## Reviewer Job
- Call out the concrete risk with file references.
- Keep the finding focused on behavior and exposure.
- Hand off deep threat analysis and remediation design to `agent-security`.

## Avoid
- turning a general review into a full security audit by default
- downplaying config risk because the change is "just metadata"
