# Eval Regression Patterns

Use this reference when verification is closer to capability evaluation than
traditional test execution.

## Pattern

- define the capability under test explicitly
- keep a regression set of representative examples
- compare against prior behavior, not just current intuition
- report both wins and regression risk
