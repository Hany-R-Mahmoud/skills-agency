# Changelog Writing

Use this reference when turning technical changes into release notes or
user-facing changelog entries.

## Purpose
Translate developer work into language that helps users understand what changed
and why it matters.

## Content Rules
- Group changes into user-meaningful categories such as features,
  improvements, fixes, and breaking changes.
- Emphasize outcomes and benefits, not commit-level implementation detail.
- Filter out internal-only work unless it affects users directly.
- Keep the writing clear, specific, and easy to scan.

## Rewrite Heuristics
- Technical commit summary -> user-facing impact
- Internal refactor -> usually omit unless it unlocks visible behavior
- Bug fix -> explain the user problem that was resolved
- Performance change -> describe the noticeable improvement

## Good Questions
- What changed from the user's point of view?
- Why should the reader care?
- Is this a feature, improvement, fix, or migration concern?
- Is this internal noise that should stay out of the changelog?
