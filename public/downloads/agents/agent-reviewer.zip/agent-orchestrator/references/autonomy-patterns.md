# Autonomy Patterns

Use this reference when designing long-running or semi-autonomous workflows that
must keep momentum without losing verification or operator control.

## Purpose
Add structure to autonomous execution without importing a full product-specific
runtime or unsafe "never ask questions" behavior.

## Useful Patterns

### Explicit execution loop
- Use a named loop such as:
  - reason
  - act
  - reflect
  - verify
- Require each cycle to produce evidence, not just progress claims.
- Make failure handling explicit: retry with a changed approach, simplify, or
  escalate.

### Phase-based execution
- Break long workflows into named phases with clear exit conditions.
- Do not advance phases just because work was attempted; require quality gates
  or completion criteria.
- Keep the current phase and next transition legible to the controller.

### Checkpointing
- Capture progress in explicit milestones so work can resume safely.
- Prefer small coherent checkpoints over giant all-or-nothing runs.
- Treat rollback and resume paths as part of orchestration design.

### Human intervention model
- Allow pause, stop, and clarification points.
- Keep collaboration possible even in highly autonomous modes.
- Never adopt blanket rules like "do not ask questions" without considering
  risk, ambiguity, and user intent.

## What To Borrow Carefully
- Structured loops
- Phase transitions
- Explicit checkpoints
- Observable status updates

## What Not To Copy
- Product-specific filesystem state machines
- Unconditional autonomy rules that suppress judgment
- Monolithic runtimes when a playbook or reference is enough
