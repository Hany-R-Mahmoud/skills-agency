# Quality Gate Patterns

Use this reference when a workflow needs structured gates before work is treated
as complete.

## Purpose
Prevent premature completion by separating "code exists" from "the work is
 actually done well enough."

## Gate Design

### Gate types
- spec compliance
- code quality
- verification and tests
- security checks when trust boundaries matter
- release readiness for larger changes

### Gate ordering
- First verify the right thing was built.
- Then verify it was built well.
- Then verify it behaves correctly in execution.

### Severity blocking
- Define which severities block completion.
- Make residual risk explicit when lower-severity issues are deferred.
- Do not silently carry forward high-risk findings.

### Reviewer independence
- Prefer independent review passes for different concerns when the task is
  important enough.
- Keep reviewer goals distinct so feedback is not redundant.

## Practical Guidance
- Use the minimum number of gates that still controls risk.
- Avoid theatrical gate inflation on small tasks.
- Make the pass/fail criteria legible before the work starts.
