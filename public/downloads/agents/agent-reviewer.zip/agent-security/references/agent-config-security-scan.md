# Agent Config Security Scan

Use this reference when reviewing agent, automation, or assistant configuration
for security risks.

## Focus Areas
- prompt files and instruction documents
- tool permission lists and allowlists
- hooks and shell command templates
- MCP or external integration configuration
- hardcoded credentials, tokens, or secrets
- unsafe bypass flags and dangerous defaults

## Common Findings

### Critical
- Hardcoded secrets in config or prompt files
- Unrestricted shell or tool permissions without clear need
- Command injection vectors in hooks or interpolated shell commands
- External integrations configured to run arbitrary code from untrusted sources

### High
- Missing deny lists or weak permission boundaries
- Auto-run instructions that expand prompt injection surface
- Agents with overly broad tool access relative to their role

### Medium
- Silent error suppression that hides failures or abuse
- Risky auto-install behavior in tool or MCP setup
- Missing descriptions or unclear ownership around privileged integrations

## Review Guidance
- Treat configuration as executable policy, not inert metadata.
- Look for least-privilege violations first.
- Prefer environment-variable-based secret handling over literal values.
- Flag dangerous convenience features when they weaken trust boundaries.
- Recommend concrete remediation, not generic alarm.
