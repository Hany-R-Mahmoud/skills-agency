# Agent-First Refactor

This file captures the durable rules behind the current refactor so the repo
does not drift back into picker bloat and duplicate public entries.

## Core Decisions

1. The public surface is agent-first.
2. Internal capability docs stay on disk as `PLAYBOOK.md`.
3. Public picker entries should be rare and intentional.
4. Codex behavior is the primary compatibility target.
5. External repos are reviewed as donors, not bulk-import sources.

## Conflict Rules

1. Workflow fit beats popularity.
2. Existing strong agents beat imported duplicates.
3. Architecture patterns are preferred over content imports.
4. Internalization beats public expansion when the idea is useful but noisy.
5. Runtime compatibility beats elegant restructuring.
6. When merging, review the underlying lines and information carefully. Do not
   append duplicated or low-signal guidance mechanically.
7. Treat overlap of roughly `50-60%` as a default merge signal rather than a
   reason to create a sibling entry.
8. Avoid naming collisions between a public agent and its internal playbook.

## Public Entry Rule

If a capability is already clearly covered by an agent, can be called by that
agent, or is unlikely to be used alone, it does not deserve public picker
space.

## Internalization Rule

If something is useful but not worth a public entry:

- keep it on disk
- convert it to `PLAYBOOK.md`
- reference it from the owning agent
- avoid making it publicly discoverable when possible

## External Repo Review Outcomes

Every candidate repo or entry should end in one of:

- `Adopt`
- `Merge`
- `Internalize`
- `Reject`

## Donor Repo Notes

### `msitarzewski/agency-agents`

- pattern donor only
- useful for role framing, mission/output contracts, and OpenCode subagent ideas
- not suitable for bulk import

### `Donchitos/Claude-Code-Game-Studios`

- system-pattern donor only
- useful for separation of agents, workflows, rules, hooks, and templates
- game-specific roster should not be imported

### `Shubhamsaboo/awesome-llm-apps`

- examples/reference only
- generic skills overlap with stronger local entries
- not suitable for direct adoption

### `JohnRiceML/clawport-ui`

- orchestration/control-plane inspiration
- useful for org maps, memory visibility, activity visibility, and introspection

### `agentscope-ai/agentscope`

- framework inspiration
- useful for abstractions around agents, tools, memory, planning, observability,
  MCP, and A2A

### `slavingia/skills`

- optional founder/business domain donor
- if adopted later, should be exposed as one public agent with internal
  business playbooks instead of many public entries

### `affaan-m/everything-claude-code`

- high-value system donor
- useful for core-vs-niche distinction, cross-platform structure, governance,
  verification, and installation strategy
- should be harvested selectively, not copied wholesale

### `paperclipai/paperclip`

- governance and orchestration inspiration
- useful for org charts, goal alignment, heartbeats, auditability, and
  cost-awareness

## Next-Step Rule

Future growth should come from:

- improving the current public agents
- adding internal playbooks
- creating new public agents only for truly distinct recurring workflows

Not from collecting more standalone public skills by default.
