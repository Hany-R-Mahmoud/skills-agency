# AI Coder Agent Repository

An agent-first repository for Codex, Cursor, and OpenCode.

The public surface is intentionally small: invoke agents from the picker, and
let those agents load the internal playbooks they need. This keeps the `$`
menu shorter, reduces duplication, and pushes routing decisions into the
specialist that owns the task.

![Agent-First Repository Structure](assets/agent-first-repository-structure.png)

Watch the explainer video: [agent-first-repository-structure.mp4](assets/agent-first-repository-structure.mp4)

## What Changed

This repository was refactored from a mixed public `Agent | Skill | Hybrid`
surface into an agent-first operating model:

- only public agents remain visible in the picker
- former public skills were converted into internal `PLAYBOOK.md` documents
- `agent-impeccable` became the public facade for private design modes
- duplicate and noisy utility entries were removed or merged
- the repo is now optimized primarily for Codex, while staying usable from
  OpenCode and adaptable to Cursor

The durable rules behind this refactor are captured in
[AGENT_FIRST_REFACTOR.md](/Users/hanyramadan/.codex/skills/AGENT_FIRST_REFACTOR.md).

## Public Surface

Only the following top-level entries are public picker entries:

- `agent-co-pilot`
- `agent-pilot`
- `agent-orchestrator`
- `agent-implementer`
- `agent-reviewer`
- `agent-tester`
- `agent-debugging`
- `agent-security`
- `agent-docs`
- `agent-history`
- `agent-impeccable`

Everything else is now an internal playbook stored as `PLAYBOOK.md`.

## Operating Model

- Pick an agent, not a playbook.
- Let the selected agent decide which internal playbooks or helper agents to
  load.
- Keep new public entries rare.
- Internalize useful but noisy capabilities instead of adding them to the
  picker.
- Treat external repositories as donors of patterns and workflows, not bulk
  import sources.

## Default Entry Points

- `agent-co-pilot`: small, obvious, low-risk work
- `agent-pilot`: standard through risky coordinated work, with scalable workflow intensity
- `agent-orchestrator`: planning-first and decomposition-first tasks
- `agent-impeccable`: UI, UX, design, polish, critique, and frontend feel

## Internal Playbooks

Internal playbooks remain on disk and are meant to be read by agents, not
selected directly by default. They cover:

- engineering domains such as React, backend, architecture, MCP, security,
  docs, and testing
- UI/design modes used internally by `agent-impeccable`
- operational and automation playbooks under `others/`

See [INDEX.md](/Users/hanyramadan/.codex/skills/INDEX.md) for the current
catalog.

## Structure

```text
skills/
├── INDEX.md
├── AGENT_FIRST_REFACTOR.md
├── assets/
│   └── agent-first-repository-structure.png
├── agent-pilot/
│   └── SKILL.md
├── agent-co-pilot/
│   └── SKILL.md
├── agent-*/
│   └── SKILL.md
├── */PLAYBOOK.md
│   └── internal capability documents
├── agent-impeccable/modes/*/PLAYBOOK.md
└── others/*/PLAYBOOK.md
```

## Refactor Rules

These are the main rules now governing the repo:

1. The public surface is agent-first.
2. Internal capability docs stay on disk as `PLAYBOOK.md`.
3. Public picker entries should be rare and intentional.
4. Codex behavior is the primary compatibility target.
5. Existing strong agents should absorb overlapping external ideas instead of
   spawning sibling entries.
6. Useful but noisy capabilities should be internalized, not exposed.
7. External repos are reviewed through one of four outcomes:
   - `Adopt`
   - `Merge`
   - `Internalize`
   - `Reject`

## Cross-Platform Note

This repo is optimized primarily for Codex. The physical structure stays flat at
the public layer to preserve picker compatibility. OpenCode can still adapt well
to this model, and Cursor can reuse the same content as repo guidance and
supporting assets.

## Contribution Rules

- Add a new public agent only if it clearly deserves picker space.
- Prefer updating an existing agent before adding a sibling with partial
  overlap.
- Prefer internal playbooks over new public entries when the capability is
  specialized, repetitive, or mostly supportive.
- Avoid naming collisions between a public agent and its internal playbook.
- When merging content, review the underlying lines and information carefully
  rather than appending duplicated guidance mechanically.
