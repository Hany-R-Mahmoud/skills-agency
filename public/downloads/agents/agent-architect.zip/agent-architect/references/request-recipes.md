# Request Recipes

Use this file when the user describes an architectural outcome instead of
naming a specific mode.

- "Design the system":
  start with `architecture-foundation`; usually add `backend-architecture`
- "Design the API":
  start with `architecture-foundation`; add `api-architecture`
- "Help with the monorepo":
  start with `architecture-foundation`; add `monorepo-architecture`
- "Should we use events / queues / orchestration here?":
  start with `architecture-foundation`; add `distributed-architecture`
- "Review this architecture":
  start with `architecture-foundation`; add `architecture-review`

## Guardrail

Do not invoke every architecture mode at once. Pick the primary design problem,
then add only the supporting modes needed to resolve it.
