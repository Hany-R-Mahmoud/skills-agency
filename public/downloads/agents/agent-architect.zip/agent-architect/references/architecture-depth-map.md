# Architecture Depth Map

Use this reference to enrich `agent-architect` with deeper architecture lenses
without turning each specialty into a separate public agent.

## API And Schema Design

- define ownership of contracts explicitly
- separate external API shape from internal service interfaces
- plan compatibility and migration before expanding schema complexity

## Microservices And Boundaries

- justify service boundaries with ownership, scaling, or deployment needs
- challenge distributed decomposition when a modular monolith is enough
- make sync vs async interaction tradeoffs explicit

## Monorepo Structure

- keep package boundaries aligned with ownership and release behavior
- prevent dependency sprawl with clear directionality
- optimize build graph clarity and local ergonomics together

## Review Bias

- prefer architecture that is easy to implement, operate, and evolve
- avoid adopting patterns purely because they are fashionable

## Decision Records

- capture major architecture choices in a short ADR-style shape:
  - context
  - decision
  - consequences
- use decision records for changes that affect boundaries, deployment shape, or
  long-lived contracts

## Quality Attributes

- make the governing quality attributes explicit before settling the design:
  - reliability
  - performance
  - security
  - operability
  - changeability
- explain which attributes are being optimized and which are intentionally
  traded off
