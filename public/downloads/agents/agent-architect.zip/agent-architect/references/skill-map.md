# Skill Map

Use this file to route a request to the minimum useful subset of the internal
architecture modes bundled inside `agent-architect`.

## Foundation

- `architecture-foundation`: `modes/architecture-foundation/PLAYBOOK.md`,
  shared discovery, constraints framing, and architecture decision rules

Always start with `architecture-foundation`.

## Design Modes

- `backend-architecture`: `modes/backend-architecture/PLAYBOOK.md`, service
  boundaries, data ownership, and backend topology
- `api-architecture`: `modes/api-architecture/PLAYBOOK.md`, API contracts,
  interface boundaries, and schema strategy
- `monorepo-architecture`: `modes/monorepo-architecture/PLAYBOOK.md`,
  workspace topology, package boundaries, and developer ergonomics
- `distributed-architecture`: `modes/distributed-architecture/PLAYBOOK.md`,
  event-driven flows, orchestration, async coordination, and failure semantics
- `architecture-review`: `modes/architecture-review/PLAYBOOK.md`, consistency
  review against intended architecture and scaling assumptions

## Recommended Bundles

- Design a backend system:
  `architecture-foundation`, then `backend-architecture`
- Design service interfaces:
  `architecture-foundation`, then `api-architecture`
- Shape a monorepo:
  `architecture-foundation`, then `monorepo-architecture`
- Evaluate distributed patterns:
  `architecture-foundation`, then `distributed-architecture`
- Review an architecture:
  `architecture-foundation`, then `architecture-review`
