---
name: distributed-architecture
description: Evaluate or design event-driven and distributed workflows, orchestration boundaries, retries, and failure semantics.
---

Use this mode when the architecture problem involves queues, events, sagas,
workflow engines, or multi-service coordination.

Focus on:

- orchestration vs choreography
- retry and compensation strategy
- idempotency
- observability requirements
- consistency tradeoffs
