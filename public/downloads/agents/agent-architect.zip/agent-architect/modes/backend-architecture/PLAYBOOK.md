---
name: backend-architecture
description: Design or refactor backend service boundaries, data ownership, and system topology with explicit tradeoffs and scaling assumptions.
---

Use this mode for service decomposition, backend topology, and ownership
decisions.

Focus on:

- service boundaries
- data ownership
- sync vs async coordination
- failure isolation
- migration path from current state
