---
name: architecture-review
description: Review a proposed or implemented architecture for coherence, scaling fit, operability, and alignment with constraints.
---

Use this mode when the main need is judgment rather than fresh design.

Focus on:

- mismatch between intended and implemented boundaries
- hidden coupling
- operability and failure handling gaps
- maintainability and migration risk
