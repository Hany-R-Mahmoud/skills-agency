---
name: monorepo-architecture
description: Design monorepo topology, package boundaries, build graph strategy, and workspace ergonomics with an eye toward long-term maintainability.
---

Use this mode for workspace structure, package layering, and tooling boundary
questions.

Focus on:

- package boundaries
- dependency flow
- shared tooling
- caching and build graph implications
- team ergonomics and ownership
