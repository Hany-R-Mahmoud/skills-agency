---
name: architecture-foundation
description: Shared foundation for architecture discovery, constraints framing, and decision-quality standards before any architecture-specific mode runs.
---

Use this playbook before any other `agent-architect` mode.

## Core Goal

Establish enough context to make architecture decisions deliberately:

- current system shape
- scale, reliability, and change-rate expectations
- operational constraints
- ownership and team boundaries
- decision reversibility

## Rules

- inspect the current repository and boundaries before proposing new ones
- separate discovered facts from assumptions and preferences
- prefer explicit tradeoffs over one-size-fits-all architecture slogans
- optimize for operability and implementation fit, not just purity
