---
name: api-architecture
description: Shape API contracts, schemas, compatibility strategy, and interface boundaries that are clear for both clients and implementers.
---

Use this mode for REST, GraphQL, internal contracts, and boundary design.

Focus on:

- resource or schema shape
- versioning or evolution strategy
- authorization surfaces
- idempotency and error semantics
- ownership of contract changes
