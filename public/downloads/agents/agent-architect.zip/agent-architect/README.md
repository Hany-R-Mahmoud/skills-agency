# Architect Guide

`agent-architect` is the public architecture and system-design entry point in
this skill pack.

## What It Does

It helps shape boundaries, APIs, monorepos, and distributed workflows before
implementation locks the wrong structure in place.

It is best at:

- system design
- API boundaries
- monorepo strategy
- distributed workflow design

## How To Use It

Call it with:

- `/agent-architect`
- `$agent-architect`

Use it when:

- you need to shape service boundaries, API contracts, or ownership lines
- a refactor, scaling decision, or distributed workflow needs architectural
  judgment first
- you want an architecture review before implementation hardens the wrong shape

## How It Works

It reads the request, chooses the smallest useful architecture lanes, makes the
tradeoffs explicit, and returns a clearer structural direction.

## Internal Playbooks

- `Architecture Foundation` (`architecture-foundation`): frames constraints,
  decision points, and the right depth for the design conversation
- `Backend Architecture` (`backend-architecture`): covers service shape,
  ownership, and backend system structure
- `API Architecture` (`api-architecture`): clarifies contracts, interface
  boundaries, and schema responsibility
- `Distributed Architecture` (`distributed-architecture`): helps with events,
  coordination patterns, and multi-service behavior

## Short Version

Use `/agent-architect` or `$agent-architect` when the biggest question is the
shape of the system, not the code inside it.
