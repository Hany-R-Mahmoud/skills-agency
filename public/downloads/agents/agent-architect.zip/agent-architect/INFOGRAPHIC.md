# Architect Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for ARCHITECT inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Engineering and Systems department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: ARCHITECT
- Subtitle: System design lead for boundaries, contracts, and structural decisions
- Commands:
  - /agent-architect
  - $agent-architect
- One-line value:
  The architecture specialist for service boundaries, APIs, monorepos, and distributed workflows. Keeps design choices explicit before implementation locks them in.
- Capabilities:
  - system design
  - API boundaries
  - monorepo strategy
  - distributed workflow design
- How it works:
  - reads the architectural question
  - chooses the smallest useful architecture lanes
  - makes the tradeoffs explicit
  - returns a clearer structural direction
- Best used when:
  - you need to shape service boundaries, API contracts, or ownership lines
  - a refactor, scaling decision, or distributed workflow needs architectural judgment first
  - you want an architecture review before implementation hardens the wrong shape
- Bottom summary:
  architecture-foundation, backend-architecture, api-architecture, distributed-architecture
- Footer note:
  You ask for the outcome. Architect clarifies the system shape.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
