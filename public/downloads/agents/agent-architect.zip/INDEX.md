# Index

This index reflects the current agent-first operating model.

## Public Agents

| Name | Kind | Primary job | Uses internal playbooks for |
| --- | --- | --- | --- |
| `agent-co-pilot` | Agent | Lightweight coordination for small tasks | narrow domain depth, quick routing, lightweight validation |
| `agent-pilot` | Agent | Scalable coordination for normal through risky feature work | domain depth, sequencing, review, verification, gates, artifact discipline |
| `agent-orchestrator` | Agent | Framing, decomposition, sequencing, and routing | architecture, research, fullstack planning, domain lookup |
| `agent-implementer` | Agent | Code changes and user-facing implementation | frontend, backend, fullstack, design-system fit, testing expectations |
| `agent-reviewer` | Agent | Correctness, regression, maintainability, PR review judgment | PR operations, security review patterns, verification interpretation |
| `agent-tester` | Agent | Test strategy, execution, and verification evidence | testing, diagnostics, browser verification, cross-layer validation |
| `agent-debugging` | Agent | Reproduce-first debugging and root-cause work | diagnostics, testing, research |
| `agent-security` | Agent | Security-specific review and trust-boundary analysis | AppSec playbooks, architecture review, review operations |
| `agent-docs` | Agent | Documentation, summaries, release-facing explanation | docs operations, research, reporting and summary patterns |
| `agent-history` | Agent | Conversation continuity and structured handoff | briefing templates and continuity references |
| `agent-impeccable` | Agent | Public UI/design facade and router | internal design modes, critique/audit, polish, hardening, optimization |

## Internal Engineering Playbooks

These playbooks are intentionally internal and are meant to be loaded by public
agents when needed.

| Folder | Document | Main use |
| --- | --- | --- |
| `coordination-playbook` | `PLAYBOOK.md` | multi-agent workflow design and routing strategy |
| `ai-systems-engineering` | `PLAYBOOK.md` | LLM systems, RAG, prompting, ML pipelines |
| `atlassian-mcp` | `PLAYBOOK.md` | Jira and Confluence integration |
| `backend-and-language-engineering` | `PLAYBOOK.md` | TS, JS, Python, NestJS, CLI implementation |
| `chatgpt-apps` | `PLAYBOOK.md` | ChatGPT Apps SDK work |
| `debugging-and-diagnostics` | `PLAYBOOK.md` | runtime debugging patterns |
| `design-to-code` | `PLAYBOOK.md` | Figma/Stitch to code workflows |
| `doc` | `PLAYBOOK.md` | document operations and fidelity guidance |
| `document-files` | `PLAYBOOK.md` | office-style document workflows |
| `documentation-and-doc-ops` | `PLAYBOOK.md` | docs systems, specs, docstrings |
| `figma` | `PLAYBOOK.md` | Figma integration and implementation |
| `flow` | `PLAYBOOK.md` | Flow type-checking guidance |
| `frontend-react-and-next` | `PLAYBOOK.md` | React and Next.js implementation patterns |
| `fullstack-engineering` | `PLAYBOOK.md` | cross-layer delivery guidance |
| `game-developer` | `PLAYBOOK.md` | game-development workflows |
| `hany-migrate-backup` | `PLAYBOOK.md` | migration and backup workflow |
| `interface-and-design` | `PLAYBOOK.md` | UI/UX and design-system direction |
| `mcp-development` | `PLAYBOOK.md` | MCP design and integration |
| `mobile-engineering` | `PLAYBOOK.md` | mobile development guidance |
| `openai-docs` | `PLAYBOOK.md` | official OpenAI documentation lookup |
| `platform-engineering` | `PLAYBOOK.md` | deployment, infra, observability |
| `prompt-optimizer` | `PLAYBOOK.md` | prompt refinement |
| `research-and-reasoning` | `PLAYBOOK.md` | deep research and adversarial reasoning |
| `review-and-pr-operations` | `PLAYBOOK.md` | PR process and review operations |
| `security-engineering` | `PLAYBOOK.md` | application and infra security patterns |
| `systems-architecture` | `PLAYBOOK.md` | system and interface architecture |
| `testing-and-verification` | `PLAYBOOK.md` | testing strategy and validation workflows |
| `vercel-deploy` | `PLAYBOOK.md` | Vercel deployment workflow |
| `visual-artifacts` | `PLAYBOOK.md` | generated visual artifact work |

## Internal Design Modes

The following are private implementation modes for `agent-impeccable`:

- `adapt`
- `animate`
- `arrange`
- `audit`
- `bolder`
- `clarify`
- `colorize`
- `critique`
- `delight`
- `distill`
- `extract`
- `frontend-design`
- `harden`
- `normalize`
- `onboard`
- `optimize`
- `overdrive`
- `polish`
- `quieter`
- `teach-impeccable`
- `typeset`

All live under:
- [agent-impeccable/modes](/Users/hanyramadan/.codex/skills/agent-impeccable/modes)

## Internal Operational Playbooks

These are still useful, but intentionally not public picker entries:

| Folder | Document | Notes |
| --- | --- | --- |
| `others/bug-triage` | `PLAYBOOK.md` | issue classification and Plane routing |
| `others/codebase-map` | `PLAYBOOK.md` | structural repo map maintenance |
| `others/context-manager` | `PLAYBOOK.md` | durable automation context |
| `others/error-handler` | `PLAYBOOK.md` | automation failure handling |
| `others/github-webhook-router` | `PLAYBOOK.md` | GitHub webhook normalization and routing |
| `others/pr-review-resolver` | `PLAYBOOK.md` | repo-specific PR review resolution loop |
| `others/speech-qa` | `PLAYBOOK.md` | ASR / recitation QA workflow |
| `others/stale-task-detector` | `PLAYBOOK.md` | backlog staleness detection |
| `others/system-monitor` | `PLAYBOOK.md` | local automation health monitoring |

## Removed During Agent-First Refactor

The following noise-heavy or duplicate families were removed from the public
surface during this refactor:

- `agent-impeccable` standalone internal modes as public skills
- duplicate report/review helpers under `others/`
- `speckit-*` from this repo scope
