# Agent pack for agent-architect

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-architect`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
