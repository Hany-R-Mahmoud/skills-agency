---
name: platform-engineering
description: Design and operate deployment, infrastructure, observability, and resilience systems. Use for cloud architecture, CI/CD, IaC, monitoring, and chaos or resilience planning.
path: skills/platform-engineering/PLAYBOOK.md
tags:
  - cloud
  - devops
  - cicd
  - terraform
  - monitoring
  - chaos
---

# Platform Engineering

## Scope
Use this skill for infrastructure and delivery systems: cloud design, CI/CD,
deployment automation, observability, Terraform, and resilience testing.

## Instructions
- Identify the platform concern first: architecture, provisioning, delivery,
  runtime visibility, or resilience validation.
- Prefer reproducible infrastructure, explicit environment separation, and
  rollback-aware delivery flows.
- Make deployment and operational assumptions visible: regions, secrets,
  tenancy, scaling model, and blast radius.
- Build observability alongside runtime systems: logs, metrics, traces,
  dashboards, and alerts.

## Sub-skill: Cloud and IaC
- Use infrastructure as code for durable environment changes.
- Optimize for recovery, cost visibility, and least-privilege access.

## Sub-skill: Delivery and operations
- Keep CI/CD pipelines explicit about gates, artifact promotion, and rollback.
- For resilience work, bound the blast radius and define clear abort criteria.

## Notes
- Pair with `security-engineering` for exposed infrastructure or secret flows.
- Pair with `systems-architecture` when the request is still at design stage.
