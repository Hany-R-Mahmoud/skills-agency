# Agent pack for agent-pilot

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-debugging`
- `agent-docs`
- `agent-impeccable`
- `agent-implementer`
- `agent-orchestrator`
- `agent-pilot`
- `agent-reviewer`
- `agent-security`
- `agent-tester`
- `backend-and-language-engineering`
- `coordination-playbook`
- `debugging-and-diagnostics`
- `documentation-and-doc-ops`
- `frontend-react-and-next`
- `fullstack-engineering`
- `interface-and-design`
- `mcp-development`
- `openai-docs`
- `platform-engineering`
- `research-and-reasoning`
- `review-and-pr-operations`
- `security-engineering`
- `systems-architecture`
- `testing-and-verification`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
