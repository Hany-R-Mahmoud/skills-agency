# Command Workflow Patterns

Use this reference to absorb the best parts of command-driven orchestration
without turning the pilot agents into a command catalog.

## Useful Patterns

- plan first, execute second
- preflight first when the workflow is procedural, risky, or repo-specific
- multi-phase decomposition with explicit stop points
- bounded delegation by concern or file scope
- quality gate before closure
- short milestone summaries at phase boundaries

## Preflight Checker Pattern

When a repo has a narrow operational workflow that is easy to break, prefer a
small ordered checker before broader implementation or delivery steps.

Good preflight checks are:

- deterministic
- cheap to run
- ordered by likely failure value
- stop-on-first-failure when later checks depend on earlier ones

Typical sequence:

1. validate environment and assumptions
2. validate changed-scope or input files
3. validate the narrow critical path
4. only then continue to heavier delivery or review steps

## Routing Bias

- use the smallest workflow that still protects quality
- prefer delegation discipline over ad hoc parallelism
- keep orchestration explicit when the task is long-running or risky
