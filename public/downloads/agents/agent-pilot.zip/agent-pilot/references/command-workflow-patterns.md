# Command Workflow Patterns

Use this reference to absorb the best parts of command-driven orchestration
without turning the pilot agents into a command catalog.

## Useful Patterns

- plan first, execute second
- multi-phase decomposition with explicit stop points
- bounded delegation by concern or file scope
- quality gate before closure
- short milestone summaries at phase boundaries

## Routing Bias

- use the smallest workflow that still protects quality
- prefer delegation discipline over ad hoc parallelism
- keep orchestration explicit when the task is long-running or risky
