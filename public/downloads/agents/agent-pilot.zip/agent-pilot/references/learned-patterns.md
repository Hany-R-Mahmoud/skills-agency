# Learned Patterns

Use this file to capture repeated, durable patterns discovered during real
usage of the `agent-pilot` family workflows.

## How To Use

- Add only stable patterns that are likely to matter again.
- Prefer short rules over long narratives.
- Capture the pattern, why it matters, and where it applies.
- If a pattern becomes broad or critical enough, graduate it into a dedicated
  skill or an update to an existing skill.

## Entry Template

### Pattern Name
- Rule:
- Why:
- Applies to:
- Example trigger:

## Seed Patterns

### Narrow Retrieval First
- Rule: Start delegated work with the smallest file set that could plausibly solve the task.
- Why: Reduces token waste and lowers hallucination risk from irrelevant context.
- Applies to: all `agent-pilot` family workflows, especially `agent-pilot`
- Example trigger: a worker asks for broad repo context before inspecting the nearest files

### Milestone Summary Before Phase Shift
- Rule: Summarize after exploration or implementation before switching to review, testing, or docs.
- Why: Prevents stale exploratory detail from polluting later phases.
- Applies to: `agent-pilot`
- Example trigger: moving from planning into implementation, or from implementation into review
