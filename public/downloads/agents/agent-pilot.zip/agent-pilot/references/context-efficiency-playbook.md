# Context Efficiency Playbook

Use this playbook to keep team-led work efficient in Codex.

## Purpose

Reduce token waste, context drift, and hallucination risk without adding heavy
process.

## Core Principles

- Retrieve progressively, not all at once.
- Summarize at milestones instead of carrying full history forever.
- Delegate with bounded scope.
- Promote repeated lessons into durable references.

## Iterative Retrieval Loop

Use this loop before loading more files into a worker:

1. Start with the smallest plausible context.
2. Inspect what is missing.
3. Retrieve only the next most relevant file or artifact.
4. Reassess whether the task is now solvable.
5. Stop after 2-3 rounds unless the task is inherently exploratory.

Use this when:
- dispatching subagents
- exploring unfamiliar code paths
- investigating bugs with unclear scope
- researching architecture before implementation

Avoid it when:
- one obvious file already contains the answer
- the task is too small to justify a loop

## Milestone Summary Pattern

When a phase ends, write a short summary with:
- problem statement
- decisions made
- files that matter now
- what is still uncertain
- the next owner or next action

This should replace dragging older exploration context into later phases.

## When This Helps Most

- medium and large tasks
- tasks with multiple specialists
- long-running debugging or review flows
- architecture-sensitive work

## When It Helps Least

- tiny one-file fixes
- obvious repetitive edits
- tasks where setup cost exceeds the likely context savings
