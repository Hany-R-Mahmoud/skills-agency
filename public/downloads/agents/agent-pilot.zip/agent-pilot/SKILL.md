---
name: agent-pilot
description: Unified team orchestration entry point for feature work ranging from normal delivery to risky, ambiguous, or cross-cutting execution. Trigger when the user explicitly invokes `$agent-pilot` anywhere in the prompt, or when they want one lead agent that can scale from lean coordination to gated multi-specialist workflow with review and verification.
---

# Agent Pilot

## Scope
Use this skill as the default lead workflow for coordinated work. It owns task
framing, specialist routing, bounded delegation, and post-change quality gates,
and can scale from a standard implementation flow to a heavier gated workflow
when risk, ambiguity, or blast radius increases.

## Invocation Contract
Use this skill immediately when the user explicitly includes `$agent-pilot`
anywhere in the prompt.

Treat it as the primary lead entry point whenever the task benefits from
coordination, and let the workflow intensity expand or contract based on the
task rather than switching to a sibling lead skill.

## Best Fit
- Most feature work
- Multi-file changes with moderate risk
- Cross-cutting or architecture-sensitive work
- Security-sensitive or ambiguous requests
- Work that needs implementation plus review and testing
- Tasks that may benefit from specialist routing, artifacts, or explicit gates

## Avoid Using This Skill For
- Tiny edits that should stay close to solo mode
- Narrow low-risk work where `$agent-co-pilot` is the better fit

## Team Model
The lead should remain mostly delegate-first. It may still perform small glue
work when doing so is faster and does not compromise ownership clarity.

## Shared Contract
Use
[`references/shared-team-contract.md`](references/shared-team-contract.md)
as the shared contract for:
- artifact shape
- file ownership
- specialist return format
- completion synthesis

When the task is substantial enough to benefit from written state, create a
small artifact set that follows the shared contract:
- `plan`
- `tasks`
- `review`
- `verification`
- `open-risks` when needed

Keep them brief. They are coordination aids, not formal documents.

For context discipline and token efficiency, also use
[`references/context-efficiency-playbook.md`](references/context-efficiency-playbook.md).
For orchestration-phase discipline, also use
[`references/command-workflow-patterns.md`](references/command-workflow-patterns.md).
Promote repeated durable lessons into
[`references/learned-patterns.md`](references/learned-patterns.md).

## Core Workflow
1. Inspect the request, nearby code, and repo conventions.
2. Use iterative retrieval to gather only the next most relevant context until
   the task shape is clear.
3. Decide the workflow intensity:
   - standard flow
   - gated flow with explicit artifacts and phase boundaries
4. Decide whether the task is implementation-first, debugging-first,
   architecture-first, or research-first.
5. Route the main execution to the best specialist.
6. At phase boundaries, write short milestone summaries instead of carrying the
   full working history forward.
7. After implementation, require review and verification before considering the
   work complete.
8. Add security and docs gates when relevant.
9. Synthesize outcomes, open questions, and residual risk.

## Standard Flow
- `agent-orchestrator` mindset for framing
- main execution through `agent-implementer`
- quality pass through `agent-reviewer`
- evidence pass through `agent-tester`

## Gated Flow
Use the heavier workflow when the cost of a wrong path is meaningful.

1. Explore:
   inspect the repo, conventions, and task shape
2. Propose:
   define the intended path, tradeoffs, and risks
3. Task:
   break work into owned slices with dependencies and file scope
4. Implement:
   delegate bounded execution to the right specialist
5. Review and verify:
   require review, testing, and security checks when relevant
6. Archive:
   summarize outcomes, residual risks, and follow-ups

## Routing Rules
Use `agent-*` worker roles for ownership:
- `agent-implementer` for code changes
- `agent-reviewer` for correctness and regressions
- `agent-tester` for validation evidence
- `agent-debugging` when failure understanding comes before fixing
- `agent-security` for trust-boundary or auth-sensitive work
- `agent-docs` for documentation and explanation deliverables

Use internal playbooks whenever the task needs domain depth:
- [`../frontend-react-and-next/PLAYBOOK.md`](../frontend-react-and-next/PLAYBOOK.md) for React, Next.js, Cache Components, or Ant Design
- [`../fullstack-engineering/PLAYBOOK.md`](../fullstack-engineering/PLAYBOOK.md) for end-to-end feature delivery across UI, API, and persistence
- [`../systems-architecture/PLAYBOOK.md`](../systems-architecture/PLAYBOOK.md) for interface, schema, migration, or boundary design
- [`../research-and-reasoning/PLAYBOOK.md`](../research-and-reasoning/PLAYBOOK.md) for tradeoffs, pre-mortems, or evidence gathering
- [`../backend-and-language-engineering/PLAYBOOK.md`](../backend-and-language-engineering/PLAYBOOK.md) for focused application or CLI implementation
- [`../mcp-development/PLAYBOOK.md`](../mcp-development/PLAYBOOK.md) for MCP server, tool, schema, or protocol work
- [`../interface-and-design/PLAYBOOK.md`](../interface-and-design/PLAYBOOK.md) or `agent-impeccable` for UI or design-heavy tasks
- [`../platform-engineering/PLAYBOOK.md`](../platform-engineering/PLAYBOOK.md) for infra or deployment-sensitive changes
- [`../openai-docs/PLAYBOOK.md`](../openai-docs/PLAYBOOK.md) for current official OpenAI guidance

## Intensity Selection
- Stay lean when:
  - the path is understood
  - one main implementer plus review/testing is enough
  - artifacts would add more ceremony than value
- Switch to the gated flow when:
  - the task affects architecture, security, migrations, or multiple critical paths
  - the blast radius is unclear
  - parallel specialist work adds value
  - written artifacts or explicit gates improve reliability
- De-escalate to `$agent-co-pilot` when the task is truly small and isolated

## Routing Matrix
- Implementation-first:
  route to `agent-implementer`, then `agent-reviewer`, then `agent-tester`
- Debugging-first:
  route to `agent-debugging`, then `agent-implementer`, then `agent-tester`
- Architecture-first:
  route to `systems-architecture` or `research-and-reasoning`, then hand off to
  `agent-implementer`
- UI-first:
  route to `agent-impeccable`, `interface-and-design`, or
  `frontend-react-and-next`, then `agent-implementer` if code changes follow
- Security-sensitive:
  add `agent-security` before closure
- Documentation-heavy:
  add `agent-docs` before closure or handoff

## Quality Gates
Before closing the task, explicitly decide whether each gate is satisfied:
- implementation gate
- review gate
- verification gate
- security gate when relevant
- docs gate when relevant

If a gate is skipped, state why and what risk remains.

## Output
- Goal and chosen workflow
- Specialists and domain skills selected
- Artifact summary when used
- Gate status
- Verification expectations
- Residual risks or escalation advice
