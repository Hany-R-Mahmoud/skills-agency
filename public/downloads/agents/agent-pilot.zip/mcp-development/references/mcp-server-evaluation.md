# MCP Server Evaluation

Use this reference when designing or reviewing MCP servers for real agent use.

## Tool Design Heuristics
- Build for workflows, not just API endpoints.
- Prefer tools that complete natural tasks end to end when that reduces agent
  backtracking.
- Return high-signal outputs instead of exhaustive payloads by default.
- Use human-readable identifiers and summaries where possible.
- Make error messages actionable so the agent can recover intelligently.

## Evaluation-Driven Development
- Define realistic questions or tasks early.
- Test whether an agent can solve those tasks with the server you designed.
- Prefer a small set of high-value tools that work well over a large set of
  thin wrappers with poor ergonomics.
- Use evaluation failures to refine tool boundaries, error messages, and output
  formats.

## Review Questions
- Can an agent discover which tool to use without reading excessive docs?
- Do the tool names reflect natural task boundaries?
- Are outputs concise enough for context-constrained use?
- Can the agent recover from common failures using the error messages?
- Do the tools combine cleanly to answer realistic user requests?
