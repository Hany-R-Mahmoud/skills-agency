---
name: mcp-development
description: Build or integrate Model Context Protocol servers and clients with production-grade tool, resource, and schema design. Use for MCP protocol work, SDK usage, and server architecture.
path: skills/mcp-development/PLAYBOOK.md
tags:
  - mcp
  - model-context-protocol
  - tools
  - resources
  - schemas
---

# MCP Development

## Scope
Use this skill for Model Context Protocol server or client design, SDK usage,
tool and resource schema design, and production deployment concerns.

## Instructions
- Clarify whether the task is an MCP server, MCP client, protocol integration,
  or troubleshooting request.
- Define resources, tools, prompts, and schemas before coding transport logic.
- Design for agent workflows, not raw endpoint coverage: prefer tools that help
  the model complete meaningful tasks instead of thin wrappers over every API
  route.
- Validate inputs and outputs explicitly and keep error messages actionable.
- Treat security, rate limits, auth, and observability as first-class concerns.
- Plan lightweight evaluations early so the server can be judged by realistic
  agent tasks, not just implementation completeness.

## Sub-skill: Protocol and SDK design
- Implement protocol details correctly for the chosen SDK and transport.
- Keep naming discoverable and outputs structured.

## Sub-skill: Production readiness
- Document capabilities, auth model, configuration, and limits.
- Test protocol compliance and operational failure modes.

## Notes
- Use `backend-and-language-engineering` when the task is mostly general app
  code with only incidental MCP usage.
- Pull in [`references/mcp-server-evaluation.md`](/Users/hanyramadan/.codex/skills/mcp-development/references/mcp-server-evaluation.md)
  for workflow-oriented tool design and evaluation guidance.
