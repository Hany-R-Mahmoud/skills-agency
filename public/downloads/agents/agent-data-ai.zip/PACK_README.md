# Agent pack for agent-data-ai

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-data-ai`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
