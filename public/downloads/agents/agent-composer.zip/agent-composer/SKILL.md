---
name: agent-composer
description: Unified skill and browser-agent composition entry point for this skill pack. Use when Codex should design, create, refine, package, or evaluate a skill, agent, or browser automation workflow end to end, especially when the result should follow the local agent pattern and may need Playwright-capable execution guidance.
path: .codex/skills/agent-composer/SKILL.md
tags:
  - agent
  - composition
  - skills
  - browser
  - playwright
  - packaging
---

# Agent Composer

Provide a single public entry point for composing new skills, browser-capable
agents, and reusable automation workflows in this repository.

Act as a router plus builder: identify whether the request is mainly about
skill architecture, browser automation, Playwright-style execution patterns,
evaluation, or packaging, then pull only the minimum internal guidance needed.

Do not treat every imported idea as a new public skill. Prefer one public
surface with private composition lanes, the same way `agent-impeccable` keeps
its internal modes bundled behind one entry point.

## Invocation Contract

Invoke this skill directly as `$agent-composer` whenever the prompt is about:

- creating a new skill or agent in the local house style
- consolidating multiple skill ideas into one coherent public entry point
- adding browser automation or Playwright-aware behavior to a skill
- improving skill packaging, routing, benchmarks, or evaluation loops
- turning external skill repos into local-first, opinionated agents

When explicitly invoked, do not make the user choose internal lanes unless
there is a real tradeoff between narrow options. Infer the likely path, explain
it briefly, and proceed.

The user should not need to know the internal lanes. Treat them as private
implementation details.

## Use This Skill For

- creating a new local skill that should feel native to this repository
- folding the best parts of several external skills into one better public
  entry point
- designing browser agents that rely on Playwright-style navigation, state,
  capture, interaction, or verification workflows
- scaffolding references, routing rules, packaging metadata, and evaluation
  heuristics for a new skill
- reviewing whether a capability should become a new public skill or stay as a
  private mode, reference, or template

## Do Not Use This Skill For

- generic application implementation unrelated to skill or agent packaging
- one-off browser tasks where the goal is to use a browser, not design an agent
- code review that does not affect skill architecture, browser automation, or
  composition quality

## Quick Start

If the request sounds like one of these, use the matching route immediately:

- "create a new skill from these repos":
  `foundation`, then usually `skill-architecture`, `skill-scaffolding`,
  `packaging`
- "make this a browser agent":
  `foundation`, then `browser-automation`, optionally `delivery`
- "add Playwright support":
  `foundation`, then `playwright-execution`, usually `browser-automation`
- "improve this skill without adding menu bloat":
  `foundation`, then `consolidation`, `packaging`
- "evaluate whether this should be a new skill":
  `foundation`, then `skill-evaluation`
- "turn this into a polished local agent":
  `foundation`, then `skill-architecture`, `skill-scaffolding`, `packaging`,
  and optionally `skill-evaluation`

If the user explicitly invokes `$agent-composer`, default to automatic routing.
Only surface the chosen lanes when it helps explain why the result looks the
way it does.

## Core Workflow

1. Inspect the request and classify it:
   - new skill creation
   - skill consolidation
   - browser automation composition
   - Playwright-style execution design
   - packaging and manifest work
   - evaluation and hardening
2. Start with the shared foundation in
   `references/composition-standards.md`.
3. Pull the minimum supporting lanes from `references/skill-map.md` and
   `references/request-recipes.md`.
4. Preserve local conventions first:
   - one public skill when possible
   - private modes and references for internal complexity
   - concise routing language
   - strong execution guidance
5. If browser automation is involved, add the browser lane:
   - model navigation, snapshotting, interaction, waiting, state, and capture
   - describe the workflow in Playwright-capable terms even when the backing
     CLI may vary
   - keep auth and session handling explicit
6. If the result is a new skill, produce the full local shape:
   - main `SKILL.md`
   - interface metadata under `agents/`
   - compact routing references
   - optional templates or playbooks only when they reduce future drift
7. If evaluating an import, convert broad external systems into the smallest
   coherent local skill shape instead of mirroring their entire tree.

## Automatic Routing Rule

When the prompt contains skill or agent creation intent but does not name a
lane:

- infer the dominant intent from the request
- choose one primary lane
- add only the minimum supporting lanes needed to finish the job
- continue without asking the user to pick from internal lanes

Escalate only when the request genuinely points to incompatible outcomes, such
as "make this a tiny local helper" and "also preserve the full external system"
at the same time.

## Routing Rules

Default to these bundles:

- New local skill:
  `foundation` plus `skill-architecture`, `skill-scaffolding`, `packaging`
- External repo to local agent:
  `foundation` plus `consolidation`, `skill-architecture`, `packaging`
- Browser or Playwright agent:
  `foundation` plus `browser-automation`, `playwright-execution`, optionally
  `delivery`
- Skill improvement without new public surface:
  `foundation` plus `consolidation`, optionally `skill-evaluation`
- Benchmarking or quality pressure test:
  `foundation` plus `skill-evaluation`, optionally `delivery`

If a request is narrow, stay narrow. A manifest or routing tweak should not
pull in full browser-execution design by default.

Prefer a primary lane and at most 2-4 supporting lanes for most tasks.

## Conflict Resolution

Some composition goals pull in opposite directions. Resolve them deliberately:

- `consolidation` vs `full-fidelity import`:
  prefer consolidation unless the user explicitly asks to preserve the full
  upstream structure
- `playwright-execution` vs `tool-agnostic design`:
  prefer tool-agnostic language when the skill is long-lived, then add a
  Playwright-capable execution note when browser precision matters
- `skill-evaluation` vs `speed of scaffolding`:
  ship the smallest useful scaffold first, then add evaluation assets if the
  skill will be reused often

## Default Execution Standards

Regardless of which lanes are selected:

- inspect existing local skills before introducing new structure
- prefer native repository phrasing over upstream terminology
- keep browser automation stateful, explicit, and reproducible
- treat authentication, session reuse, screenshots, downloads, and waits as
  part of correctness for browser-capable skills
- avoid picker sprawl by default; hide internal complexity in references,
  modes, templates, or scripts
- when importing external skill ideas, adapt rather than copy verbatim

## User Request Translation

Users often describe outcomes, not composition lanes. Translate intent like
this:

- "build me a skill like this repo" usually means `skill-architecture`,
  `skill-scaffolding`, `packaging`
- "make it use Playwright" usually means `playwright-execution`,
  `browser-automation`
- "bundle all of this into one agent" usually means `consolidation`,
  `skill-architecture`
- "make it production-ready" usually means `delivery`, often with
  `skill-evaluation`
- "keep it like our other agents" usually means `foundation`, `packaging`,
  `consolidation`

If the prompt mixes several desires, prioritize in this order unless the user
says otherwise:

1. match the local skill taxonomy
2. keep the public surface minimal
3. preserve the strongest upstream ideas
4. make browser execution reliable
5. add evaluation and hardening

## Output Shape

Match the task:

- For new skill creation:
  explain the selected lanes briefly, then create the files
- For import evaluation:
  summarize what was kept, what was adapted, and what was intentionally omitted
- For browser-agent design:
  describe the execution model in concrete browser terms, including state and
  verification

Always name the lanes you chose when that helps the user understand why the
skill was structured a certain way.

## Reference

Use these references as needed:

- `references/composition-standards.md`: shared standards for local skill
  composition and import hygiene
- `references/browser-composition.md`: browser and Playwright-style workflow
  guidance for new skills
- `references/skill-map.md`: compact map of internal composition lanes
- `references/request-recipes.md`: common request phrasing to lane bundles
- `references/command-packaging-patterns.md`: packaging inspiration for
  turning repeatable workflows into thin local shims instead of bloated public
  surfaces

Read only the relevant entries rather than treating every lane as active.
