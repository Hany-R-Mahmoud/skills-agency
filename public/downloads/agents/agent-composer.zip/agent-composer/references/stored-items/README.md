# Stored Items

Use this folder for repo-evolution ideas that are worth keeping but not worth
patching into the live skill system yet.

## Purpose

`store` is a deliberate parking decision:

- the idea is potentially useful
- the current fit is incomplete, too product-specific, or too risky
- forcing it into a skill or reference now would add clutter

The goal is to preserve good judgment without inflating the active system.

## What Belongs Here

- strong ideas with an unclear destination today
- app-specific patterns that may become useful once generalized
- infrastructure-heavy concepts that are interesting but premature
- candidate imports that overlap current guidance and need a clearer trigger

## What Does Not Belong Here

- rejected ideas
- active backlog items that already have an approved patch plan
- large copied excerpts from upstream repos

## How To Use The Registry

Add one concise entry per stored idea to [`REGISTRY.md`](./REGISTRY.md) with:

- a stable id
- the source repo and file
- why it was stored instead of adapted
- the most likely future home
- a concrete trigger for reconsideration

Keep entries brief. The registry is an index for future judgment, not a second
documentation dump.

## Promotion Rule

Promote a stored item only when a later task gives it:

- a clearer low-risk destination
- stronger evidence of reuse value
- a more generic phrasing than the original product-specific version
