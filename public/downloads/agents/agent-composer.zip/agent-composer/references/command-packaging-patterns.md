# Command Packaging Patterns

Use this reference when adapting command-style workflow repos into your local
agent system.

## Pattern

- keep the public surface small
- convert repeated workflows into private modes or references first
- use thin shims when the workflow is procedural and repeatable
- avoid copying large command catalogs verbatim into the picker

## Surface Selection Order

When importing a workflow from another repo, place it in the narrowest useful
surface first:

1. `rules/` for deterministic always-on constraints
2. `skills/` for on-demand workflows and judgment-heavy guidance
3. `MCP` for durable structured tool boundaries
4. local scripts or CLI for deterministic one-shot execution
5. direct API calls inside an existing skill or script for narrow remote steps

If two options seem valid, prefer the smaller runtime surface with lower token
and maintenance cost.

## Shim Design

- Keep entrypoints thin. Let them delegate to shared references, playbooks, or
  scripts instead of holding the full workflow inline.
- Treat shim code as routing and packaging glue, not the main knowledge store.
- If a command exists mainly to rephrase an existing local skill, collapse it
  back into that skill instead of preserving a second public surface.
- If the same capability ships across multiple hosts, keep one core workflow
  and let host-specific wrappers handle only install, invocation, and naming
  differences.

## Config Layering

- Prefer a predictable precedence order such as:
  - built-in defaults
  - user or global config
  - project-local config
  - one-shot invocation overrides
- Document the merge behavior explicitly, including which layer wins on
  conflict.
- If a mode disables part of the config stack, say so clearly rather than
  silently ignoring project-local settings.

## Fallback Packaging

- When a packaged command or shim supports optional arguments, let it try the
  preferred invocation first and fall back to a safer minimal invocation only
  when the first path fails.
- Keep fallbacks conservative. They should preserve correctness and startup
  reliability, not introduce a second equally complex execution path.
- Treat fallback behavior as packaging resilience, not a substitute for fixing
  a broken primary route.
- Keep install and onboarding stories shared across hosts where possible. Avoid
  rewriting setup guidance separately for each thin wrapper unless the host
  genuinely requires it.

## Pattern Mining

- When the same workflow appears across multiple sessions or repos, treat that
  as input for private suggestion logic before turning it into a public skill.
- Prefer repeated workflow detection over one-off intuition when deciding that a
  new skill or command surface might be justified.
- Keep the detection machinery private. The user-facing output should still be a
  simple recommendation to enhance an existing public entry point, add a
  private reference or mode, or decline to create anything new.
- Never let pattern mining create public surfaces automatically. It should help
  surface candidates, not bypass packaging judgment.
