# Command Packaging Patterns

Use this reference when adapting command-style workflow repos into your local
agent system.

## Pattern

- keep the public surface small
- convert repeated workflows into private modes or references first
- use thin shims when the workflow is procedural and repeatable
- avoid copying large command catalogs verbatim into the picker
