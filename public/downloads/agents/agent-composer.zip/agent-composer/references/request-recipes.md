# Request Recipes

Use this file when the user describes a desired outcome instead of naming a
specific composition lane.

## New Skills

- "Create a new agent/skill like our others":
  start with `foundation`; usually add `skill-architecture`,
  `skill-scaffolding`, `packaging`
- "Turn these ideas into one agent":
  start with `foundation`; add `consolidation`, then `skill-architecture`
- "Make this feel native to our repo":
  start with `foundation`; add `packaging`; often add `consolidation`
- "Analyze this repo and improve our existing skills":
  start with `foundation`; add `repo-evolution`, then `consolidation`,
  `skill-evaluation`
- "Compare this repo to what we already have and merge only what matters":
  start with `foundation`; add `repo-evolution`, `consolidation`, `packaging`
- "Analyze this repo" when the surrounding context is about skill evolution:
  start with `foundation`; add `repo-evolution`, `consolidation`,
  `skill-evaluation`; use repo-evolution defaults unless the user overrides

## Browser And Playwright

- "Make it a browser agent":
  start with `foundation`; add `browser-automation`; usually add `delivery`
- "Use Playwright":
  start with `foundation`; add `playwright-execution`; often add
  `browser-automation`
- "It should test, log in, click around, or capture screenshots":
  start with `foundation`; add `browser-automation`, `playwright-execution`

## Quality And Reuse

- "Make it production-ready":
  start with `foundation`; add `delivery`; optionally `skill-evaluation`
- "Make sure the routing is good":
  start with `foundation`; add `skill-evaluation`
- "Keep the best of the source repos but simplify them":
  start with `foundation`; add `consolidation`, `packaging`
- "Keep our skills updated from outside repos without breaking them":
  start with `foundation`; add `repo-evolution`; usually add
  `skill-evaluation`

## Explicit-Only Routing

Some imported or manual-heavy workflows should not be inferred from loose
phrasing alone.

Prefer explicit naming or a strong direct match when the workflow is:

- highly opinionated about tradeoffs or style
- manual-only by design
- likely to override normal defaults
- heavy enough that accidental routing would waste time or add noise

Examples:

- "use this exact skill/workflow by name" should honor the explicit route
- "review this repo and keep only what matters" should still use
  `repo-evolution` because the outcome clearly matches the workflow
- "make everything radically smaller" should not automatically trigger a
  deletion-biased or entropy-style workflow unless the user clearly asks for it
- "write QA docs" should not automatically load a full manual-test-planning
  workflow unless the user explicitly wants that level of structure

## Guardrail

Do not map vague prompts to every lane. Pick the most likely primary lane, then
add only the supporting lanes needed to complete the job well.
