# Request Recipes

Use this file when the user describes a desired outcome instead of naming a
specific composition lane.

## New Skills

- "Create a new agent/skill like our others":
  start with `foundation`; usually add `skill-architecture`,
  `skill-scaffolding`, `packaging`
- "Turn these ideas into one agent":
  start with `foundation`; add `consolidation`, then `skill-architecture`
- "Make this feel native to our repo":
  start with `foundation`; add `packaging`; often add `consolidation`

## Browser And Playwright

- "Make it a browser agent":
  start with `foundation`; add `browser-automation`; usually add `delivery`
- "Use Playwright":
  start with `foundation`; add `playwright-execution`; often add
  `browser-automation`
- "It should test, log in, click around, or capture screenshots":
  start with `foundation`; add `browser-automation`, `playwright-execution`

## Quality And Reuse

- "Make it production-ready":
  start with `foundation`; add `delivery`; optionally `skill-evaluation`
- "Make sure the routing is good":
  start with `foundation`; add `skill-evaluation`
- "Keep the best of the source repos but simplify them":
  start with `foundation`; add `consolidation`, `packaging`

## Guardrail

Do not map vague prompts to every lane. Pick the most likely primary lane, then
add only the supporting lanes needed to complete the job well.
