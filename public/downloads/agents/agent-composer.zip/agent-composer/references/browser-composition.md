# Browser Composition

Use this file when the new skill or agent should handle browser automation,
especially with Playwright-style expectations.

## Browser Workflow

Model browser-capable skills around a repeatable interaction loop:

1. navigate to the page or start from a known authenticated state
2. inspect the current page and identify actionable elements
3. interact using stable selectors or references
4. wait for navigation, network, or DOM changes explicitly
5. capture the result with text, screenshot, download, or verification output
6. re-inspect before the next action if the page changed materially

## Playwright-Capable Guidance

Even when the runtime tool is not literally Playwright, describe the workflow in
Playwright-capable terms:

- browser context and session state
- selectors and element targeting
- navigation and load-state waits
- screenshots and PDFs
- downloads and network-aware verification
- auth state reuse and profile persistence

## State And Auth

Treat authentication as first-class:

- prefer reusable session state for recurring flows
- keep secrets out of prompts and repos
- describe when to use saved state, profiles, or manual login checkpoints
- make it clear when the agent must pause for user auth or MFA

## Reliability Standards

- avoid one-shot "click and hope" flows
- re-check page state after significant interactions
- use explicit waits tied to URL, element, text, or network changes
- capture evidence when the workflow is meant for testing or auditing
- mention cleanup of temporary state files when relevant

## Good Fit

Use the browser lane when the skill is meant to:

- test or verify a web application
- automate a login or form flow
- collect data from websites
- capture screenshots, PDFs, or video evidence
- run recurring browser workflows with stable state

## Bad Fit

Do not load heavy browser guidance for skills that only need packaging or text
generation.
