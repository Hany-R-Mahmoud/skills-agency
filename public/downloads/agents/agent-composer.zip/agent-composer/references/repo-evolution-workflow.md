# Repo Evolution Workflow

Use this reference when an external repo should improve existing local skills
without creating duplication, picker noise, or brittle imports.

## Primary Goal

Extract the strongest reusable ideas from an external repo and merge them into
the current local skill system safely, with a dry-run-first mindset.

When repeatability matters more than ad hoc inspection, use the executable
helper at
`agent-composer/scripts/repo_evolution.py`
to generate a dry-run report and patch-plan data before editing anything.

## Default Bias

- refresh the local skill snapshot each run instead of trusting stale copies
- preserve the existing public skill taxonomy unless the public contract truly
  changes
- prefer adaptation over copying
- reject upstream surfaces more aggressively than upstream abstractions
- prefer references and playbooks before public `SKILL.md` growth
- reject ideas that add clutter without changing outcomes
- grade evidence strength before treating an imported claim as reusable truth
- challenge the strongest new claim before promoting it into local guidance
- use the dry-run as intake first, then do a salvage pass for strong concepts
  that belong in lighter local references

## Automatic Defaults

When the user asks `agent-composer` to analyze or compare an external repo for
skill evolution and does not provide more detail, assume all of the following
without asking:

- Goal:
  compare the repo against the local `agent-*` skills and extract only
  improvements that are useful, non-duplicative, and safe
- Rules:
  - dry-run first
  - prefer updating playbooks and references before `SKILL.md`
  - no bloat
  - no over-engineering
  - no breaking current routing
  - show `adopt` / `adapt` / `store` / `reject` for each candidate
- Default focus:
  - `agent-pilot`
  - `agent-composer`
  - `agent-orchestrator`
- Default priorities:
  - routing improvements
  - evaluation loops
  - import hygiene
  - playbook structure

Treat these as the standard repo-evolution contract. Only deviate when the user
explicitly narrows the target skills, changes the priorities, or asks for a
different level of aggressiveness.

## Flow

1. Snapshot
   Read the current local state of the target skills, playbooks, and
   references. Treat the repo on disk as the source of truth each run. By
   default, start with `agent-pilot`, `agent-composer`, and
   `agent-orchestrator`, then widen only if the repo clearly contains stronger
   matches elsewhere.
2. Ingest
   Read the external repo progressively. Focus on execution patterns, routing
   heuristics, evaluation loops, safety rules, and reusable packaging ideas.
3. Normalize
   Convert findings into compact candidate improvements:
   - routing improvement
   - workflow improvement
   - heuristic or reference improvement
   - packaging improvement
   - noise or duplication
4. Triage
   Classify the imported material before scoring it:
   - `expert`: adds non-obvious local value and is worth preserving
   - `activation`: mostly familiar, but worth keeping as a compact reminder,
     checklist, or routing cue
   - `redundant`: basic, generic, or already covered locally
   Default action:
   - preserve `expert`
   - compress `activation`
   - delete or reject `redundant`
5. Grade
   Mark the support level behind the candidate:
   - documented fact
   - observed example
   - inference
   - unresolved uncertainty
6. Compare
   Check whether the idea already exists locally, partially exists, conflicts
   with current structure, or belongs in a different destination.
7. Challenge
   Pressure-test the strongest candidate or the riskiest new claim before
   accepting it. Look for stale assumptions, missing local fit, or evidence
   that the idea is narrower than it first appeared.
8. Decide
   Choose one action per candidate:
   - `adopt`
   - `adapt`
   - `store`
   - `reject`
9. Salvage
   For candidates that are valuable but badly packaged upstream, salvage the
   abstraction instead of importing the surrounding surface:
   - keep the checklist, not the full framework
   - keep the routing cue, not the catalog entry
   - keep the validation phase, not the product-specific pipeline
   - keep the packaging lesson, not the host-specific install story
10. Map
   Send accepted changes to the lightest useful destination:
   - public contract or invocation change: `SKILL.md`
   - execution details: `PLAYBOOK.md`
   - heuristics, recipes, or examples: `references/`
   - repeated durable lesson: `learned-patterns.md`
   - useful but not yet ready: `references/stored-items/REGISTRY.md`
11. Patch Plan
   Produce a concise dry-run summary with proposed diffs, touched files,
   rationale, and risks before editing.
12. Apply
   Make only the accepted minimal edits and keep the result native to the local
   repository style.

## Executable Helper

The local helper script:

- snapshots the local `agent-*` skills every run
- reads a local path or Git URL
- extracts structured candidates
- compares them to the current skill corpus
- scores `novelty`, `utility`, `fit`, and `risk`
- suggests a destination
- records lightweight history for repeated repo analysis

Use it when you want consistency, speed, and repeatability rather than a
purely manual repo-evolution pass.

## Decision Rubric

Score each candidate on these four axes:

- `novelty`: how much is new relative to the current local system
- `utility`: whether it improves routing, execution quality, or reuse
- `fit`: whether it matches the local architecture and tone
- `risk`: whether it bloats, duplicates, or destabilizes existing skills

Also note the evidence level behind the idea:

- `documented fact`: supported by clear upstream or local primary evidence
- `observed example`: seen in practice but not established as a stable rule
- `inference`: plausible interpretation that still needs caution
- `unresolved uncertainty`: interesting but not trustworthy enough to drive
  direct adoption

Use the rubric like this:

- high utility, high fit, low risk: `adopt`
- high utility, medium fit: `adapt`
- good idea but too detailed for public skill text: `store`
- mostly duplicate, noisy, or low fit: `reject`

## Destination Rules

- Do not expand a public `SKILL.md` unless the invocation contract, scope, or
  top-level routing needs to change.
- If the upstream repo has a lot of useful detail but weak packaging, default
  to salvaging its best abstractions into references instead of importing its
  public surface.
- If the idea improves execution depth but not the public promise, move it into
  a playbook or reference.
- If the same idea would help more than one skill, prefer a shared reference or
  a central playbook update.
- If the idea is strong but not yet proven durable, keep it out of the main
  skill and store it in a reference first.
- If the evidence is weak or mixed, adapt the caution rather than importing the
  claim as settled truth.
- If the idea looks promising but lacks a clean low-risk home today, store it
  in the repo-evolution registry instead of forcing a premature patch.

## Import Review Questions

Before accepting an imported idea, answer these briefly:

1. Is this a real reusable local surface, or just documentation for another
   tool or runtime?
2. Does this improve an existing local skill more cleanly than creating
   something new?
3. Are we importing the underlying concept, or accidentally importing product
   identity and vendor framing?
4. Would a local user understand the resulting surface without knowing the
   upstream repo?
5. Is the lightest destination a reference, playbook, or learned pattern
   instead of public skill text?
6. Is the upstream artifact internally contradictory, bloated, or mixing
   several concerns that should be split before import?
7. If the packaging is noisy, what is the smallest abstraction worth salvaging?

Weak answers are a signal to adapt more aggressively, narrow the scope, or
reject the candidate.

## Useful Imported Signals

The following upstream traits are often worth salvaging even when the source
repo itself should not be imported directly:

- contradiction-first cleanup before splitting a large instruction file
- explicit validation tiers such as structure, safety, references, and
  provenance
- named evaluation scenarios with compact pass criteria
- explicit-only routing for heavy, manual, or strongly opinionated workflows
- preflight checkers with ordered stop-on-first-failure steps

## Anti-Patterns

- mirroring upstream folder structures inside local public skills
- pasting long upstream instructions verbatim
- adding new picker entries when a private mode or reference is enough
- treating every interesting repo detail as reusable
- editing multiple skills at once without a clear per-skill rationale

## Suggested Output Shape

For each evolution pass, summarize:

- target repo
- local skills reviewed
- candidates extracted
- evidence level per candidate
- `adopt` / `adapt` / `store` / `reject` decisions
- proposed file destinations
- residual risks or follow-up checks

When one or more items are marked `store`, add or update the matching entries in
`references/stored-items/REGISTRY.md` so future passes can build on prior
judgment instead of rediscovering the same idea.
