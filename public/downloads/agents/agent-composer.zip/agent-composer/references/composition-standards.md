# Composition Standards

Use this file as the shared foundation for `agent-composer`.

## Primary Goal

Create local skills that feel native to this repository even when the source
ideas come from larger or noisier upstream skill packs.

## Core Rules

- Prefer one coherent public entry point over many narrow picker entries.
- Pull in only the strongest upstream ideas; do not mirror foreign trees by
  default.
- Convert product-specific jargon into local, reusable language.
- Keep the public `SKILL.md` short enough to route well, but concrete enough to
  execute.
- Move complexity into references, private modes, templates, or scripts.

## Local Shape

When creating a new public skill, prefer this shape:

- `SKILL.md` as the main entry point
- `agents/openai.yaml` for interface metadata
- `references/` for routing maps, recipes, and opinionated standards
- `modes/` only when private execution branches are large enough to justify
  separate playbooks

## Import Hygiene

When adapting external skills or repos:

- keep the capability, not the clutter
- remove marketplace-facing or vendor-specific framing
- preserve strong execution patterns, examples, and guardrails
- collapse overlapping concepts into fewer internal lanes
- avoid verbatim copying when a concise local rewrite is stronger

## Evaluation Bias

If the skill will be reused often, include lightweight evaluation guidance:

- what good requests look like
- how to judge whether the route was correct
- what should remain private vs public
- which browser flows or templates are risky enough to verify explicitly

## Anti-Pattern

Do not create a new public skill just because the upstream repo had a distinct
folder. Public surface area is part of product design.
