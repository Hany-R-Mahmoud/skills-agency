#!/usr/bin/env python3
from __future__ import annotations

import argparse
import dataclasses
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


SCRIPT_PATH = Path(__file__).resolve()
AGENT_COMPOSER_DIR = SCRIPT_PATH.parent.parent
SKILLS_ROOT = AGENT_COMPOSER_DIR.parent
DEFAULT_OUTPUT_DIR = AGENT_COMPOSER_DIR / "artifacts" / "repo-evolution"
DEFAULT_STATE_DIR = AGENT_COMPOSER_DIR / "state" / "repo-evolution"
DEFAULT_CACHE_DIR = DEFAULT_STATE_DIR / "cache"
DEFAULT_HISTORY_PATH = DEFAULT_STATE_DIR / "history.json"

DEFAULT_FOCUS_SKILLS = [
    "agent-pilot",
    "agent-composer",
    "agent-orchestrator",
]

DEFAULT_PRIORITIES = [
    "routing improvements",
    "evaluation loops",
    "import hygiene",
    "playbook structure",
]

DEFAULT_GUARDRAILS = [
    "dry-run first",
    "prefer updating playbooks and references before SKILL.md",
    "no bloat",
    "no over-engineering",
    "no breaking current routing",
    "show adopt/adapt/store/reject for each candidate",
]

TEXT_FILE_EXTENSIONS = {
    ".md",
    ".txt",
    ".py",
    ".ts",
    ".tsx",
    ".js",
    ".jsx",
    ".mjs",
    ".cjs",
    ".json",
    ".yaml",
    ".yml",
    ".toml",
    ".sh",
}

SKIP_DIR_NAMES = {
    ".git",
    "node_modules",
    "dist",
    "build",
    "artifacts",
    "state",
    ".next",
    ".turbo",
    ".venv",
    "venv",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
}

CATEGORY_KEYWORDS: dict[str, tuple[str, ...]] = {
    "routing improvement": (
        "route",
        "routing",
        "router",
        "dispatch",
        "trigger",
        "intent",
        "bundle",
        "lane",
        "mode",
    ),
    "workflow improvement": (
        "workflow",
        "phase",
        "step",
        "handoff",
        "gate",
        "review",
        "verify",
        "checkpoint",
        "milestone",
    ),
    "heuristic or reference improvement": (
        "heuristic",
        "rubric",
        "guideline",
        "rule",
        "preference",
        "criteria",
        "decision",
        "pattern",
        "recipe",
    ),
    "packaging improvement": (
        "package",
        "packaging",
        "public surface",
        "private",
        "playbook",
        "reference",
        "scaffold",
        "manifest",
        "skill",
    ),
}

PRIORITY_KEYWORDS: dict[str, tuple[str, ...]] = {
    "routing improvements": (
        "route",
        "routing",
        "trigger",
        "intent",
        "dispatch",
        "mode",
        "lane",
    ),
    "evaluation loops": (
        "evaluate",
        "evaluation",
        "verify",
        "verification",
        "review",
        "feedback",
        "loop",
        "benchmark",
    ),
    "import hygiene": (
        "import",
        "adapt",
        "copy",
        "duplicate",
        "mirror",
        "upstream",
        "vendor",
    ),
    "playbook structure": (
        "playbook",
        "reference",
        "mode",
        "public surface",
        "private",
        "skill.md",
    ),
}

TARGET_SKILL_KEYWORDS: dict[str, tuple[str, ...]] = {
    "agent-history": (
        "handoff",
        "resume",
        "continue in another tool",
        "conversation history",
        "working state",
        "context extraction",
        "session context",
        "session",
        "continuity",
        "export",
        "briefing",
    ),
    "agent-pilot": (
        "lead",
        "delegate",
        "phase",
        "gate",
        "review",
        "verification",
        "milestone",
        "specialist",
    ),
    "agent-composer": (
        "compose",
        "packaging",
        "import",
        "consolidation",
        "repo",
        "skill",
        "playbook",
        "reference",
    ),
    "agent-orchestrator": (
        "plan",
        "decompose",
        "sequence",
        "assumption",
        "dependency",
        "checkpoint",
        "orchestrate",
    ),
}

REPO_CAPABILITY_KEYWORDS: dict[str, tuple[str, ...]] = {
    "session continuity and handoff": (
        "handoff",
        "continue",
        "continues",
        "resume",
        "session",
        "working state",
        "conversation history",
        "pick up where you left off",
        "rate limit",
    ),
    "cross-tool parsing and extraction": (
        "parser",
        "parsing",
        "extract",
        "extraction",
        "native format",
        "jsonl",
        "sqlite",
        "yaml",
        "registry",
        "scan",
        "discovery",
    ),
    "cli workflow and configuration": (
        "cli",
        "command",
        "flags",
        "config",
        "interactive",
        "tui",
        "prompt",
        "usage",
    ),
    "verification and quality gates": (
        "test",
        "check",
        "lint",
        "verify",
        "fixture",
        "validation",
        "ci",
        "diagnostic",
    ),
    "packaging and import hygiene": (
        "dependency",
        "dependencies",
        "install",
        "runtime",
        "package",
        "read-only",
        "anti-pattern",
        "do not",
    ),
}

CAPABILITY_TO_SKILLS: dict[str, list[str]] = {
    "session continuity and handoff": ["agent-history", "agent-orchestrator", "agent-pilot", "agent-composer"],
    "cross-tool parsing and extraction": ["agent-composer", "agent-orchestrator"],
    "cli workflow and configuration": ["agent-composer", "agent-orchestrator"],
    "verification and quality gates": ["agent-pilot", "agent-orchestrator"],
    "packaging and import hygiene": ["agent-composer", "agent-pilot"],
}

HIGH_SIGNAL_FILE_NAMES = {
    "README.md",
    "AGENTS.md",
    "CLAUDE.md",
    "REVIEW.md",
    "package.json",
    "tsconfig.json",
}


@dataclasses.dataclass
class Candidate:
    candidate_id: str
    source_path: str
    section_title: str
    excerpt: str
    category: str
    target_skills: list[str]
    target_reason: str
    matched_priorities: list[str]
    novelty: int
    utility: int
    fit: int
    risk: int
    decision: str
    destination: str
    rationale: str
    duplicate_signals: list[str]
    warnings: list[str]


@dataclasses.dataclass
class RepoProfile:
    repo_kind: str
    capabilities: list[str]
    likely_target_skills: list[str]
    priorities: list[str]
    key_files: list[str]
    summary: str


@dataclasses.dataclass
class ExtractionDiagnostics:
    files_total: int
    files_selected: int
    sections_total: int
    sections_kept: int
    candidate_count: int
    top_files: list[dict[str, Any]]


def now_utc() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def slugify(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return normalized or "repo"


def tokenize(text: str) -> set[str]:
    return {token for token in re.findall(r"[a-z0-9]{3,}", text.lower()) if token}


def similarity(a: str, b: str) -> float:
    a_tokens = tokenize(a)
    b_tokens = tokenize(b)
    if not a_tokens or not b_tokens:
        return 0.0
    overlap = len(a_tokens & b_tokens)
    base = min(len(a_tokens), len(b_tokens))
    return overlap / base if base else 0.0


def sha1_text(value: str) -> str:
    return hashlib.sha1(value.encode("utf-8")).hexdigest()


def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def save_json(path: Path, data: Any) -> None:
    ensure_dir(path.parent)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=True) + "\n", encoding="utf-8")


def clean_text(text: str) -> str:
    text = text.replace("\r\n", "\n")
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def collect_text_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for path in root.rglob("*"):
        rel_parts = path.relative_to(root).parts
        if any(part in SKIP_DIR_NAMES for part in rel_parts):
            continue
        if path.is_file() and path.suffix.lower() in TEXT_FILE_EXTENSIONS:
            files.append(path)
    return sorted(files)


def read_text_file(path: Path) -> str:
    try:
        return clean_text(path.read_text(encoding="utf-8"))
    except UnicodeDecodeError:
        return ""


def score_repo_capabilities(text: str) -> dict[str, int]:
    lowered = text.lower()
    return {
        capability: sum(1 for keyword in keywords if keyword in lowered)
        for capability, keywords in REPO_CAPABILITY_KEYWORDS.items()
    }


def classify_repo(repo_root: Path, available_skills: list[str]) -> RepoProfile:
    texts: list[str] = []
    key_files: list[str] = []

    for candidate in (
        repo_root / "README.md",
        repo_root / "AGENTS.md",
        repo_root / "CLAUDE.md",
        repo_root / "REVIEW.md",
        repo_root / "package.json",
        repo_root / "src" / "cli.ts",
        repo_root / "src" / "index.ts",
    ):
        if candidate.exists() and candidate.is_file():
            text = read_text_file(candidate)
            if text:
                texts.append(text[:12000])
                key_files.append(str(candidate.relative_to(repo_root)))

    combined = "\n\n".join(texts)
    capability_scores = score_repo_capabilities(combined)
    capabilities = [
        capability
        for capability, score in sorted(capability_scores.items(), key=lambda item: item[1], reverse=True)
        if score > 0
    ]

    if "session continuity and handoff" in capabilities:
        repo_kind = "continuity-cli"
    elif "cross-tool parsing and extraction" in capabilities:
        repo_kind = "parser-cli"
    elif "cli workflow and configuration" in capabilities:
        repo_kind = "workflow-cli"
    else:
        repo_kind = "general-repo"

    skill_scores: dict[str, int] = {skill: 0 for skill in available_skills}
    for capability in capabilities:
        for skill in CAPABILITY_TO_SKILLS.get(capability, []):
            if skill in skill_scores:
                skill_scores[skill] += 2

    likely_target_skills = [
        skill
        for skill, score in sorted(skill_scores.items(), key=lambda item: item[1], reverse=True)
        if score > 0
    ] or [skill for skill in DEFAULT_FOCUS_SKILLS if skill in available_skills]

    matched_priorities = choose_priorities(combined)
    summary = summarize_excerpt(combined) if combined else "No high-signal repo documents found."

    return RepoProfile(
        repo_kind=repo_kind,
        capabilities=capabilities[:5],
        likely_target_skills=likely_target_skills[:3],
        priorities=matched_priorities,
        key_files=key_files[:8],
        summary=summary,
    )


def score_file_relevance(rel_path: str, text: str, repo_profile: RepoProfile) -> tuple[int, list[str]]:
    score = 0
    reasons: list[str] = []
    path_name = Path(rel_path).name
    lowered_path = rel_path.lower()
    lowered = text.lower()

    if path_name in HIGH_SIGNAL_FILE_NAMES:
        score += 4
        reasons.append(f"high-signal file: {path_name}")
    if lowered_path.startswith("src/cli") or lowered_path.startswith("src/index"):
        score += 3
        reasons.append("entrypoint source file")
    if any(marker in lowered_path for marker in ("parser", "registry", "config", "fixture", "test")):
        score += 2
        reasons.append("implementation or validation support file")

    capability_scores = score_repo_capabilities(f"{rel_path}\n{text[:5000]}")
    for capability, capability_score in capability_scores.items():
        if capability_score > 0:
            score += min(3, capability_score)
            reasons.append(f"matches repo capability: {capability}")

    if any(skill.replace("agent-", "") in lowered for skill in repo_profile.likely_target_skills):
        score += 1
        reasons.append("mentions likely target skill concepts")

    return score, reasons


def select_candidate_files(repo_root: Path, repo_profile: RepoProfile) -> tuple[list[dict[str, Any]], int]:
    selected: list[dict[str, Any]] = []
    all_files = collect_text_files(repo_root)

    for path in all_files:
        text = read_text_file(path)
        if not text:
            continue
        rel_path = str(path.relative_to(repo_root))
        score, reasons = score_file_relevance(rel_path, text, repo_profile)
        selected.append(
            {
                "path": path,
                "rel_path": rel_path,
                "text": text,
                "score": score,
                "reasons": reasons,
            }
        )

    selected.sort(key=lambda item: (item["score"], len(item["text"])), reverse=True)
    chosen = [item for item in selected if item["score"] >= 3][:20]
    if not chosen:
        chosen = selected[:10]
    return chosen, len(all_files)


def local_skill_snapshot(skills_root: Path) -> dict[str, Any]:
    agents: dict[str, Any] = {}
    corpus: list[dict[str, str]] = []

    for skill_dir in sorted(skills_root.glob("agent-*")):
        if not skill_dir.is_dir():
            continue

        files: list[dict[str, Any]] = []
        for file_path in sorted(skill_dir.rglob("*")):
            if file_path.is_dir():
                continue
            if any(part in SKIP_DIR_NAMES for part in file_path.parts):
                continue
            if file_path.name == ".DS_Store":
                continue
            if file_path.suffix.lower() not in TEXT_FILE_EXTENSIONS and file_path.name != "SKILL.md":
                continue

            text = read_text_file(file_path)
            if not text:
                continue

            rel_path = str(file_path.relative_to(skills_root))
            files.append(
                {
                    "path": rel_path,
                    "size": len(text),
                    "kind": infer_local_kind(file_path),
                }
            )
            corpus.append(
                {
                    "path": rel_path,
                    "kind": infer_local_kind(file_path),
                    "text": text,
                }
            )

        agents[skill_dir.name] = {"files": files}

    return {"agents": agents, "corpus": corpus}


def infer_local_kind(path: Path) -> str:
    if path.name == "SKILL.md":
        return "skill"
    if path.name == "PLAYBOOK.md":
        return "playbook"
    if "references" in path.parts:
        return "reference"
    if "scripts" in path.parts:
        return "script"
    return "support"


def resolve_repo_source(repo: str, cache_dir: Path) -> tuple[Path, dict[str, Any]]:
    parsed = urlparse(repo)
    if parsed.scheme in {"http", "https", "ssh"} or repo.endswith(".git"):
        ensure_dir(cache_dir)
        repo_id = sha1_text(repo)[:12]
        target = cache_dir / repo_id
        meta = {"source": repo, "resolved_path": str(target), "mode": "git-cache"}
        if target.exists():
            run_git(["git", "-C", str(target), "fetch", "--all", "--prune"])
            run_git(["git", "-C", str(target), "reset", "--hard", "FETCH_HEAD"])
        else:
            run_git(["git", "clone", "--depth", "1", repo, str(target)])
        return target, meta

    repo_path = Path(repo).expanduser().resolve()
    if not repo_path.exists():
        raise SystemExit(f"Repository path does not exist: {repo_path}")
    return repo_path, {"source": repo, "resolved_path": str(repo_path), "mode": "local-path"}


def run_git(cmd: list[str]) -> None:
    completed = subprocess.run(cmd, capture_output=True, text=True, check=False)
    if completed.returncode != 0:
        raise SystemExit(
            "Git command failed.\n"
            f"Command: {' '.join(cmd)}\n"
            f"stderr: {completed.stderr.strip()}"
        )


def split_sections(text: str) -> list[tuple[str, str]]:
    lines = text.splitlines()
    sections: list[tuple[str, list[str]]] = []
    current_title = "Document"
    current_lines: list[str] = []

    for line in lines:
        if re.match(r"^#{1,6}\s+", line):
            if current_lines:
                sections.append((current_title, current_lines))
            current_title = re.sub(r"^#{1,6}\s+", "", line).strip()
            current_lines = []
        else:
            current_lines.append(line)

    if current_lines:
        sections.append((current_title, current_lines))

    return [(title, clean_text("\n".join(content))) for title, content in sections if clean_text("\n".join(content))]


def choose_category(text: str) -> str:
    lowered = text.lower()
    best_category = "workflow improvement"
    best_score = -1
    for category, keywords in CATEGORY_KEYWORDS.items():
        score = sum(1 for keyword in keywords if keyword in lowered)
        if score > best_score:
            best_score = score
            best_category = category
    return best_category


def choose_priorities(text: str) -> list[str]:
    lowered = text.lower()
    matches = [
        priority
        for priority, keywords in PRIORITY_KEYWORDS.items()
        if any(keyword in lowered for keyword in keywords)
    ]
    return matches or ["routing improvements"]


def choose_target_skills(
    text: str,
    available_skills: list[str],
    repo_profile: RepoProfile,
) -> tuple[list[str], bool]:
    lowered = text.lower()
    score_map: dict[str, int] = {skill: 0 for skill in available_skills}

    for skill, keywords in TARGET_SKILL_KEYWORDS.items():
        if skill not in available_skills:
            continue
        score = sum(1 for keyword in keywords if keyword in lowered)
        if score:
            score_map[skill] += score

    for rank, skill in enumerate(repo_profile.likely_target_skills):
        if skill in score_map:
            score_map[skill] += max(1, 3 - rank)

    scored = [(score, skill) for skill, score in score_map.items() if score > 0]
    if scored:
        scored.sort(reverse=True)
        best_score = scored[0][0]
        best = [skill for score, skill in scored if score == best_score]
        explicit_match = any(
            any(keyword in lowered for keyword in TARGET_SKILL_KEYWORDS.get(skill, ()))
            for skill in best
        )
        return best[:2], explicit_match

    fallback = [skill for skill in repo_profile.likely_target_skills if skill in available_skills]
    return (fallback or [skill for skill in DEFAULT_FOCUS_SKILLS if skill in available_skills]), False


def should_keep_section(title: str, text: str, file_score: int, repo_profile: RepoProfile) -> bool:
    if len(text) < 120:
        return False
    combined = f"{title}\n{text}".lower()
    useful_markers = (
        "skill",
        "agent",
        "playbook",
        "reference",
        "route",
        "routing",
        "workflow",
        "guardrail",
        "public surface",
        "picker",
        "mode",
        "lane",
        "packaging",
        "import",
        "consolidation",
        "pattern",
        "recipe",
        "evaluate",
        "evaluation",
        "verify",
        "validation",
    )
    capability_matches = any(
        any(keyword in combined for keyword in REPO_CAPABILITY_KEYWORDS.get(capability, ()))
        for capability in repo_profile.capabilities
    )
    return file_score >= 5 or capability_matches or any(marker in combined for marker in useful_markers)


def extract_candidates(
    repo_root: Path,
    snapshot: dict[str, Any],
    repo_profile: RepoProfile,
) -> tuple[list[Candidate], ExtractionDiagnostics]:
    local_corpus: list[dict[str, str]] = snapshot["corpus"]
    available_skills = sorted(snapshot["agents"].keys())
    candidates: list[Candidate] = []
    chosen_files, files_total = select_candidate_files(repo_root, repo_profile)
    sections_total = 0
    sections_kept = 0

    for file_entry in chosen_files:
        text = file_entry["text"]
        rel_path = file_entry["rel_path"]
        file_score = file_entry["score"]
        for title, section_text in split_sections(text):
            sections_total += 1
            if not should_keep_section(title, section_text, file_score, repo_profile):
                continue
            sections_kept += 1

            excerpt = summarize_excerpt(section_text)
            corpus_match = find_best_local_match(excerpt, local_corpus)
            novelty = score_novelty(corpus_match["score"])
            category = choose_category(f"{title}\n{section_text}")
            matched_priorities = sorted(
                set(choose_priorities(f"{title}\n{section_text}") + repo_profile.priorities)
            )
            target_skills, explicit_target_match = choose_target_skills(
                f"{title}\n{section_text}",
                available_skills,
                repo_profile,
            )
            target_skills, retarget_reason = retarget_from_overlap(
                f"{title}\n{section_text}",
                target_skills,
                corpus_match,
            )
            utility = score_utility(category, matched_priorities, target_skills, explicit_target_match)
            fit = score_fit(section_text, category)
            risk, warnings = score_risk(rel_path, section_text, category, target_skills)
            decision = choose_decision(novelty, utility, fit, risk, explicit_target_match)
            destination = choose_destination(decision, category, target_skills)
            decision, destination, warnings = apply_source_guardrails(
                rel_path,
                title,
                decision,
                destination,
                warnings,
            )
            candidate_id = sha1_text(f"{rel_path}:{title}:{excerpt}")[:10]
            duplicate_signals = []
            if corpus_match["path"]:
                duplicate_signals.append(
                    f"Closest local match: {corpus_match['path']} ({corpus_match['kind']}, similarity {corpus_match['score']:.2f})"
                )
            target_reason = build_target_reason(
                target_skills[0] if target_skills else "agent-composer",
                f"{title}\n{section_text}",
                corpus_match,
                retarget_reason,
            )
            rationale = build_rationale(category, matched_priorities, target_skills, novelty, utility, fit, risk)
            candidates.append(
                Candidate(
                    candidate_id=candidate_id,
                    source_path=rel_path,
                    section_title=title,
                    excerpt=excerpt,
                    category=category,
                    target_skills=target_skills,
                    target_reason=target_reason,
                    matched_priorities=matched_priorities,
                    novelty=novelty,
                    utility=utility,
                    fit=fit,
                    risk=risk,
                    decision=decision,
                    destination=destination,
                    rationale=rationale,
                    duplicate_signals=duplicate_signals,
                    warnings=warnings,
                )
            )

    sorted_candidates = sorted(
        candidates,
        key=lambda candidate: (
            decision_rank(candidate.decision),
            -candidate.utility,
            -candidate.novelty,
            candidate.risk,
        ),
    )
    diagnostics = ExtractionDiagnostics(
        files_total=files_total,
        files_selected=len(chosen_files),
        sections_total=sections_total,
        sections_kept=sections_kept,
        candidate_count=len(sorted_candidates),
        top_files=[
            {
                "path": file_entry["rel_path"],
                "score": file_entry["score"],
                "reasons": file_entry["reasons"][:3],
            }
            for file_entry in chosen_files[:10]
        ],
    )
    return sorted_candidates, diagnostics


def summarize_excerpt(text: str) -> str:
    lines = [line.strip("- ").strip() for line in text.splitlines() if line.strip()]
    summary = " ".join(lines[:4])
    summary = re.sub(r"\s+", " ", summary)
    return summary[:420]


def skill_from_local_path(path: str) -> str | None:
    if not path:
        return None
    first = path.split("/", 1)[0]
    if first.startswith("agent-"):
        return first
    return None


def keyword_score_for_skill(skill: str, text: str) -> int:
    lowered = text.lower()
    return sum(1 for keyword in TARGET_SKILL_KEYWORDS.get(skill, ()) if keyword in lowered)


def find_best_local_match(excerpt: str, corpus: list[dict[str, str]]) -> dict[str, Any]:
    best = {"path": "", "kind": "", "score": 0.0}
    for item in corpus:
        score = similarity(excerpt, item["text"][:3000])
        if score > best["score"]:
            best = {"path": item["path"], "kind": item["kind"], "score": score}
    return best


def retarget_from_overlap(
    text: str,
    current_targets: list[str],
    corpus_match: dict[str, Any],
) -> tuple[list[str], str | None]:
    overlap_skill = skill_from_local_path(corpus_match.get("path", ""))
    if not overlap_skill:
        return current_targets, None
    if corpus_match.get("score", 0.0) < 0.24:
        return current_targets, None

    overlap_score = keyword_score_for_skill(overlap_skill, text)
    current_score = keyword_score_for_skill(current_targets[0], text) if current_targets else 0

    if overlap_score == 0:
        return current_targets, None
    if current_targets and overlap_skill == current_targets[0]:
        return current_targets, None
    if overlap_score < current_score:
        return current_targets, None

    reordered = [overlap_skill] + [skill for skill in current_targets if skill != overlap_skill]
    reason = (
        f"Retargeted toward {overlap_skill} because the section semantics and closest local overlap both point there."
    )
    return reordered[:2], reason


def build_target_reason(
    primary_target: str,
    text: str,
    corpus_match: dict[str, Any],
    retarget_reason: str | None,
) -> str:
    if retarget_reason:
        return retarget_reason

    fragments: list[str] = []
    lowered = text.lower()
    if primary_target == "agent-history" and any(
        marker in lowered for marker in ("handoff", "resume", "session", "context extraction", "conversation history")
    ):
        fragments.append("section is about session continuity, handoff, or context extraction")
    elif primary_target == "agent-composer" and any(
        marker in lowered for marker in ("packaging", "import", "scaffold", "playbook", "reference")
    ):
        fragments.append("section is mainly about skill packaging, import hygiene, or composition")
    elif primary_target == "agent-orchestrator" and any(
        marker in lowered for marker in ("plan", "checkpoint", "dependency", "sequence", "verification")
    ):
        fragments.append("section is mainly about planning, checkpoints, or execution structure")
    elif primary_target == "agent-pilot" and any(
        marker in lowered for marker in ("phase", "gate", "review", "verification", "delegate")
    ):
        fragments.append("section is mainly about phased execution, gates, or coordinated delivery")

    overlap_skill = skill_from_local_path(corpus_match.get("path", ""))
    if overlap_skill == primary_target and corpus_match.get("score", 0.0) >= 0.24:
        fragments.append("closest meaningful local overlap points to the same skill")

    if not fragments:
        fragments.append("best ownership fit based on section semantics and current local overlap")
    return " and ".join(fragments)


def score_novelty(best_similarity: float) -> int:
    if best_similarity >= 0.7:
        return 1
    if best_similarity >= 0.5:
        return 2
    if best_similarity >= 0.3:
        return 3
    if best_similarity >= 0.15:
        return 4
    return 5


def score_utility(
    category: str,
    priorities: list[str],
    target_skills: list[str],
    explicit_target_match: bool,
) -> int:
    score = 1
    if category in {"routing improvement", "workflow improvement"}:
        score += 1
    if priorities:
        score += min(2, len(priorities))
    if explicit_target_match and any(skill in DEFAULT_FOCUS_SKILLS for skill in target_skills):
        score += 1
    return min(score, 5)


def score_fit(text: str, category: str) -> int:
    lowered = text.lower()
    score = 3
    if "public surface" in lowered or "playbook" in lowered or "reference" in lowered:
        score += 1
    if category == "packaging improvement":
        score += 1
    if any(marker in lowered for marker in ("vendor", "marketplace", "framework-specific", "monolithic")):
        score -= 1
    return max(1, min(score, 5))


def score_risk(source_path: str, text: str, category: str, target_skills: list[str]) -> tuple[int, list[str]]:
    lowered = text.lower()
    risk = 2
    warnings: list[str] = []

    if len(text) > 1600:
        risk += 1
        warnings.append("Long section; likely needs summarization before reuse.")
    if len(target_skills) > 1:
        risk += 1
        warnings.append("Touches multiple target skills; review destination carefully.")
    if source_path.startswith(".system/"):
        risk += 1
        warnings.append("Comes from a system skill; verify that local skill-pack conventions still fit.")
    if "new public skill" in lowered or "new picker" in lowered:
        risk += 1
        warnings.append("Suggests public-surface expansion; verify necessity.")
    if category == "packaging improvement" and "skill.md" in lowered:
        risk += 1
        warnings.append("May tempt SKILL.md growth; prefer references or playbooks first.")

    return min(risk, 5), warnings


def choose_decision(novelty: int, utility: int, fit: int, risk: int, explicit_target_match: bool) -> str:
    if novelty <= 1:
        return "reject"
    if utility >= 4 and fit >= 4 and risk <= 2 and novelty >= 4 and explicit_target_match:
        return "adopt"
    if utility >= 3 and fit >= 3 and risk <= 3 and novelty >= 3:
        return "adapt"
    if utility >= 2 and fit >= 2 and risk <= 4:
        return "store"
    return "reject"


def choose_destination(decision: str, category: str, target_skills: list[str]) -> str:
    target = target_skills[0] if target_skills else "agent-composer"

    if decision == "reject":
        return "none"
    if category == "routing improvement":
        return f"{target}/references/request-recipes.md"
    if category == "workflow improvement":
        return f"{target}/references/learned-patterns.md" if target == "agent-pilot" else f"{target}/references/"
    if category == "heuristic or reference improvement":
        return f"{target}/references/"
    if category == "packaging improvement":
        return f"{target}/references/" if decision != "adopt" else f"{target}/SKILL.md"
    return f"{target}/references/"


def apply_source_guardrails(
    rel_path: str,
    section_title: str,
    decision: str,
    destination: str,
    warnings: list[str],
) -> tuple[str, str, list[str]]:
    lowered_title = section_title.lower()
    lowered_path = rel_path.lower()
    adjusted_warnings = warnings.copy()

    if any(
        marker in lowered_path
        for marker in (
            "/prompts/",
            "redesign-backlog",
            "/handoff-pointers/",
            "/research/",
        )
    ):
        if decision in {"adopt", "adapt"}:
            decision = "store"
        if "request-recipes.md" in destination:
            destination = "agent-composer/references/"
        adjusted_warnings.append("Source is exploratory or backlog-oriented; store it unless later evidence confirms it.")

    if any(marker in lowered_title for marker in ("open question", "open issue")) or "99-open" in lowered_path:
        if decision in {"adopt", "adapt"}:
            decision = "store"
        destination = "agent-composer/references/"
        adjusted_warnings.append("Source is unresolved research material; keep as a stored reference until verified.")

    if lowered_path.endswith(".json") and section_title == "Document":
        if decision in {"adopt", "adapt"}:
            decision = "store"
        adjusted_warnings.append("Raw config/package files should be summarized before reuse.")

    return decision, destination, adjusted_warnings


def build_rationale(
    category: str,
    priorities: list[str],
    target_skills: list[str],
    novelty: int,
    utility: int,
    fit: int,
    risk: int,
) -> str:
    parts = [
        f"Category: {category}.",
        f"Priorities matched: {', '.join(priorities) if priorities else 'none'}.",
        f"Likely targets: {', '.join(target_skills) if target_skills else 'none'}.",
        f"Scores - novelty {novelty}/5, utility {utility}/5, fit {fit}/5, risk {risk}/5.",
    ]
    return " ".join(parts)


def decision_rank(decision: str) -> int:
    return {"adopt": 0, "adapt": 1, "store": 2, "reject": 3}[decision]


def summarize_guardrails(snapshot: dict[str, Any], candidates: list[Candidate]) -> list[str]:
    warnings: list[str] = []

    for skill in DEFAULT_FOCUS_SKILLS:
        skill_meta = snapshot["agents"].get(skill)
        if not skill_meta:
            continue
        skill_files = skill_meta["files"]
        for item in skill_files:
            if item["kind"] == "skill" and item["size"] > 14000:
                warnings.append(f"{item['path']} is already large ({item['size']} chars); avoid expanding SKILL.md.")

    multi_skill_candidates = [candidate for candidate in candidates if len(candidate.target_skills) > 1 and candidate.decision in {"adopt", "adapt"}]
    if multi_skill_candidates:
        warnings.append(
            f"{len(multi_skill_candidates)} candidate(s) touch multiple skills; keep edits sequential and narrow."
        )

    duplicate_candidates = [candidate for candidate in candidates if candidate.decision != "reject" and candidate.novelty <= 2]
    if duplicate_candidates:
        warnings.append(
            f"{len(duplicate_candidates)} kept candidate(s) are close to existing content; verify duplication before editing."
        )

    return warnings


def summarize_zero_result_diagnostics(
    repo_profile: RepoProfile,
    diagnostics: ExtractionDiagnostics,
) -> list[str]:
    reasons: list[str] = []

    if diagnostics.files_selected == 0:
        reasons.append("No readable text files were selected for analysis.")
    elif diagnostics.sections_total == 0:
        reasons.append("Relevant files were found, but no sections could be split from them.")
    elif diagnostics.sections_kept == 0:
        reasons.append("Sections existed, but the section relevance filter removed all of them.")
    elif diagnostics.candidate_count == 0:
        reasons.append("Candidates were filtered out by target routing or decision thresholds.")

    if not repo_profile.capabilities:
        reasons.append("Repo-level classification did not find strong capability signals in the top docs.")
    if not repo_profile.key_files:
        reasons.append("No high-signal repo files such as README.md or AGENTS.md were found.")

    return reasons or ["No specific zero-result cause detected."]


def patch_plan(candidates: list[Candidate]) -> list[dict[str, Any]]:
    planned: list[dict[str, Any]] = []
    for candidate in candidates:
        if candidate.decision == "reject":
            continue
        planned.append(
            {
                "candidate_id": candidate.candidate_id,
                "decision": candidate.decision,
                "destination": candidate.destination,
                "summary": candidate.excerpt,
                "action": (
                    "Summarize and integrate into the destination file."
                    if candidate.decision in {"adopt", "adapt"}
                    else "Store as a durable reference item for later review."
                ),
            }
        )
    return planned


def repo_history_key(source: str) -> str:
    return sha1_text(source)[:12]


def update_history(history_path: Path, source_meta: dict[str, Any], report_paths: dict[str, str], candidates: list[Candidate]) -> dict[str, Any]:
    history = load_json(history_path, {"version": 1, "repos": {}})
    key = repo_history_key(source_meta["source"])
    entry = history["repos"].get(key, {"source": source_meta["source"], "runs": []})
    entry["source"] = source_meta["source"]
    entry["resolved_path"] = source_meta["resolved_path"]
    entry["last_run_at"] = now_utc()
    entry["runs"].append(
        {
            "run_at": entry["last_run_at"],
            "reports": report_paths,
            "counts": decision_counts(candidates),
        }
    )
    entry["runs"] = entry["runs"][-10:]
    history["repos"][key] = entry
    save_json(history_path, history)
    return entry


def decision_counts(candidates: list[Candidate]) -> dict[str, int]:
    counts = {"adopt": 0, "adapt": 0, "store": 0, "reject": 0}
    for candidate in candidates:
        counts[candidate.decision] += 1
    return counts


def render_markdown_report(
    repo_label: str,
    source_meta: dict[str, Any],
    repo_profile: RepoProfile,
    diagnostics: ExtractionDiagnostics,
    candidates: list[Candidate],
    snapshot: dict[str, Any],
    guardrail_warnings: list[str],
) -> str:
    counts = decision_counts(candidates)
    lines = [
        "# Repo Evolution Report",
        "",
        f"- Generated: {now_utc()}",
        f"- Repo: `{repo_label}`",
        f"- Source mode: `{source_meta['mode']}`",
        f"- Skills reviewed: `{len(snapshot['agents'])}`",
        f"- Default focus: `{', '.join(DEFAULT_FOCUS_SKILLS)}`",
        "",
        "## Repo Profile",
        "",
        f"- Kind: `{repo_profile.repo_kind}`",
        f"- Capabilities: `{', '.join(repo_profile.capabilities) if repo_profile.capabilities else 'none detected'}`",
        f"- Likely targets: `{', '.join(repo_profile.likely_target_skills)}`",
        f"- Key files: `{', '.join(repo_profile.key_files) if repo_profile.key_files else 'none'}`",
        f"- Summary: {repo_profile.summary}",
        "",
        "## Default Contract",
        "",
        "- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.",
        f"- Guardrails: {', '.join(DEFAULT_GUARDRAILS)}",
        f"- Priorities: {', '.join(DEFAULT_PRIORITIES)}",
        "",
        "## Extraction Diagnostics",
        "",
        f"- Files scanned: {diagnostics.files_total}",
        f"- Files selected: {diagnostics.files_selected}",
        f"- Sections seen: {diagnostics.sections_total}",
        f"- Sections kept: {diagnostics.sections_kept}",
        f"- Candidates produced: {diagnostics.candidate_count}",
        "",
        "### Top Files",
        "",
    ]

    if diagnostics.top_files:
        lines.extend(
            [
                f"- `{entry['path']}` score `{entry['score']}` because {', '.join(entry['reasons']) or 'no reasons captured'}"
                for entry in diagnostics.top_files
            ]
        )
    else:
        lines.append("- None")

    lines.extend(
        [
            "",
        "## Decision Summary",
        "",
        f"- Adopt: {counts['adopt']}",
        f"- Adapt: {counts['adapt']}",
        f"- Store: {counts['store']}",
        f"- Reject: {counts['reject']}",
        "",
        "## Guardrail Warnings",
        "",
        ]
    )

    if guardrail_warnings:
        lines.extend([f"- {warning}" for warning in guardrail_warnings])
    else:
        lines.append("- None")

    if not candidates:
        lines.extend(["", "## Zero-Result Diagnostics", ""])
        lines.extend([f"- {reason}" for reason in summarize_zero_result_diagnostics(repo_profile, diagnostics)])

    lines.extend(["", "## Candidates", ""])

    for candidate in candidates[:40]:
        lines.extend(
            [
                f"### {candidate.candidate_id} - {candidate.decision.upper()}",
                "",
                f"- Source: `{candidate.source_path}`",
                f"- Section: `{candidate.section_title}`",
                f"- Category: `{candidate.category}`",
                f"- Primary target: `{candidate.target_skills[0] if candidate.target_skills else 'none'}`",
                f"- Secondary targets: `{', '.join(candidate.target_skills[1:]) if len(candidate.target_skills) > 1 else 'none'}`",
                f"- Why target: {candidate.target_reason}",
                f"- Proposed destination: `{candidate.destination}`",
                f"- Scores: novelty `{candidate.novelty}` | utility `{candidate.utility}` | fit `{candidate.fit}` | risk `{candidate.risk}`",
                f"- Priorities: `{', '.join(candidate.matched_priorities)}`",
                f"- Excerpt: {candidate.excerpt}",
                f"- Rationale: {candidate.rationale}",
            ]
        )
        if candidate.duplicate_signals:
            lines.extend([f"- Overlap check: {signal}" for signal in candidate.duplicate_signals])
        if candidate.warnings:
            lines.extend([f"- Warning: {warning}" for warning in candidate.warnings])
        lines.append("")

    return "\n".join(lines).strip() + "\n"


def build_run_payload(
    repo_label: str,
    source_meta: dict[str, Any],
    repo_profile: RepoProfile,
    diagnostics: ExtractionDiagnostics,
    candidates: list[Candidate],
    guardrail_warnings: list[str],
    history_entry: dict[str, Any],
) -> dict[str, Any]:
    return {
        "generated_at": now_utc(),
        "repo": repo_label,
        "source": source_meta,
        "repo_profile": dataclasses.asdict(repo_profile),
        "diagnostics": dataclasses.asdict(diagnostics),
        "defaults": {
            "focus_skills": DEFAULT_FOCUS_SKILLS,
            "priorities": DEFAULT_PRIORITIES,
            "guardrails": DEFAULT_GUARDRAILS,
        },
        "guardrail_warnings": guardrail_warnings,
        "zero_result_diagnostics": summarize_zero_result_diagnostics(repo_profile, diagnostics) if not candidates else [],
        "decision_counts": decision_counts(candidates),
        "patch_plan": patch_plan(candidates),
        "history": {
            "source": history_entry.get("source"),
            "last_run_at": history_entry.get("last_run_at"),
            "previous_runs": len(history_entry.get("runs", [])),
        },
        "candidates": [dataclasses.asdict(candidate) for candidate in candidates],
    }


def parse_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Analyze an external repo and generate a dry-run evolution report for local agent skills."
    )
    parser.add_argument("--repo", required=True, help="Local repo path or git URL to analyze.")
    parser.add_argument(
        "--output-dir",
        default=str(DEFAULT_OUTPUT_DIR),
        help="Directory for markdown and json reports.",
    )
    parser.add_argument(
        "--state-dir",
        default=str(DEFAULT_STATE_DIR),
        help="Directory for cache and history state.",
    )
    parser.add_argument(
        "--max-candidates",
        type=int,
        default=40,
        help="Maximum number of candidates to keep in the report.",
    )
    parser.add_argument(
        "--print-report",
        action="store_true",
        help="Print the markdown report path and summary to stdout.",
    )
    return parser.parse_args(argv)


def main(argv: list[str]) -> int:
    args = parse_args(argv)
    output_dir = Path(args.output_dir).expanduser().resolve()
    state_dir = Path(args.state_dir).expanduser().resolve()
    cache_dir = state_dir / "cache"
    history_path = state_dir / "history.json"

    ensure_dir(output_dir)
    ensure_dir(state_dir)

    snapshot = local_skill_snapshot(SKILLS_ROOT)
    available_skills = sorted(snapshot["agents"].keys())
    repo_root, source_meta = resolve_repo_source(args.repo, cache_dir)
    repo_profile = classify_repo(repo_root, available_skills)
    candidates, diagnostics = extract_candidates(repo_root, snapshot, repo_profile)
    candidates = candidates[: args.max_candidates]
    diagnostics.candidate_count = len(candidates)
    guardrail_warnings = summarize_guardrails(snapshot, candidates)

    repo_slug = slugify(Path(source_meta["resolved_path"]).name or source_meta["source"])
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d-%H%M%S")
    run_dir = output_dir / f"{repo_slug}-{timestamp}"
    ensure_dir(run_dir)

    report_paths = {
        "markdown": str(run_dir / "report.md"),
        "json": str(run_dir / "report.json"),
    }
    history_entry = update_history(history_path, source_meta, report_paths, candidates)

    markdown_report = render_markdown_report(
        args.repo,
        source_meta,
        repo_profile,
        diagnostics,
        candidates,
        snapshot,
        guardrail_warnings,
    )
    payload = build_run_payload(
        args.repo,
        source_meta,
        repo_profile,
        diagnostics,
        candidates,
        guardrail_warnings,
        history_entry,
    )

    Path(report_paths["markdown"]).write_text(markdown_report, encoding="utf-8")
    save_json(Path(report_paths["json"]), payload)

    if args.print_report:
        print(f"Report: {report_paths['markdown']}")
        print(json.dumps(payload["decision_counts"], indent=2))

    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
