# Repo Evolution Tool

Use `repo_evolution.py` to turn the recurring repo-to-skill comparison flow
into a repeatable dry-run report.

## What It Does

- snapshots the current local `agent-*` skills from disk each run
- reads a local repo path or a Git URL
- extracts reusable candidate patterns from the repo
- compares them against the local skill corpus
- scores each candidate by `novelty`, `utility`, `fit`, and `risk`
- chooses `adopt`, `adapt`, `store`, or `reject`
- suggests a likely destination such as `SKILL.md`, `PLAYBOOK.md`,
  `references/`, or `learned-patterns.md`
- writes a markdown report and a JSON payload
- stores lightweight history so repeated runs against the same repo are tracked

## Usage

```bash
python3 /Users/hanyramadan/.codex/skills/agent-composer/scripts/repo_evolution.py \
  --repo /path/to/repo \
  --print-report
```

For a Git URL:

```bash
python3 /Users/hanyramadan/.codex/skills/agent-composer/scripts/repo_evolution.py \
  --repo https://github.com/example/project.git \
  --print-report
```

## Default Behavior

The tool follows the same repo-evolution defaults documented for
`agent-composer`:

- dry-run first
- prefer `PLAYBOOK.md` and `references/` before `SKILL.md`
- no bloat
- no over-engineering
- no routing breakage
- default focus on `agent-pilot`, `agent-composer`, and `agent-orchestrator`

## Output

Reports are written under:

`/Users/hanyramadan/.codex/skills/agent-composer/artifacts/repo-evolution/`

State is written under:

`/Users/hanyramadan/.codex/skills/agent-composer/state/repo-evolution/`
