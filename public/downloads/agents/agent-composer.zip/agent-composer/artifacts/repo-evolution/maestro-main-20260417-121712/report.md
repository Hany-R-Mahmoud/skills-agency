# Repo Evolution Report

- Generated: 2026-04-17T12:17:12.028004+00:00
- Repo: `/tmp/agent-composer-maestro/maestro-main`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `cli workflow and configuration, verification and quality gates, packaging and import hygiene, cross-tool parsing and extraction, session continuity and handoff`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, package.json`
- Summary: <div align="center"> <img src="assets/logo.svg" alt="Maestro" width="80" /> # Maestro **Workflow fluency for AI coding agents.**

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 94
- Files selected: 20
- Sections seen: 146
- Sections kept: 129
- Candidates produced: 40

### Top Files

- `README.md` score `14` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration
- `source/skills/agent-workflow/reference/guardrails-safety.md` score `13` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `maestro-extension/README.md` score `12` because high-signal file: README.md, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `mcp-server/README.md` score `12` because high-signal file: README.md, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `source/skills/diagnose/SKILL.md` score `11` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `maestro-extension/webview-ui/README.md` score `11` because high-signal file: README.md, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `maestro-extension/scripts/test-chat-commands.js` score `10` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration
- `source/skills/specialize/SKILL.md` score `10` because matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `maestro-extension/package.json` score `9` because high-signal file: package.json, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `source/skills/temper/SKILL.md` score `9` because matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates

## Decision Summary

- Adopt: 2
- Adapt: 38
- Store: 0
- Reject: 0

## Guardrail Warnings

- 4 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### f9b64a39b5 - ADOPT

- Source: `README.md`
- Section: `Maestro`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `5` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Workflow fluency for AI coding agents.** [![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE) [![Version](https://img.shields.io/badge/version-1.3.1-brightgreen.svg)](https://github.com/sharpdeveye/maestro/releases) [![npm](https://img.shields.io/npm/v/maestro-workflow-mcp.svg?label=npm&color=cb3837)](https://www.npmjs.com/package/maestro-workflow-mcp)
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 5/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.14)

### 528e3b3bfc - ADOPT

- Source: `maestro-extension/README.md`
- Section: `🔗 Ecosystem`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Component | Description | |-----------|-------------| | [MCP Server](https://www.npmjs.com/package/maestro-workflow-mcp) | Use Maestro as a live MCP server — `npx maestro-workflow-mcp` | | [Website](https://maestroskills.dev) | Interactive showcase and documentation |
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-docs/SKILL.md (skill, similarity 0.29)

### 22ef288749 - ADAPT

- Source: `maestro-extension/README.md`
- Section: `🔄 Multi-Provider Skill Sync`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: On every activation, Maestro syncs all 22 bundled skills into **10 AI provider directories** simultaneously: `.agents/` · `.cursor/` · `.claude/` · `.gemini/` · `.codex/` · `.kiro/` · `.trae/` · `.trae-cn/` · `.opencode/` · `.pi/` Your skills are always available regardless of which AI tool you use. 
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/SKILL.md (skill, similarity 0.25)

### f07469bfcb - ADAPT

- Source: `mcp-server/README.md`
- Section: `Prompts`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 21 prompt templates — one per command. Select from your client's prompt picker: `diagnose` · `evaluate` · `refine` · `streamline` · `calibrate` · `fortify` · `zero-defect` · `amplify` · `compose` · `enrich` · `accelerate` · `chain` · `guard` · `iterate` · `temper` · `turbocharge` · `extract-pattern` · `adapt-workflow` · `onboard-agent` · `specialize` · `teach-maestro`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/SKILL.md (skill, similarity 0.25)

### e91702abf4 - ADAPT

- Source: `maestro-extension/CHANGELOG.md`
- Section: `Added`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Animated Maestro logo** — equalizer-style animation in the sidebar header using Framer Motion **Multi-provider skill sync** — 22 bundled skills auto-install into 10 AI provider directories (`.agents/`, `.cursor/`, `.claude/`, `.gemini/`, `.codex/`, `.kiro/`, `.trae/`, `.trae-cn/`, `.opencode/`, `.pi/`) on every activation **Antigravity native integration** — uses `antigravity.sendPromptToAgentPanel` for direct slas
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/SKILL.md (skill, similarity 0.28)

### c7a473c645 - ADAPT

- Source: `maestro-extension/CHANGELOG.md`
- Section: `Added`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Command Center sidebar** — webview panel with all 21 commands organized by category (Analysis, Fix & Improve, Enhancement, Utility) **Zero-Defect Mode toggle** — status bar item and sidebar switch for activating precision rules **`@maestro` Chat Participant** — use `@maestro /command` directly in VS Code chat **`.maestro.md` auto-detection** — status indicator and one-click initialization
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.25)

### db6aeab4fc - ADAPT

- Source: `source/skills/diagnose/SKILL.md`
- Section: `Dimension 2: Context Efficiency (1-5)`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Evaluate: Context budget allocation (planned vs. ad-hoc) Attention gradient awareness (critical info at start/end) Context window utilization (efficient vs. wasteful)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/bolder/PLAYBOOK.md (playbook, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 594d46ea8c - ADAPT

- Source: `source/skills/diagnose/SKILL.md`
- Section: `Recommended Next Step`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: After diagnosis, run the command mapped to your lowest-scoring dimension. For a general improvement sequence: `{{command_prefix}}fortify` → `{{command_prefix}}streamline` → `{{command_prefix}}refine`. **NEVER**: Give all 5s unless the workflow is genuinely production-excellent Skip dimensions — score all 5 even if some seem fine
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.24)
- Warning: Touches multiple target skills; review destination carefully.

### 7e378912ea - ADAPT

- Source: `source/skills/specialize/SKILL.md`
- Section: `Step 4: Domain Guardrails`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Legal**: "Not legal advice" disclaimer, jurisdiction limitations **Medical**: "Not medical advice" disclaimer, emergency detection **Financial**: Regulatory disclosures, suitability warnings **Code**: Security scanning, dependency vulnerability checks
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-orchestrator/references/quality-gate-patterns.md (reference, similarity 0.20)
- Warning: Touches multiple target skills; review destination carefully.

### b7db14cae7 - ADAPT

- Source: `README.md`
- Section: `What is Maestro?`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: AI agents are only as good as the workflows they operate in. Without guidance, you get the same predictable mistakes: unstructured prompts, context window overflows, tool sprawl, no error handling, and multi-agent systems for single-agent problems. Maestro fights that pattern with: A comprehensive **agent-workflow** skill with 7 domain-specific reference files ([view source](source/skills/agent-workflow)) **21 comman
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/SKILL.md (skill, similarity 0.40)

### af6667b44b - ADAPT

- Source: `README.md`
- Section: `Quick Start`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash npx skills add sharpdeveye/maestro ``` Then use any command in your AI coding agent:
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.46)

### 99596e1b66 - ADAPT

- Source: `README.md`
- Section: `Analysis — read-only, generate reports`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Command | Purpose | |---------|---------| | [`/diagnose`](source/skills/diagnose/SKILL.md) | Systematic workflow quality audit with scored dimensions | | [`/evaluate`](source/skills/evaluate/SKILL.md) | Holistic review of workflow interaction quality |
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/SKILL.md (skill, similarity 0.47)

### 06f76f1df7 - ADAPT

- Source: `README.md`
- Section: `Fix & Improve — make targeted changes`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Command | Purpose | |---------|---------| | [`/refine`](source/skills/refine/SKILL.md) | Final quality pass on prompts, tools, and configuration | | [`/streamline`](source/skills/streamline/SKILL.md) | Remove unnecessary complexity, flatten over-engineering |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/references/skill-map.md (reference, similarity 0.45)

### 633b9ecd11 - ADAPT

- Source: `README.md`
- Section: `Anti-Patterns ("Workflow Slop")`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The skill includes explicit guidance on what to avoid: Don't dump entire codebases/databases into context Don't use multi-agent systems for single-agent problems Don't skip error handling (happy path only = production failure)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/SKILL.md (skill, similarity 0.48)

### 04db619432 - ADAPT

- Source: `maestro-extension/README.md`
- Section: `Enhancement — add capabilities`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Command | Description | |---------|-------------| | `/amplify` | Boost capabilities with better tools and context | | `/chain` | Build effective tool chains and pipelines |
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/SKILL.md (skill, similarity 0.38)

### 3ddfc5b6d6 - ADAPT

- Source: `mcp-server/README.md`
- Section: `maestro-workflow-mcp`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: MCP server for [Maestro](https://github.com/sharpdeveye/maestro) — exposes 22 workflow skills as tools, prompts, and resources for any MCP-compatible AI client.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.33)

### 91ed8d39f5 - ADAPT

- Source: `source/skills/agent-workflow/SKILL.md`
- Section: `1. Prompt Engineering`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **DO**: Use structured prompts with clear sections (role, context, instructions, output format) Define output schemas explicitly (JSON schema, markdown template, typed response) Use few-shot examples for ambiguous tasks
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.38)

### c30ba79b5a - ADAPT

- Source: `source/skills/agent-workflow/SKILL.md`
- Section: `2. Context Management`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **DO**: Budget context window usage (system prompt, examples, user input, tool results, output) Place critical information at the start AND end of context (attention gradient) Use retrieval (RAG) instead of stuffing full documents
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-researcher/SKILL.md (skill, similarity 0.43)

### 78e7dc4428 - ADAPT

- Source: `source/skills/agent-workflow/SKILL.md`
- Section: `6. Knowledge Systems`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **DO**: Choose retrieval strategy based on query type (semantic, keyword, hybrid) Chunk documents thoughtfully (semantic boundaries, not arbitrary token counts) Include source attribution in every retrieved result
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.30)

### 460509d8aa - ADAPT

- Source: `source/skills/agent-workflow/SKILL.md`
- Section: `7. Guardrails & Safety`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **DO**: Validate inputs before processing (schema validation, size limits) Filter outputs for sensitive content, PII, and policy violations Set hard cost ceilings (max tokens, max API calls, max spend per run)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-researcher/SKILL.md (skill, similarity 0.36)

### e882749e01 - ADAPT

- Source: `source/skills/zero-defect/SKILL.md`
- Section: `The 8 Precision Rules`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Follow these for the **entire session** after this command is invoked: | # | Rule | Why | |---|------|-----| | 1 | **Read before writing** — Re-read the relevant code/context before every modification | Prevents edits based on stale mental models |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/clarify/PLAYBOOK.md (playbook, similarity 0.42)

### 9c7c492cbd - ADAPT

- Source: `source/skills/zero-defect/SKILL.md`
- Section: `Recommended Next Step`
- Category: `workflow improvement`
- Primary target: `agent-pilot`
- Secondary targets: `none`
- Why target: section is mainly about phased execution, gates, or coordinated delivery
- Proposed destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: After the critical work is done, run `{{command_prefix}}evaluate` to review the output quality, or `{{command_prefix}}refine` for a final polish pass. **NEVER**: Skip the pre-commit gate because "it's a small change" Claim completion without running verification commands
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-pilot. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/references/autonomy-patterns.md (reference, similarity 0.45)

### 1e20b9ffda - ADAPT

- Source: `maestro-extension/scripts/test-chat-commands.js`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: /** * test-chat-commands.js * * A Node.js test runner script to evaluate Antigravity/VS Code chat-related commands.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-tester/references/eval-regression-patterns.md (reference, similarity 0.40)
- Warning: Long section; likely needs summarization before reuse.

### 9b31d6d0ec - ADAPT

- Source: `source/skills/zero-defect/SKILL.md`
- Section: `The Pre-Commit Gate`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-orchestrator because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Before claiming ANY work is complete, pass every item: [ ] Code compiles / lints clean (run the actual command) [ ] Tests pass (run the actual command) [ ] Every new import/dependency actually exists
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-orchestrator/references/quality-gate-patterns.md (reference, similarity 0.45)
- Warning: Touches multiple target skills; review destination carefully.

### 81d3362ac6 - ADAPT

- Source: `README.md`
- Section: `Remote (HTTP)`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Host Maestro as a public MCP endpoint: ```bash npx maestro-workflow-mcp --http --port 3001 ```
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.27)

### a84268f6cd - ADAPT

- Source: `source/skills/agent-workflow/reference/guardrails-safety.md`
- Section: `Layer 1: Input Validation`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Validate everything before it reaches the model: **Schema validation**: Does the input match the expected format? **Size limits**: Is the input within acceptable length? **Sanitization**: Remove or escape potentially harmful content
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/adapt/PLAYBOOK.md (playbook, similarity 0.29)

### 952807c1bd - ADAPT

- Source: `source/skills/agent-workflow/reference/guardrails-safety.md`
- Section: `Layer 4: Output Filtering`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Check outputs before surfacing to users: **PII detection**: Names, emails, phone numbers, SSNs, addresses **Content policy**: Harmful, illegal, or inappropriate content **Format validation**: Output matches expected schema
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/clarify/PLAYBOOK.md (playbook, similarity 0.21)

### f726e11ddf - ADAPT

- Source: `source/skills/agent-workflow/reference/guardrails-safety.md`
- Section: `Layer 5: Cost Controls`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Prevent runaway costs: ```yaml Cost ceiling configuration: max_tokens_per_request: 4000
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/skill-map.md (reference, similarity 0.17)

### dfa438db46 - ADAPT

- Source: `source/skills/agent-workflow/reference/guardrails-safety.md`
- Section: `Layer 6: Audit Logging`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Log everything (redacting sensitive data): ```json { "timestamp": "2026-01-15T10:30:00Z",
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-history/references/session-continuity-patterns.md (reference, similarity 0.20)

### 4358423767 - ADAPT

- Source: `maestro-extension/README.md`
- Section: `Maestro — AI Workflow Fluency`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **21 commands for production-grade AI agent workflows.** [![VS Code](https://img.shields.io/visual-studio-marketplace/v/sharpdeveye.maestro-workflow?label=Marketplace&color=007ACC&logo=visual-studio-code)](https://marketplace.visualstudio.com/items?itemName=sharpdeveye.maestro-workflow) [![Installs](https://img.shields.io/visual-studio-marketplace/i/sharpdeveye.maestro-workflow?color=blue)](https://marketplace.visual
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/SKILL.md (skill, similarity 0.23)

### 87b1b14361 - ADAPT

- Source: `maestro-extension/README.md`
- Section: `🎛️ Command Center Sidebar`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Browse all 21 Maestro commands organized into four categories — **Analysis**, **Fix & Improve**, **Enhancement**, and **Utility**. Click any command to instantly inject it into your AI chat panel. ![Command Center](media/sidebar-preview.png)
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.22)

### a6ff9794ea - ADAPT

- Source: `mcp-server/README.md`
- Section: `Remote (HTTP)`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Start as a public HTTP endpoint: ```bash npx maestro-workflow-mcp --http --port 3001 ```
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.27)

### d8c4948ec7 - ADAPT

- Source: `source/skills/diagnose/SKILL.md`
- Section: `Dimension 4: Architecture Fitness (1-5)`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Evaluate: Topology appropriateness (single vs. multi-agent justified) Agent boundaries (clear vs. overlapping) Handoff protocols (structured vs. ad-hoc)
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.29)

### 1ecf7db557 - ADAPT

- Source: `source/skills/specialize/SKILL.md`
- Section: `Recommended Next Step`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: After specialization, run `{{command_prefix}}evaluate` with domain-specific scenarios, then `{{command_prefix}}guard` to add domain-appropriate safety guardrails. **NEVER**: Specialize without consulting domain experts or authoritative sources Skip domain-specific guardrails
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md (playbook, similarity 0.29)

### 8bf6a39250 - ADAPT

- Source: `source/skills/guard/SKILL.md`
- Section: `Guard Checklist`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: [ ] All inputs validated before processing [ ] PII detection on all outputs [ ] Cost ceiling set with enforcement [ ] Prompt injection defenses active
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/SKILL.md (skill, similarity 0.29)

### 013ba9e9bd - ADAPT

- Source: `README.md`
- Section: `Combine Commands`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```text /diagnose /calibrate /refine # Full workflow: audit → standardize → polish /evaluate /fortify /accelerate # Review → harden → optimize ```
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/references/skill-map.md (reference, similarity 0.47)

### 0852c07014 - ADAPT

- Source: `README.md`
- Section: `MCP Server`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Use Maestro as a live MCP server instead of static skill files. Any MCP-compatible client can connect — no file copying required.
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.35)

### 3d13fed0f1 - ADAPT

- Source: `README.md`
- Section: `Local (stdio)`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Add to your MCP client config (Claude Desktop, Cursor, VS Code, etc.): ```json { "mcpServers": {
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.42)

### 912b445eca - ADAPT

- Source: `README.md`
- Section: `What the MCP Server Exposes`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Type | Count | Description | |------|-------|-------------| | **Prompts** | 21 | One per command — select from the prompt picker | | **Tools** | 4 | `list_commands`, `run_command`, `read_context`, `init` |
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.42)

### 3463b971b0 - ADAPT

- Source: `source/skills/agent-workflow/reference/guardrails-safety.md`
- Section: `Defense in Depth`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Safety is not one layer — it's multiple independent layers: ```text ┌─────────────────────────────────────┐ │ Layer 1: INPUT VALIDATION │ Schema checks, size limits, sanitization
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/clarify/PLAYBOOK.md (playbook, similarity 0.40)
