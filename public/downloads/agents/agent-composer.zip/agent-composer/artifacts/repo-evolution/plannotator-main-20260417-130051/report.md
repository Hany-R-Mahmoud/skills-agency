# Repo Evolution Report

- Generated: 2026-04-17T13:00:51.967405+00:00
- Repo: `/tmp/plannotator-main`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `cli workflow and configuration, verification and quality gates, packaging and import hygiene, session continuity and handoff, cross-tool parsing and extraction`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, AGENTS.md, CLAUDE.md, package.json`
- Summary: <p align="center"> <img src="apps/marketing/public/og-image.webp" alt="Plannotator" width="80%" /> </p> # Plannotator

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 515
- Files selected: 20
- Sections seen: 212
- Sections kept: 183
- Candidates produced: 40

### Top Files

- `apps/pi-extension/README.md` score `15` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration
- `apps/hook/README.md` score `14` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `apps/hook/server/index.ts` score `13` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `AGENTS.md` score `13` because high-signal file: AGENTS.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `CLAUDE.md` score `13` because high-signal file: CLAUDE.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `README.md` score `13` because high-signal file: README.md, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `apps/marketing/src/content/blog/plannotator-meets-pi.md` score `12` because matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `packages/shared/config.ts` score `12` because implementation or validation support file, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `apps/opencode-plugin/README.md` score `12` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `tests/devcontainer/README.md` score `12` because high-signal file: README.md, implementation or validation support file, matches repo capability: cli workflow and configuration

## Decision Summary

- Adopt: 1
- Adapt: 39
- Store: 0
- Reject: 0

## Guardrail Warnings

- 34 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### 96b7a3e8d8 - ADOPT

- Source: `apps/marketing/src/content/docs/getting-started/configuration.md`
- Section: `Environment variables`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Variable | Default | Description | |----------|---------|-------------| | `PLANNOTATOR_REMOTE` | auto-detect | Set to `1` or `true` to force remote mode, `0` or `false` to force local mode, or leave unset to auto-detect via `SSH_TTY` / `SSH_CONNECTION`. Uses a fixed port in remote mode; browser-opening behavior depends on the environment. | | `PLANNOTATOR_PORT` | random (local) / `19432` (remote) | Fixed server por
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.19)

### 367de5bb9b - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Shared Plannotator event API`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Plannotator also listens on the shared `plannotator:request` event channel so other extensions can reuse the same browser review flows without importing Plannotator internals. Supported actions and payloads: `plan-review`: `{ planContent, planFilePath? }` `review-status`: `{ reviewId }`
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/stored-items/REGISTRY.md (reference, similarity 0.29)

### e13b53c58c - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Install`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **From npm** (recommended): ```bash pi install npm:@plannotator/pi-extension ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 8dc6a305aa - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Top-level shape`
- Category: `workflow improvement`
- Primary target: `agent-pilot`
- Secondary targets: `agent-orchestrator`
- Why target: section is mainly about phased execution, gates, or coordinated delivery
- Proposed destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```json { "defaults": { "model": { "provider": "anthropic", "id": "claude-sonnet-4-5" },
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-pilot, agent-orchestrator. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/skill-map.md (reference, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### f83517607d - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Behavior notes`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Unknown template variables trigger a warning in the UI and are rendered as empty strings. `activeTools` are additive with the tools currently active in the session, so Plannotator still preserves tools provided by other extensions. Execution progress remains dynamic (`[DONE:n]` + checklist tracking), even if `statusLabel` is set.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-orchestrator/modes/plan-execution/PLAYBOOK.md (playbook, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 00e341f2f3 - ADAPT

- Source: `apps/hook/README.md`
- Section: `Obsidian Integration`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Approved plans can be automatically saved to your Obsidian vault. **Setup:** 1. Open Settings (gear icon) in Plannotator 2. Enable "Obsidian Integration"
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/spatial-design.md (support, similarity 0.25)
- Warning: Touches multiple target skills; review destination carefully.

### 44dcdd299d - ADAPT

- Source: `AGENTS.md`
- Section: `Annotate Server (`packages/server/annotate.ts`)`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Endpoint | Method | Purpose | | --------------------- | ------ | ------------------------------------------ | | `/api/plan` | GET | Returns `{ plan, origin, mode: "annotate", filePath, sourceInfo? }` | | `/api/feedback` | POST | Submit annotations (body: feedback, annotations) |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-orchestrator/references/quality-gate-patterns.md (reference, similarity 0.24)
- Warning: Touches multiple target skills; review destination carefully.

### 5c0cbb12aa - ADAPT

- Source: `AGENTS.md`
- Section: `Paste Service (`apps/paste-service/`)`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Endpoint | Method | Purpose | | --------------------- | ------ | ------------------------------------------ | | `/api/paste` | POST | Store compressed plan data, returns `{ id }` | | `/api/paste/:id` | GET | Retrieve stored compressed data |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/stored-items/README.md (reference, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 4e5fe52675 - ADAPT

- Source: `AGENTS.md`
- Section: `Marketing Site`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `apps/marketing/` is the plannotator.ai website — landing page, documentation, and blog. Built with Astro 5 (static output, zero client JS except a theme toggle island). Docs are markdown files in `src/content/docs/`, blog posts in `src/content/blog/`, both using Astro content collections. Tailwind CSS v4 via `@tailwindcss/vite`. Deploys to S3/CloudFront via GitHub Actions on push to main.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### f57ac2e05b - ADAPT

- Source: `CLAUDE.md`
- Section: `Annotate Server (`packages/server/annotate.ts`)`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Endpoint | Method | Purpose | | --------------------- | ------ | ------------------------------------------ | | `/api/plan` | GET | Returns `{ plan, origin, mode: "annotate", filePath, sourceInfo? }` | | `/api/feedback` | POST | Submit annotations (body: feedback, annotations) |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-orchestrator/references/quality-gate-patterns.md (reference, similarity 0.24)
- Warning: Touches multiple target skills; review destination carefully.

### 42e0726867 - ADAPT

- Source: `CLAUDE.md`
- Section: `Paste Service (`apps/paste-service/`)`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Endpoint | Method | Purpose | | --------------------- | ------ | ------------------------------------------ | | `/api/paste` | POST | Store compressed plan data, returns `{ id }` | | `/api/paste/:id` | GET | Retrieve stored compressed data |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/stored-items/README.md (reference, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### e934b0db90 - ADAPT

- Source: `CLAUDE.md`
- Section: `Marketing Site`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `apps/marketing/` is the plannotator.ai website — landing page, documentation, and blog. Built with Astro 5 (static output, zero client JS except a theme toggle island). Docs are markdown files in `src/content/docs/`, blog posts in `src/content/blog/`, both using Astro content collections. Tailwind CSS v4 via `@tailwindcss/vite`. Deploys to S3/CloudFront via GitHub Actions on push to main.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### a2eb01d992 - ADAPT

- Source: `README.md`
- Section: `Install for Gemini CLI`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Install the `plannotator` command:** **macOS / Linux / WSL:** ```bash curl -fsSL https://plannotator.ai/install.sh | bash
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.27)
- Warning: Touches multiple target skills; review destination carefully.

### c865b8f98e - ADAPT

- Source: `README.md`
- Section: `Install for OpenCode`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Add to your `opencode.json`: ```json { "plugin": ["@plannotator/opencode@latest"]
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### aa07a5d105 - ADAPT

- Source: `README.md`
- Section: `Install for Pi`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash pi install npm:@plannotator/pi-extension ``` Then start Pi with `--plan` to enter plan mode, or toggle it during a session with `/plannotator`.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### f11bee7371 - ADAPT

- Source: `README.md`
- Section: `Install for Codex`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Install the `plannotator` command:** **macOS / Linux / WSL:** ```bash curl -fsSL https://plannotator.ai/install.sh | bash
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.27)
- Warning: Touches multiple target skills; review destination carefully.

### 7855942a88 - ADAPT

- Source: `apps/marketing/src/content/blog/plannotator-meets-pi.md`
- Section: `Watch the Demo`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: <iframe width="100%" style="aspect-ratio: 16/9;" src="https://www.youtube.com/embed/XqFun9XCXPw?si=BbjywvxWPONkLRij" title="Plannotator for Pi" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/responsive-design.md (support, similarity 0.23)
- Warning: Touches multiple target skills; review destination carefully.

### cb219d3cdc - ADAPT

- Source: `apps/marketing/src/content/blog/plannotator-meets-pi.md`
- Section: `Install`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash pi install npm:@plannotator/pi-extension ``` Or try it without installing:
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.25)
- Warning: Touches multiple target skills; review destination carefully.

### 4570bc2632 - ADAPT

- Source: `apps/marketing/src/content/blog/plannotator-meets-pi.md`
- Section: `Review phase`
- Category: `workflow improvement`
- Primary target: `agent-pilot`
- Secondary targets: `agent-orchestrator`
- Why target: section is mainly about phased execution, gates, or coordinated delivery
- Proposed destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: When the agent calls `plannotator_submit_plan`, the extension reads `PLAN.md` from disk, starts a local HTTP server, and opens the Plannotator browser UI. You see the rendered plan with all the annotation tools — comments, deletions, replacements, insertions. Three outcomes: **Approve** — the extension transitions to the executing phase. The agent gets full tool access. **Approve with notes** — same transition, but t
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-pilot, agent-orchestrator. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/overdrive/PLAYBOOK.md (playbook, similarity 0.28)
- Warning: Touches multiple target skills; review destination carefully.

### 9aab3e31e4 - ADAPT

- Source: `apps/marketing/src/content/blog/plannotator-meets-pi.md`
- Section: `The Node.js constraint`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Pi loads extensions via [jiti](https://github.com/unjs/jiti), which runs in Node.js — not Bun. The shared Plannotator server code in `packages/server/` uses `Bun.serve()`, which doesn't work here. The Pi extension includes its own server implementation using `node:http`. It's a stripped-down version of the shared server — same API endpoints, same HTML payloads, same behavior — but built on `createServer` instead of B
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.23)
- Warning: Touches multiple target skills; review destination carefully.

### 73e67b2522 - ADAPT

- Source: `apps/marketing/src/content/blog/plannotator-meets-pi.md`
- Section: `Code review and annotation`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The Pi extension includes the same `/plannotator-review` and `/plannotator-annotate` commands as the Claude Code and OpenCode integrations: **`/plannotator-review`** — captures `git diff HEAD`, opens the diff viewer in your browser. You annotate lines, switch between diff types (uncommitted, last commit, vs default branch), and submit feedback. The extension sends the formatted feedback back to the agent as a user me
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/overdrive/PLAYBOOK.md (playbook, similarity 0.26)
- Warning: Touches multiple target skills; review destination carefully.

### 613e306974 - ADAPT

- Source: `apps/marketing/src/content/blog/plannotator-meets-pi.md`
- Section: `Try it`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash pi install npm:@plannotator/pi-extension pi --plan ```
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-architect/references/architecture-depth-map.md (reference, similarity 0.17)
- Warning: Touches multiple target skills; review destination carefully.

### 706d495ee4 - ADAPT

- Source: `apps/opencode-plugin/README.md`
- Section: `How It Works`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. Agent calls `submit_plan` → Plannotator opens in your browser 2. Select text → annotate (delete, replace, comment) 3. **Approve** → Agent proceeds with implementation 4. **Request changes** → Annotations sent back as structured feedback
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-orchestrator/references/quality-gate-patterns.md (reference, similarity 0.28)
- Warning: Touches multiple target skills; review destination carefully.

### b1430ae7fc - ADAPT

- Source: `tests/bench-startup.sh`
- Section: `── Scenario 2: Published npm plugin ─────────────────────────────────`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: echo "━━━ Scenario 2: Published npm plugin (@plannotator/opencode) ━━━" write_config '["@plannotator/opencode@latest"]' clear_plugin_cache npm_times=()
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.23)
- Warning: Touches multiple target skills; review destination carefully.

### 045b9cc767 - ADAPT

- Source: `tests/manual/local/sandbox-gemini.sh`
- Section: `--- Install Gemini config ---`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: echo "Installing Gemini policy..." mkdir -p "$GEMINI_DIR/policies" cp "$PROJECT_ROOT/apps/gemini/hooks/plannotator.toml" "$GEMINI_DIR/policies/plannotator.toml" echo "Configuring Gemini hook (pointing to local source)..."
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/stored-items/REGISTRY.md (reference, similarity 0.28)
- Warning: Touches multiple target skills; review destination carefully.

### c486368a8e - ADAPT

- Source: `tests/manual/local/sandbox-gemini.sh`
- Section: `Verification`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Output should be exactly: `Hello, World!` ```python print("Hello, World!") ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### d384790bb7 - ADAPT

- Source: `tests/manual/local/sandbox-gemini.sh`
- Section: `--- Mode: nightly ---`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: if [ "$MODE" = "--nightly" ]; then echo "Installing Gemini CLI nightly (includes exit_plan_mode fix)..." npm install -g @google/gemini-cli@nightly 2>&1 | tail -3 echo ""
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.20)
- Warning: Touches multiple target skills; review destination carefully.

### c6d65a62ae - ADAPT

- Source: `tests/manual/local/sandbox-gemini.sh`
- Section: `--- Run Gemini ---`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: GEMINI_BIN="" if [ "$MODE" = "--nightly" ]; then GEMINI_BIN="gemini" elif [ -f "$HOME/gemini-cli/packages/cli/dist/index.js" ]; then
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.27)
- Warning: Touches multiple target skills; review destination carefully.

### a6d15d405a - ADAPT

- Source: `apps/marketing/src/content/docs/guides/ai-features.md`
- Section: `OpenCode (via OpenCode SDK)`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Requires the `opencode` CLI installed and authenticated. Plannotator spawns `opencode serve` and communicates via HTTP + SSE. Models are discovered dynamically from your connected providers. OpenCode supports session forking, resuming, and runtime permission approvals — the richest capability set of all four providers.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.26)
- Warning: Touches multiple target skills; review destination carefully.

### b0b8208585 - ADAPT

- Source: `apps/gemini/README.md`
- Section: `Install`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Install the `plannotator` command:** **macOS / Linux / WSL:** ```bash curl -fsSL https://plannotator.ai/install.sh | bash
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.27)
- Warning: Touches multiple target skills; review destination carefully.

### eee34c962e - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Option reference`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Option | Type | Meaning | |--------|------|---------| | `defaults` | object | Base values applied to every phase before phase-specific overrides | | `phases` | object | Phase-specific overrides |
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/arrange/PLAYBOOK.md (playbook, similarity 0.36)

### 4b7a7415de - ADAPT

- Source: `apps/marketing/src/content/blog/plannotator-meets-pi.md`
- Section: `Planning phase`
- Category: `workflow improvement`
- Primary target: `agent-pilot`
- Secondary targets: `none`
- Why target: section is mainly about phased execution, gates, or coordinated delivery
- Proposed destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Start plan mode with `pi --plan` or toggle it mid-session with `/plannotator` or `Ctrl+Alt+P`. The extension immediately restricts the agent's available tools: **Read-only access** — `read`, `grep`, `find`, `ls` all work normally **Bash is gated** — every command is checked against a safety allowlist before execution. `cat`, `git status`, `ls`, `find`, `rg` pass. `rm`, `git commit`, `npm install`, `sudo` don't. The a
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-pilot. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md (playbook, similarity 0.32)

### d7625d1c32 - ADAPT

- Source: `.agents/skills/update-deps/SKILL.md`
- Section: `Update Dependencies`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Audit outdated packages, verify supply chain integrity, bump what's safe, defer what needs review, and log everything. This process has three phases: discovery, integrity audit, and execution. The integrity audit is the most important — every package gets checked before it touches the lockfile.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/references/quality-gate-patterns.md (reference, similarity 0.39)

### 26f666d428 - ADAPT

- Source: `apps/marketing/src/content/docs/getting-started/configuration.md`
- Section: `Disabling sharing`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Set `PLANNOTATOR_SHARE=disabled` to remove all sharing UI — the Share tab, copy link action, and import review option are all hidden. Useful for teams working with sensitive plans. To self-host the share portal instead, see the [self-hosting guide](/docs/guides/self-hosting/).
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/SKILL.md (skill, similarity 0.35)

### 216d458ecc - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Plannotator for Pi`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Plannotator integration for the [Pi coding agent](https://github.com/badlogic/pi-mono/tree/main/packages/coding-agent). Adds file-based plan mode with a visual browser UI for reviewing, annotating, and approving agent plans.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-orchestrator/modes/plan-execution/PLAYBOOK.md (playbook, similarity 0.44)
- Warning: Touches multiple target skills; review destination carefully.

### 5ecaaf1dc8 - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Build from source`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: If installing from a local clone, build the HTML assets first: ```bash cd plannotator bun install
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-stitch/modes/generate-design/PLAYBOOK.md (playbook, similarity 0.46)
- Warning: Touches multiple target skills; review destination carefully.

### bcd0d802f6 - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Configuring per-phase behavior`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Plannotator loads configuration in three layers: 1. Built-in base config shipped with the package: `plannotator.json` 2. Global user config: `~/.pi/agent/plannotator.json` 3. Project-local config: `<cwd>/.pi/plannotator.json`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.47)
- Warning: Touches multiple target skills; review destination carefully.

### f31e085ba2 - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Prompt variables`
- Category: `workflow improvement`
- Primary target: `agent-pilot`
- Secondary targets: `agent-orchestrator`
- Why target: section is mainly about phased execution, gates, or coordinated delivery
- Proposed destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Use these inside `systemPrompt` strings: `${planFilePath}` — current plan file path `${todoList}` — remaining checklist items as markdown checkboxes `${completedCount}` — completed checklist count
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-pilot, agent-orchestrator. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/ux-writing.md (support, similarity 0.32)
- Warning: Touches multiple target skills; review destination carefully.

### bd37c393b0 - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Code review`
- Category: `workflow improvement`
- Primary target: `agent-pilot`
- Secondary targets: `agent-orchestrator`
- Why target: Retargeted toward agent-pilot because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Run `/plannotator-review` to open your current git changes in the code review UI. Annotate specific lines, switch between diff views (uncommitted, staged, last commit, branch), and submit feedback that gets sent to the agent.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-pilot, agent-orchestrator. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.38)
- Warning: Touches multiple target skills; review destination carefully.

### 59eace9f3b - ADAPT

- Source: `apps/pi-extension/README.md`
- Section: `Annotate last message`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Run `/plannotator-last` to annotate the agent's most recent response. The message opens in the annotation UI where you can highlight text, add comments, and send structured feedback back to the agent.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/animate/PLAYBOOK.md (playbook, similarity 0.38)
- Warning: Touches multiple target skills; review destination carefully.
