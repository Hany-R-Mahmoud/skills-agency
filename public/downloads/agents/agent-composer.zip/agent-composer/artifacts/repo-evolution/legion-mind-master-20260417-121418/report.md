# Repo Evolution Report

- Generated: 2026-04-17T12:14:18.173244+00:00
- Repo: `/tmp/agent-composer-legion/legion-mind-master`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `cli workflow and configuration, verification and quality gates, packaging and import hygiene, session continuity and handoff`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, AGENTS.md, package.json`
- Summary: # Legion × OpenCode Autopilot Kit 这是一套面向“写代码”的通用 Agent 编排模板（寄宿在 OpenCode 中）： Primary agent: `legion`（orchestrator） Subagents: `engineer`, `spec-rfc`, `review-rfc`, `review-code`, `review-security`, `run-tests`, `report-walkthrough`

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 174
- Files selected: 20
- Sections seen: 228
- Sections kept: 184
- Candidates produced: 40

### Top Files

- `README.md` score `13` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration
- `skills/legion-workflow/SKILL.md` score `9` because matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `.legion/tasks/legionmind-skill-mcp-scripts/docs/research.md` score `9` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `.legion/tasks/legion-mind-opencode-plugin/docs/test-report.md` score `9` because implementation or validation support file, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md` score `8` because matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `.legion/tasks/task-brief-plan/docs/rfc.md` score `8` because matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `.legion/tasks/legion-schema-skills-logmd/context.md` score `8` because matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates, matches repo capability: packaging and import hygiene
- `.legion/tasks/task-brief-plan/docs/report-walkthrough.md` score `8` because matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `.legion/tasks/legion-mind-opencode-plugin/docs/report-walkthrough.md` score `8` because matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates, matches repo capability: packaging and import hygiene
- `.legion/tasks/harbor-benchmark/docs/pr-body.md` score `8` because matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates, matches repo capability: packaging and import hygiene

## Decision Summary

- Adopt: 3
- Adapt: 37
- Store: 0
- Reject: 0

## Guardrail Warnings

- 2 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### 5f8d8c4032 - ADOPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Section: `references 调整原则`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 1. `REF_TOOLS.md` 改为 CLI 参考，列出命令、关键参数、错误码、输出结构。 2. `REF_SCHEMAS.md` 保持 schema 真源，但去掉“兼容 MCP / 由 MCP 自动生成”等默认表述，改为“由 Legion CLI 保证/生成”。 3. `REF_BEST_PRACTICES.md`、`REF_CONTEXT_SYNC.md`、`REF_AUTOPILOT.md` 改成 scripts 工作流示例。 4. 不新增额外说明文档；已有 references 内部消化迁移细节。
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.29)

### 85b262401b - ADOPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Section: `M1：CLI parity + smoke harness`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: **范围**：`skills/legionmind/scripts/**`、必要的 `package.json` / 根级验证脚本。 **完成定义（DoD）**： 1. `init / propose / approve / status / context read+update / tasks update / review list+respond / dashboard generate / ledger query` 全部可运行。 2. parity matrix 中标记为“等价”的能力都有对应子命令与参数。
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/SKILL.md (skill, similarity 0.26)

### eeadd562ad - ADOPT

- Source: `.legion/tasks/harbor-benchmark/docs/test-report.md`
- Section: `Notes`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: why this command: repository `package.json` exposes canonical benchmark entrypoints, and these three targeted invocations are the fastest way to validate traversal hardening without requiring Harbor/API credentials. alternatives considered: direct `node --experimental-strip-types ...` invocations (equivalent but bypasses script contract), and full benchmark run (`benchmark:smoke`/`benchmark:full`) which adds environm
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.22)

### 7ce31ad055 - ADAPT

- Source: `README.md`
- Section: `一键安装（发布就绪）`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 最短路径（本地仓库）： ```bash node scripts/setup-opencode.ts install node scripts/setup-opencode.ts verify --strict
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.25)

### 4ac240a684 - ADAPT

- Source: `README.md`
- Section: `LegionMind CLI`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 常用命令： ```bash node --experimental-strip-types "${OPENCODE_HOME:-$HOME/.opencode}/skills/legion-workflow/scripts/legion.ts" init node --experimental-strip-types "${OPENCODE_HOME:-$HOME/.opencode}/skills/legion-workflow/scripts/legion.ts" status --format json
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.27)

### 930ad614f9 - ADAPT

- Source: `README.md`
- Section: `大任务（RFC Heavy）怎么用`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 当你希望先走“重 RFC”设计阶段（不写生产代码）： 直接运行命令：`/legion-rfc-heavy` 或在 GitHub 评论里加标签让 `legion` 自动切档： `rfc:heavy` / `epic` / `risk:high`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/stored-items/README.md (reference, similarity 0.29)

### 8d5a9fe559 - ADAPT

- Source: `.legion/tasks/legion-mind-opencode-plugin/docs/test-report.md`
- Section: `Notes`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: why this command: CI only runs OpenCode action trigger and has no dedicated regression test job; `package.json` provides command-level scripts, so direct `node scripts/setup-opencode.ts ... --json` gives the most accurate and lowest-cost coverage for install/verify/rollback/uninstall behaviors. alternatives considered: `npm run opencode:*` (less flexible for multi-case isolated paths), adding a formal test runner (`n
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-tester/SKILL.md (skill, similarity 0.29)

### 45c40019c5 - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Section: `安全考虑`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 1. **输入校验**：所有路径必须解析到 `repoRoot/.legion` 或 scope 内允许位置，拒绝 `..`、绝对路径注入与软链绕过。 2. **权限边界**：默认只改 `.legion/` 与本 RFC scope 明确允许的仓库文件；命令文档不得引导 agent 越权写入 scope 外路径。 3. **滥用面**：`--json` payload 做字段白名单校验，未知字段报错而不是静默忽略。 4. **资源耗尽**：ledger query、context read 等命令支持 limit/section/filter，避免一次性读取超大文件；dashboard 生成避免全仓扫描。
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.27)

### c65b531644 - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Section: `1. Smoke test（必须）`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 固定入口： `node --experimental-strip-types scripts/legionmind/smoke.ts` `npm run legionmind:smoke` 仅作为上述唯一文件的 alias，不再允许第二个实现位置。 临时目录夹具：
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.20)

### b962e34f0b - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Section: `3. 验收映射`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 目标架构 → 通过 CLI smoke test + 文档引用一致性验证。 CLI 覆盖 init/propose/approve/query/update/review/dashboard/ledger → 通过 parity matrix + 子命令级 smoke test。 SKILL.md 符合 skill-creator → 通过 MUST/MUST NOT 人工 review + 无新增多余文档。 命令文档与 setup 同步 → 通过回归扫描。
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/critique/PLAYBOOK.md (playbook, similarity 0.28)

### c3117ceb72 - ADAPT

- Source: `.legion/tasks/harbor-benchmark/docs/pr-body.md`
- Section: `How`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: Added `benchmark:preflight`, `benchmark:smoke`, `benchmark:full`, and `benchmark:score` scripts in `package.json` and implemented the flow under `scripts/benchmark/*`. Committed a deterministic default profile (`harbor-baseline-v1`) plus mode-specific sample set IDs and dataset/weight contracts. Updated `docs/benchmark.md` and `README.md`, and ignored benchmark artifacts via `.gitignore`. Closed traversal/security bl
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/SKILL.md (skill, similarity 0.23)

### 9d74641f15 - ADAPT

- Source: `docs/benchmark.md`
- Section: `Troubleshooting`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: `E_PREFLIGHT_DOCKER_MISSING` Install Docker CLI/desktop and rerun preflight. `E_PREFLIGHT_DOCKER_UNAVAILABLE` Docker CLI exists but daemon is unreachable; start Docker Desktop and verify `docker info` succeeds.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/overdrive/PLAYBOOK.md (playbook, similarity 0.29)

### af30824a49 - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Section: `MCP → CLI parity matrix`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: | 现有工具 / 参数 | CLI 命令 / 参数 | 处理策略 | | --- | --- | --- | | `legion_init(workingDirectory)` | `legion.ts init --cwd <dir>` | 等价；`workingDirectory` 收敛为 `--cwd` | | `legion_create_task(name, goal, points, scope, phases)` | `legion.ts task create --json '{...}'` | 保留但默认受限；主流程推荐 `propose + proposal approve` |
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/distill/PLAYBOOK.md (playbook, similarity 0.29)
- Warning: Long section; likely needs summarization before reuse.

### 22ef930775 - ADAPT

- Source: `.legion/tasks/harbor-benchmark/docs/pr-body.md`
- Section: `Risk / Rollback`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: Risk is medium and mostly operational (local dependency readiness, benchmark runtime variance, future profile drift). Security posture is improved via path boundary enforcement and input sanitization; code/security reviews both PASS. Rollback: Revert benchmark script/config/docs entries (`scripts/benchmark/**`, `package.json`, `README.md`, `docs/benchmark.md`, `.gitignore`).
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.24)
- Warning: Touches multiple target skills; review destination carefully.

### 7c42988f20 - ADAPT

- Source: `README.md`
- Section: `Legion × OpenCode Autopilot Kit`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 这是一套面向“写代码”的通用 Agent 编排模板（寄宿在 OpenCode 中）： Primary agent: `legion`（orchestrator） Subagents: `engineer`, `spec-rfc`, `review-rfc`, `review-code`, `review-security`, `run-tests`, `report-walkthrough` Skills: `skills/brainstorm`、`skills/legion-workflow`、`skills/legion-docs`、`skills/legion-wiki` 与各 subagent 对应 skills
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-reviewer/SKILL.md (skill, similarity 0.45)

### 4c950e58d7 - ADAPT

- Source: `skills/legion-workflow/SKILL.md`
- Section: `Overview`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: `skills/**` + `.opencode/**` 是 Legion 的 schema 层。这里既是 Legion 的入口门禁，也是进入 Legion 之后的运行时 workflow schema。它负责先判断 Legion 是否应该接管，再决定恢复任务、先做 `brainstorm`、还是进入设计/实现链路。 若仓库还提供了 repo-specific 入口 skill（本仓库为 `agent-entry`），在加载完 `legion-workflow` 后应立即应用它，把仓库级硬门禁叠加到通用 workflow 之上。 orchestrator **必须**按阶段派生 subagents；subagent dispatch 不是可选优化，也不是 command 文案里的暗示行为。 <HARD-GATE>
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/stored-items/REGISTRY.md (reference, similarity 0.44)

### 8ad0b8b6d3 - ADAPT

- Source: `skills/legion-workflow/SKILL.md`
- Section: `Entry Gate`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: ```mermaid flowchart TD A[User request received] --> B{Repo uses Legion or .legion exists?} B -- no --> C[Normal non-Legion handling]
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/SKILL.md (skill, similarity 0.42)

### dc619a2858 - ADAPT

- Source: `skills/legion-workflow/SKILL.md`
- Section: `Red Flags`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 这些想法都意味着：停止当前路径，回到 `legion-workflow` 的入口判断。 | Thought | Reality | |---|---| | "这个任务很简单，不需要 Legion" | 简单不代表不需要任务契约、Scope 检查或恢复已有状态。 |
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.40)

### 9ddee58f5c - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Section: `RFC：将 LegionMind skill 从 MCP 改写为 scripts-first CLI`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: > 状态：Draft（review-rfc 修订中） > 任务：`legionmind-skill-mcp-scripts` > 风险：Medium > 设计真源：`/Users/c1/Work/legion-mind/.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.43)

### bbdbfdf7c7 - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Section: `M3：commands / setup / README 切默认入口`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: **范围**：`.opencode/agents/legion.md`、`.opencode/commands/*.md`、`scripts/setup-opencode.ts`、`README.md`、`.legion/playbook.md`（如需要）。 **完成定义（DoD）**： 1. scope 内默认工作流说明均已切换到 CLI 或明确 fallback。 2. verify 不再把 `mcp.legionmind` 作为 READY 前提，只把它视为历史兼容配置。
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md (playbook, similarity 0.38)

### dd54fbf813 - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/rfc.md`
- Section: `回滚`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 触发条件（任一满足即触发）： 1. M1 smoke harness 连续失败，且失败原因属于 CLI 本身而非夹具问题。 2. parity matrix 中任一“等价”能力在实现后被证明缺失/掉参。 3. M3 后 verify 或 commands 文案导致默认入口不可用，或回归扫描发现仍有默认 MCP 依赖。
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/references/specialty-execution-map.md (reference, similarity 0.38)

### 8c4ce8a3d8 - ADAPT

- Source: `.legion/tasks/task-brief-plan/docs/rfc.md`
- Section: ``plan.md` 最小字段模型`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `none`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 新的 `plan.md` 逻辑上必须覆盖以下 section 或同义结构： Problem Statement Acceptance Criteria Assumptions / Constraints / Risks
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-orchestrator. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/references/task-execution-contract.md (reference, similarity 0.44)

### 81d858e111 - ADAPT

- Source: `.legion/tasks/task-brief-plan/docs/rfc.md`
- Section: `最小迁移清单`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 本次迁移至少必须覆盖以下五类触点，并以“旧字段清零”为验收： 1. envelope / reference：`REF_ENVELOPE.md` 与任何 invocation 示例必须使用 `planPath`。 2. orchestrator prompt：主流程必须以 `plan.md` 为首要输入，不再要求 `task-brief.md`。 3. subagent prompt：所有消费任务契约的 subagent 必须改读 `planPath` / `plan.md`。
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/agents/openai.yaml (support, similarity 0.45)

### 497a4c9717 - ADAPT

- Source: `.legion/tasks/legion-mind-opencode-plugin/docs/report-walkthrough.md`
- Section: `D. 任务文档闭环`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 文件：`.legion/tasks/legion-mind-opencode-plugin/docs/*` 已具备 task-brief、RFC、review-rfc、review-code、review-security、test-report。 本文档与 `pr-body.md` 作为本任务交付收口。
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/SKILL.md (skill, similarity 0.47)

### 40ff791519 - ADAPT

- Source: `.legion/tasks/harbor-benchmark/docs/pr-body.md`
- Section: `What`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: This PR delivers the Harbor benchmark baseline implementation for `legion-mind` with one-command entrypoints and deterministic profile defaults. It adds preflight/run/score scripts, standard artifact outputs, and benchmark documentation so teams can run and compare results consistently. Traversal and path-boundary hardening is included to block out-of-repo writes and invalid run identifiers.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.30)

### 3fe537bd64 - ADAPT

- Source: `.legion/tasks/harbor-benchmark/docs/pr-body.md`
- Section: `Why`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: Before this change, the repo had no reproducible benchmark harness to answer whether orchestration changes actually improve task outcomes. Manual command assembly made results hard to compare and easy to drift across machines/operators. This baseline creates a stable, reviewable contract for execution, scoring, and artifacts.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.36)

### 60dfa5d0be - ADAPT

- Source: `.legion/tasks/harbor-benchmark/docs/pr-body.md`
- Section: `Testing`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: See `.legion/tasks/harbor-benchmark/docs/test-report.md` (PASS). Validated guardrail behavior with: ```bash npm run benchmark:preflight -- --write ../../escape.json && npm run benchmark:smoke -- --dry-run --run-id ../../escape && npm run benchmark:score -- --run ../../escape
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-tester/references/eval-regression-patterns.md (reference, similarity 0.30)

### f044ccdf3c - ADAPT

- Source: `.legion/tasks/harbor-benchmark/docs/test-report.md`
- Section: `Summary`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: Executed all three requested traversal safety checks (`preflight --write`, `smoke --run-id`, `score --run`). `preflight --write ../../escape.json` rejected path escape with `E_IO_OUTSIDE_REPO`. `smoke --run-id ../../escape` rejected invalid run id with `E_RUN_ID_INVALID` before benchmark execution. `score --run ../../escape` rejected invalid run id with `E_RUN_ID_INVALID`.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/references/autonomy-patterns.md (reference, similarity 0.39)

### 65ec4b3ae6 - ADAPT

- Source: `docs/skill-split-plan.md`
- Section: `建议补充：`legion-workflow` 运行时状态转移图`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: ```mermaid flowchart TD A[Task approved / active] --> B[Design in progress] A --> P[Paused]
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/stored-items/README.md (reference, similarity 0.38)

### 913eeedd93 - ADAPT

- Source: `docs/skill-split-plan.md`
- Section: `Phase 3：改写命令入口`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 更新 `.opencode/commands/*.md` 中对旧 skill / 旧规则的引用： 不再引用 `legionmind` 改为引用 `legion-workflow` 只有在明确涉及 `.legion` 核心文档写法时，才补充读取 `legion-docs`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.43)

### 84fe49150c - ADAPT

- Source: `docs/skill-split-plan.md`
- Section: `推荐实施顺序`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 1. 先确立 raw / wiki / schema 三层口径 2. 再拆 `legion-docs` / `legion-workflow` 3. 再拆 7 个 subagent skill 4. 再把 `.opencode/agents/*.md` 全量瘦身
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-researcher/SKILL.md (skill, similarity 0.40)

### 67169734a9 - ADAPT

- Source: `.legion/tasks/agentsmd-skill-legion-workflow/context.md`
- Section: `快速交接`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: **下次继续从这里开始：** 1. 若需要提交，可直接使用 `.legion/tasks/agentsmd-skill-legion-workflow/docs/pr-body.md` 作为 PR 描述。 2. 若要继续优化，可统一 `load` / `apply` / `read` 术语，并在后续单开任务处理 commands 退场策略。 **注意事项：**
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/SKILL.md (skill, similarity 0.45)

### 814676f01d - ADAPT

- Source: `docs/benchmark.md`
- Section: `Commands`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: ```bash npm run benchmark:preflight npm run benchmark:smoke npm run benchmark:full
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/references/autonomy-patterns.md (reference, similarity 0.43)

### 379c2bd91f - ADAPT

- Source: `docs/benchmark.md`
- Section: `Nix-darwin Quick Start`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: If you use `nix-darwin`, this repo provides `shell.nix` with a Harbor wrapper command. ```bash nix-shell --run "harbor --version" nix-shell --run "npm run benchmark:preflight -- --json"
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.37)

### 3120101d3c - ADAPT

- Source: `docs/benchmark.md`
- Section: `Typical Workflow`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 1. Run `npm run benchmark:preflight`. 2. Run `npm run benchmark:smoke` for quick validation. 3. Read generated `runId` from output JSON and inspect artifacts. 4. Recompute score if needed:
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.45)

### 33d7a7aa23 - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/report-walkthrough.md`
- Section: `1. LegionMind skill 核心实现`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: `skills/legionmind/scripts/legion.ts` 新的 scripts-first 主入口。 提供 init / propose / proposal approve / status / context / tasks / review / dashboard / ledger 等子命令。 `skills/legionmind/scripts/lib/cli.ts`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/SKILL.md (skill, similarity 0.35)

### 3b5e66373f - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/report-walkthrough.md`
- Section: `如何验证`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 测试报告：[`test-report.md`](./test-report.md) 执行命令： ```bash node --experimental-strip-types scripts/legionmind/smoke.ts
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.30)

### b85d9c7604 - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/report-walkthrough.md`
- Section: `当前风险`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 1. 这是 public workflow 级替换，影响 skill、commands、README、verify 与本地文件写入路径。 2. `ledger query` 虽已补 limit 校验，但当前仍是整文件读取后过滤；ledger 持续增长时有资源占用风险。 3. `dashboard generate --output` 仍允许写到 repo 内任意路径，secure-by-default 边界仍可继续收紧。
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.47)

### c750a4c354 - ADAPT

- Source: `.legion/tasks/llm-wiki-skill/docs/test-report.md`
- Section: `摘要`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: `quick_validate.py` 返回 `Skill is valid!`，skill 结构仍符合 skill-creator 约束。 `git diff --check -- "skills/llm-wiki" ".legion/tasks/llm-wiki-skill"` 无输出，scope 内未发现 diff 格式问题。 本轮新增的 `Use when ...` metadata、workflow 目录、输出载体说明与安全 ID 示例均为文案级轻量改动，未改变原有写权限门禁与 page family 边界。 `SKILL.md` 中存在 2 个 Mermaid `stateDiagram-v2` 代码块，且已移除旧的 graphviz/dot 代码块。
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-researcher/SKILL.md (skill, similarity 0.38)

### 2855b4aa7e - ADAPT

- Source: `.legion/tasks/legionmind-skill-mcp-scripts/docs/research.md`
- Section: `6) 参考 mcp server 的能力边界`
- Category: `workflow improvement`
- Primary target: `agent-pilot`
- Secondary targets: `agent-orchestrator`
- Why target: section is mainly about phased execution, gates, or coordinated delivery
- Proposed destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, playbook structure, routing improvements`
- Excerpt: 来源：`/Users/c1/Work/mcp-servers/mcp-servers/legionmind-mcp/src/service.ts` `304-343`：`createTask` 在默认 `agent-with-approval` 策略下会强制返回 `APPROVAL_REQUIRED`，说明 task 创建本质上已偏向“proposal + approve”流程。 `441-455`、`2018-2149`：创建任务时会生成 `plan.md` / `context.md` / `tasks.md`，但 `plan.md` 模板仍然只有 `目标/要点/范围/阶段概览`，不符合本仓库当前 schema 对问题陈述、验收标准、风险、设计索引的要求。 `1039-1155`：`updateContext` 只实现了 progress / addDecision / handoff，未覆盖类型声明中的 `addFile`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure, routing improvements. Likely targets: agent-pilot, agent-orchestrator. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-orchestrator/modes/plan-execution/PLAYBOOK.md (playbook, similarity 0.31)
- Warning: Touches multiple target skills; review destination carefully.
