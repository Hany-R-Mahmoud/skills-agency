# Repo Evolution Report

- Generated: 2026-04-17T08:59:09.277724+00:00
- Repo: `/Users/hanyramadan/.codex/skills`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Decision Summary

- Adopt: 12
- Adapt: 0
- Store: 0
- Reject: 0

## Guardrail Warnings

- None

## Candidates

### 8586111177 - ADOPT

- Source: `.system/imagegen/SKILL.md`
- Section: `Script-mode notes`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: CLI commands + examples: `references/cli.md` API parameter quick reference: `references/image-api.md` Network approvals / sandbox settings for CLI mode: `references/codex-network.md`
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-architect/SKILL.md (skill, similarity 0.38)

### d057f9906b - ADOPT

- Source: `.system/imagegen/SKILL.md`
- Section: `Reference map`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `routing improvements, import hygiene, playbook structure`
- Excerpt: `references/prompting.md`: shared prompting principles for both modes. `references/sample-prompts.md`: shared copy/paste prompt recipes for both modes. `references/cli.md`: fallback-only CLI usage via `scripts/image_gen.py`. `references/image-api.md`: fallback-only API/CLI parameter reference.
- Rationale: Category: routing improvement. Priorities matched: routing improvements, import hygiene, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-architect/SKILL.md (skill, similarity 0.33)

### fb26a8ec39 - ADOPT

- Source: `.system/openai-docs/SKILL.md`
- Section: `Document`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt:  name: "openai-docs" description: "Use when the user asks how to build with OpenAI products or APIs and needs up-to-date official documentation with citations, help choosing the latest model for a use case, or explicit GPT-5.4 upgrade and prompt-upgrade guidance; prioritize OpenAI docs MCP tools, use bundled references only as helper context, and restrict any fallback browsing to official OpenAI domains." 
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-architect/SKILL.md (skill, similarity 0.36)

### 3ec78b2379 - ADOPT

- Source: `.system/openai-docs/SKILL.md`
- Section: `OpenAI Docs`
- Category: `packaging improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `5` | fit `5` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: Provide authoritative, current guidance from OpenAI developer docs using the developers.openai.com MCP server. Always prioritize the developer docs MCP tools over web.run for OpenAI-related questions. This skill may also load targeted files from `references/` for model-selection and GPT-5.4-specific requests, but current OpenAI docs remain authoritative. Only if the MCP server is installed and returns no meaningful r
- Rationale: Category: packaging improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 5/5, risk 2/5.
- Duplicate signal: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.40)

### 31219d53c7 - ADOPT

- Source: `.system/openai-docs/SKILL.md`
- Section: `Quick start`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: Use `mcp__openaiDeveloperDocs__search_openai_docs` to find the most relevant doc pages. Use `mcp__openaiDeveloperDocs__fetch_openai_doc` to pull exact sections and quote/paraphrase accurately. Use `mcp__openaiDeveloperDocs__list_openai_docs` only when you need to browse or discover pages without a clear query. Load only the relevant file from `references/` when the question is about model selection or a GPT-5.4 upgra
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.33)

### bf74b7ba96 - ADOPT

- Source: `.system/openai-docs/SKILL.md`
- Section: `Quality rules`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: Treat OpenAI docs as the source of truth; avoid speculation. Keep quotes short and within policy limits; prefer paraphrase with citations. If multiple pages differ, call out the difference and cite both. Reference files are convenience guides only; for volatile guidance such as recommended models, upgrade instructions, or prompting advice, current OpenAI docs always win.
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-docs/SKILL.md (skill, similarity 0.30)

### ed30d2d5ed - ADOPT

- Source: `.system/skill-creator/SKILL.md`
- Section: `What Skills Provide`
- Category: `workflow improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `playbook structure`
- Excerpt: 1. Specialized workflows - Multi-step procedures for specific domains 2. Tool integrations - Instructions for working with specific file formats or APIs 3. Domain expertise - Company-specific knowledge, schemas, business logic 4. Bundled resources - Scripts, references, and assets for complex and repetitive tasks
- Rationale: Category: workflow improvement. Priorities matched: playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md (playbook, similarity 0.31)

### 05aad7e3ce - ADOPT

- Source: `.system/skill-creator/SKILL.md`
- Section: `Step 2: Planning the Reusable Skill Contents`
- Category: `workflow improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `playbook structure`
- Excerpt: To turn concrete examples into an effective skill, analyze each example by: 1. Considering how to execute on the example from scratch 2. Identifying what scripts, references, and assets would be helpful when executing these workflows repeatedly Example: When building a `pdf-editor` skill to handle queries like "Help me rotate this PDF," the analysis shows:
- Rationale: Category: workflow improvement. Priorities matched: playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.38)

### 210baafd73 - ADOPT

- Source: `README.md`
- Section: `Internal Playbooks`
- Category: `packaging improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `5` | fit `5` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: Internal playbooks remain on disk and are meant to be read by agents, not selected directly by default. They cover: engineering domains such as React, backend, architecture, MCP, security, docs, and testing
- Rationale: Category: packaging improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 5/5, risk 2/5.
- Duplicate signal: Closest local match: agent-debugging/SKILL.md (skill, similarity 0.36)

### 5deef65661 - ADOPT

- Source: `agent-impeccable/modes/onboard/PLAYBOOK.md`
- Section: `Documentation & Help`
- Category: `workflow improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `playbook structure`
- Excerpt: **In-product help**: Contextual help links throughout interface Keyboard shortcut reference Search-able help center
- Rationale: Category: workflow improvement. Priorities matched: playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/media-ideation/PLAYBOOK.md (playbook, similarity 0.33)

### f7581acb34 - ADOPT

- Source: `chatgpt-apps/PLAYBOOK.md`
- Section: `API Surface Guardrails`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: Some examples wrap the bridge with an `app` object (for example, `@modelcontextprotocol/ext-apps/react`) and expose helper names like `app.sendMessage()`, `app.callServerTool()`, `app.openLink()`, or host getter methods. Treat those wrappers as implementation details or convenience layers, not the canonical public API to teach by default. For ChatGPT-facing guidance, prefer the current documented surface: `window.ope
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-architect/SKILL.md (skill, similarity 0.32)

### 6235e90dd4 - ADOPT

- Source: `chatgpt-apps/PLAYBOOK.md`
- Section: `6. Validate the Local Loop`
- Category: `workflow improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `routing improvements, evaluation loops, playbook structure`
- Excerpt: Validate against the minimum working repo contract, not just “did files get created.” Run the lowest-cost checks first: static contract review syntax or compile checks when feasible
- Rationale: Category: workflow improvement. Priorities matched: routing improvements, evaluation loops, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-composer/SKILL.md (skill, similarity 0.38)
