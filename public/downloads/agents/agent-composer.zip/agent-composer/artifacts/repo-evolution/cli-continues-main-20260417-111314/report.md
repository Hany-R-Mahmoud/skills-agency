# Repo Evolution Report

- Generated: 2026-04-17T11:13:14.287731+00:00
- Repo: `/tmp/cli-continues-main`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `cross-tool parsing and extraction, session continuity and handoff, cli workflow and configuration, verification and quality gates, packaging and import hygiene`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, AGENTS.md, CLAUDE.md, REVIEW.md, package.json, src/cli.ts, src/index.ts`
- Summary: # continues > You hit the rate limit mid-debug. 30 messages of context — file changes, architecture decisions, half-finished refactors — and now you either wait hours or start fresh in another tool. **`continues` grabs your session from whichever AI coding tool you were using and hands it off to another one.** Conversation history, file changes, working state — all of it comes along. ```bash npx continues

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 233
- Files selected: 20
- Sections seen: 178
- Sections kept: 160
- Candidates produced: 40

### Top Files

- `AGENTS.md` score `20` because high-signal file: AGENTS.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `README.md` score `19` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `CLAUDE.md` score `19` because high-signal file: CLAUDE.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `REVIEW.md` score `19` because high-signal file: REVIEW.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `.greptile/config.json` score `18` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `docs/parser-documentation/README.md` score `18` because high-signal file: README.md, implementation or validation support file, matches repo capability: session continuity and handoff
- `package.json` score `18` because high-signal file: package.json, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `docs/parser-documentation/prompts/2026-04-15-internet-adversarial-verification-pad.md` score `17` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `docs/parser-documentation/99-open-questions.md` score `17` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `src/cli.ts` score `16` because entrypoint source file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction

## Decision Summary

- Adopt: 0
- Adapt: 40
- Store: 0
- Reject: 0

## Guardrail Warnings

- 11 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### ffef123628 - ADAPT

- Source: `AGENTS.md`
- Section: `Anti-Patterns to Avoid`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Writing to tool storage directories** — the tool is read-only. Any write to `~/.claude/`, `~/.codex/`, etc. is a severe bug. **`exec()` with string interpolation** — always use `spawn()` with an argument array in `resume.ts`. Session IDs and paths can contain shell metacharacters. **`fs.readFileSync`/`fs.writeFileSync` in parsers** — these block the event loop. Use async fs APIs or shared streaming helpers. **Dupli
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.27)
- Warning: Touches multiple target skills; review destination carefully.

### 56644e7313 - ADAPT

- Source: `CLAUDE.md`
- Section: `2. Create the parser — `src/parsers/newtool.ts``
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Export two functions following the established pattern: `parseNewtoolSessions(): Promise<UnifiedSession[]>` — Discovers session files from the tool's storage directory, reads metadata (id, cwd, repo, branch, timestamps, summary), and returns `UnifiedSession[]` sorted by `updatedAt` descending. `extractNewtoolContext(session: UnifiedSession): Promise<SessionContext>` — Reads the full session, extracts `ConversationMes
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.26)
- Warning: Touches multiple target skills; review destination carefully.

### e6954919d8 - ADAPT

- Source: `REVIEW.md`
- Section: `Security`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: section is about session continuity, handoff, or context extraction and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Session data is **read-only**. Any PR that writes to tool storage directories (`~/.claude/`, `~/.codex/`, `~/.copilot/`, etc.) is a severe bug. External process spawning in `resume.ts` must use `spawn()` with arguments as an array, never `exec()` with string interpolation. This prevents command injection via session IDs or file paths containing shell metacharacters. The `--dangerously-skip-permissions` / `--dangerous
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.28)
- Warning: Touches multiple target skills; review destination carefully.

### b67cafa126 - ADAPT

- Source: `docs/parser-documentation/README.md`
- Section: `Parser Documentation Research`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: This directory is the evidence base for schema accuracy work in `continues`. The immediate driver is a parser-quality problem: session extraction is inconsistent across tools verbosity reduction is too open-ended at the top level
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/critique/PLAYBOOK.md (playbook, similarity 0.30)
- Warning: Touches multiple target skills; review destination carefully.

### 0ae0da918b - ADAPT

- Source: `docs/parser-documentation/00-overview.md`
- Section: `What Is Now Complete`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `storage-format/`: verified or challenged current storage-root assumptions `message-schema/`: documented assistant-message and chronology models `tool-call-map/`: mapped exact tool-call encoding and fidelity losses `access-recipes/`: documented how to inspect deeper raw data directly
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.23)
- Warning: Touches multiple target skills; review destination carefully.

### 52f069ca5c - ADAPT

- Source: `AGENTS.md`
- Section: `Dependencies`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **`@clack/prompts`** — all interactive TUI prompts and spinners. Do not use `readline` or `inquirer`. **`chalk`** — terminal color. Chalk v4 is installed (CommonJS compat import); do not upgrade to v5+ (ESM-only). **`commander`** — CLI argument parsing. **`ora`** — non-interactive spinners.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/interaction-design.md (support, similarity 0.33)

### 1b92c0b85c - ADAPT

- Source: `README.md`
- Section: `Development`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash git clone https://github.com/yigitkonur/cli-continues cd cli-continues pnpm install
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.45)

### 6ada7f8fd6 - ADAPT

- Source: `CLAUDE.md`
- Section: `3. Register in the adapter registry — `src/parsers/registry.ts``
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Add an entry to the registry with all metadata, parser functions, and resume commands: ```ts import { parseNewtoolSessions, extractNewtoolContext } from './newtool.js'; register({
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/skill-map.md (reference, similarity 0.44)

### 6f96e90eb0 - ADAPT

- Source: `CLAUDE.md`
- Section: `Key Conventions`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ESM-only (`"type": "module"` in package.json). All local imports use `.js` extensions. `process.exitCode` is set instead of calling `process.exit()` directly. The tool suppresses `ExperimentalWarning` from `node:sqlite` at the top of `cli.ts`. Session data is **read-only** — the tool never modifies source session files.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.32)

### 97cb18af6a - ADAPT

- Source: `docs/parser-documentation/storage-format/03-copilot.md`
- Section: `Documented Fact`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `none`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Default config root: `~/.copilot` Overrides: `COPILOT_HOME` `--config-dir` takes precedence over `COPILOT_HOME`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.40)

### e7dd4dc9ff - ADAPT

- Source: `README.md`
- Section: `Verbosity control`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: section is about session continuity, handoff, or context extraction
- Proposed destination: `agent-history/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Not every handoff needs to be a novel. Four presets control how much detail goes in: | Preset | Messages | Tool samples | Subagent detail | When to use | |:-------|:---------|:-------------|:----------------|:------------| | `minimal` | 3 | 0 | None | Quick context, token-constrained targets |
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/polish/PLAYBOOK.md (playbook, similarity 0.38)
- Warning: Touches multiple target skills; review destination carefully.

### ef3635e231 - ADAPT

- Source: `CLAUDE.md`
- Section: `What This Project Is`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: section is about session continuity, handoff, or context extraction and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-history/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `continues` is a CLI tool that lets users resume AI coding sessions across Claude Code, GitHub Copilot CLI, Gemini CLI, Codex CLI, OpenCode, Factory Droid, and Cursor AI. It reads each tool's native session storage (read-only), extracts context (messages, file changes, tool activity, AI reasoning), and injects it into a different tool as a structured markdown handoff document.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.43)
- Warning: Touches multiple target skills; review destination carefully.

### 3597b548b2 - ADAPT

- Source: `src/cli.ts`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: #!/usr/bin/env node // Suppress experimental warnings (node:sqlite) process.removeAllListeners('warning'); process.on('warning', (warning) => {
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.36)
- Warning: Long section; likely needs summarization before reuse.

### 46362e8c5c - ADAPT

- Source: `docs/parser-documentation/00-overview.md`
- Section: `Highest-Risk Drift Versus Current Code`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: These are the most urgent mismatches repeatedly confirmed across contexts: | Tool | Main drift | Why it matters | | --- | --- | --- | | Gemini | Current upstream code writes JSONL append logs, while `src/parsers/gemini.ts` still targets older JSON session objects. | Discovery, message reconstruction, tool-call recovery, and pointer design are all at risk. |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/quieter/PLAYBOOK.md (playbook, similarity 0.31)
- Warning: Long section; likely needs summarization before reuse.

### 6867ebbd86 - ADAPT

- Source: `docs/parser-documentation/00-overview.md`
- Section: `1. Simplify the user-facing contract, but do not collapse every concern into one toggle`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The user-facing problem is not “how many samples should I see.” It is “can I continue immediately, and can I go deeper when I need to.” The local research strongly supported a two-mode design, but the adversarial internet verification found that major CLIs more often separate: a human-readable session/transcript surface a machine-readable or inspection-oriented output surface explicit session/checkpoint/raw inspectio
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-researcher/SKILL.md (skill, similarity 0.40)
- Warning: Touches multiple target skills; review destination carefully.

### 04baa8d39a - ADAPT

- Source: `docs/parser-documentation/storage-format/03-copilot.md`
- Section: `Unresolved Uncertainty`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: First-party docs confirm `events.jsonl`, but they do not publicly document `workspace.yaml`; that filename remains a local parser assumption.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.32)
- Warning: Touches multiple target skills; review destination carefully.

### 77cd00340c - ADAPT

- Source: `src/__tests__/e2e-conversions.test.ts`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: /** * E2E test harness: extracts handoff markdown from real sessions, * injects into each target tool non-interactively, and validates * the target tool acknowledges the previous conversation.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.36)
- Warning: Long section; likely needs summarization before reuse.

### d4418b147e - ADAPT

- Source: `CLAUDE.md`
- Section: `Types`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `5` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `src/types/index.ts` defines: `SessionSource` (union of 7 tool names), `UnifiedSession`, `ConversationMessage`, `ToolCall`, `ToolUsageSummary`, `SessionNotes`, `SessionContext`, `HandoffOptions`.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 5/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.13)

### 710ba98433 - ADAPT

- Source: `AGENTS.md`
- Section: `Coding Standards`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **ESM-only**: all local imports must end in `.js`, even for `.ts` source files (e.g., `import { foo } from './foo.js'`). **No `any`**: Biome reports `noExplicitAny` as a warning. Avoid it; document the reason if unavoidable. **Exit codes**: set `process.exitCode = N` rather than calling `process.exit(N)`. **Logging**: use `logger` from `src/logger.ts` for all diagnostic output. Never use bare `console.log`/`console.w
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-researcher/SKILL.md (skill, similarity 0.29)

### ac4960ec13 - ADAPT

- Source: `README.md`
- Section: `Scripting & CI`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash continues list # table output continues list --source claude --json # JSON, filtered continues list --jsonl -n 10 # JSONL, last 10
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.27)

### 04dcb66137 - ADAPT

- Source: `README.md`
- Section: `Tool Activity`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Bash** (×47): `$ npm test → exit 0` · `$ git status → exit 0` · `$ npm run build → exit 1` **Edit** (×12): `edit src/auth.ts` · `edit src/api/routes.ts` · `edit tests/auth.test.ts` **Grep** (×8): `grep "handleLogin" src/` · `grep "JWT_SECRET"` · `grep "middleware"`
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/skill-map.md (reference, similarity 0.21)

### ab48fc119b - ADAPT

- Source: `README.md`
- Section: `Community contributions`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: This started as a 7-tool project and grew fast thanks to contributors: **Factory Droid support** — [#1](https://github.com/yigitkonur/cli-continues/pull/1), first community parser **Cursor AI support** — [#4](https://github.com/yigitkonur/cli-continues/pull/4) by [@Evrim267](https://github.com/Evrim267), with smart slug-to-path resolution **Single-tool error handling** — [#3](https://github.com/yigitkonur/cli-continu
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.24)

### 79c387adf5 - ADAPT

- Source: `CLAUDE.md`
- Section: `Test file conventions`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Parser/conversion tests**: `src/__tests__/unit-conversions.test.ts` — the primary test suite (fixture-based, all conversion paths) **Utility tests**: dedicated files (e.g. `src/__tests__/cwd-matching.test.ts`) **Fixtures**: `src/__tests__/fixtures/index.ts` — one `createXxxFixture()` factory per tool
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.23)

### 2f25ecc792 - ADAPT

- Source: `REVIEW.md`
- Section: `Conventions`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ESM-only: all local imports must use `.js` extensions, even for `.ts` source files. Use `process.exitCode = N` instead of `process.exit(N)`. Biome handles linting and formatting — do not introduce ESLint or Prettier configs. Parser functions must return `Promise<UnifiedSession[]>` and `Promise<SessionContext>` respectively. Both must be registered in `src/parsers/registry.ts`.
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.26)

### 45654c4f61 - ADAPT

- Source: `REVIEW.md`
- Section: `Performance`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Parsers run in parallel via `Promise.allSettled` in the session index builder. A slow parser blocks only its own results, not the entire index. However, flag any parser that performs synchronous I/O or blocks the event loop. The session index uses a 5-minute TTL cache (`~/.continues/sessions.jsonl`). Changes that bypass or invalidate the cache should be justified. Flag any use of `fs.readFileSync` or `fs.writeFileSyn
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.26)

### 223164e9e5 - ADAPT

- Source: `REVIEW.md`
- Section: `Testing`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The primary test suite is `src/__tests__/unit-conversions.test.ts`. All 14 tools x 13 targets = 182 conversion paths must pass. PRs that change parser logic must include or update fixture data in `src/__tests__/fixtures/index.ts`. PRs that add source files under `src/` but do not touch any test files should be flagged — the CI will also flag this via the test-quality job. Node.js 22+ is required. The `node:sqlite` bu
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.30)

### 3207fad520 - ADAPT

- Source: `docs/parser-documentation/00-overview.md`
- Section: `What The Research Now Establishes`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The current product problem is not that `continues` fails to read sessions at all. The deeper issue is that the parser layer mixes three concerns that need to be separated: 1. schema truth 2. readability-oriented summarization 3. handoff navigation
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/typography.md (support, similarity 0.30)

### bbf3211e1e - ADAPT

- Source: `docs/parser-documentation/storage-format/03-copilot.md`
- Section: `Comparison Against `continues``
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Registry: `src/parsers/registry.ts` captures `~/.copilot/session-state/` but omits `COPILOT_HOME`, `--config-dir`, and `session-store.db`. Parser: `src/parsers/copilot.ts` expects `workspace.yaml` and `events.jsonl`. Gap: parser behavior may still work for current installs, but only `events.jsonl` is externally documented; the parser also ignores the SQLite session store and reindex semantics.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/SKILL.md (skill, similarity 0.27)

### 78c32311e0 - ADAPT

- Source: `README.md`
- Section: `Supported tools`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 14 AI coding agents, any-to-any handoff: **Claude Code** · **Codex** · **GitHub Copilot CLI** · **Gemini CLI** · **Cursor** · **Amp** · **Cline** · **Roo Code** · **Kilo Code** · **Kiro** · **Crush** · **OpenCode** · **Factory Droid** · **Antigravity** That's 182 cross-tool handoff paths. Pick any source, pick any destination — it works.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 71d0a48e3a - ADAPT

- Source: `CLAUDE.md`
- Section: `Core Flow`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ``` CLI (src/cli.ts) → Registry (src/parsers/registry.ts) → Index (src/utils/index.ts) → Parsers (src/parsers/*.ts) → Markdown (src/utils/markdown.ts) → Resume (src/utils/resume.ts) ``` 1. **Adapter Registry** (`src/parsers/registry.ts`): Central `ToolAdapter` interface and `adapters` record. Every supported CLI tool is registered here with its parser functions, resume commands, color, label, and storage path. All ot
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/audit/PLAYBOOK.md (playbook, similarity 0.23)
- Warning: Long section; likely needs summarization before reuse.

### a734701ee7 - ADAPT

- Source: `docs/parser-documentation/00-overview.md`
- Section: `Parser Documentation Master Overview`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Access date: 2026-04-15 This directory is now a complete parser-research package for `continues`. The five context folders cover storage format, message schema, tool-call fidelity, direct-access recipes, and handoff-pointer design across all 16 canonical tools defined in `src/types/tool-names.ts`.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 02448271b8 - ADAPT

- Source: `AGENTS.md`
- Section: `Workflow`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Before any commit**: run `pnpm run check` (`pnpm lint && pnpm build`). Fix all Biome errors; warnings are advisory. **After changing a parser or fixture**: run `pnpm test` and confirm all tests pass. Do not commit with failing tests. **After adding a new tool**: run `pnpm run link` to test the global `continues` / `cont` binary locally. **Never run** `pnpm run test:watch`, `e2e-conversions.test.ts`, `real-e2e-full.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-reviewer/SKILL.md (skill, similarity 0.33)

### 1a53a62bcc - ADAPT

- Source: `README.md`
- Section: `Install`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: No install needed — just run `npx continues`. Or install globally: ```bash npm install -g continues # gives you `continues` and `cont` ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/adapt/PLAYBOOK.md (playbook, similarity 0.31)

### d784a17964 - ADAPT

- Source: `README.md`
- Section: `Interactive (default)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Just run `continues`. It finds all your sessions, lets you pick one, and asks where to continue: ``` ┌ continues — pick up where you left off │
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/arrange/PLAYBOOK.md (playbook, similarity 0.47)

### 2ce40cbbcd - ADAPT

- Source: `README.md`
- Section: `Inspect (for debugging)`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: See exactly what gets parsed and what ends up in the handoff: ```bash continues inspect abc123 # diagnostic view continues inspect abc123 --preset full --write-md handoff.md # dump full markdown
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/modes/plan-execution/PLAYBOOK.md (playbook, similarity 0.35)

### 2332076a17 - ADAPT

- Source: `README.md`
- Section: `YAML config`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: For per-project defaults, drop a `.continues.yml` in your project root: ```yaml preset: verbose recentMessages: 15
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.31)

### 18482f2a7d - ADAPT

- Source: `README.md`
- Section: `Session Notes`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Model**: claude-sonnet-4 **Tokens**: 45,230 in / 12,847 out 💭 Need to handle the edge case where token refresh races with logout ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/polish/PLAYBOOK.md (playbook, similarity 0.39)

### 48cbe1201e - ADAPT

- Source: `README.md`
- Section: `Commands reference`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Command | What it does | |:--------|:-------------| | `continues` | Interactive TUI picker | | `continues list` | List sessions (`--source`, `--json`, `--jsonl`, `-n`) |
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md (playbook, similarity 0.42)

### 1de60a552f - ADAPT

- Source: `README.md`
- Section: `Requirements`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Node.js 22+** (uses built-in `node:sqlite` for OpenCode and Crush) At least one of the 14 supported tools installed `sqlite3` CLI binary (only needed for Crush — ships with macOS)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/PLAYBOOK.md (playbook, similarity 0.36)

### 4fe39cf9ff - ADAPT

- Source: `CLAUDE.md`
- Section: `Build & Development Commands`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash pnpm install # Install dependencies pnpm run build # TypeScript compile (tsc) → dist/ pnpm run dev # Run with tsx (no build step)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.36)
