# Repo Evolution Report

- Generated: 2026-04-17T12:21:28.733471+00:00
- Repo: `/tmp/agent-composer-mempalace/mempalace-develop`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `cli workflow and configuration, verification and quality gates, packaging and import hygiene, cross-tool parsing and extraction, session continuity and handoff`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, AGENTS.md, CLAUDE.md`
- Summary: > [!CAUTION] > **Scam alert.** The only official sources for MemPalace are this > [GitHub repository](https://github.com/MemPalace/mempalace), the > [PyPI package](https://pypi.org/project/mempalace/), and the docs site at

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 53
- Files selected: 20
- Sections seen: 271
- Sections kept: 202
- Candidates produced: 40

### Top Files

- `README.md` score `17` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `CLAUDE.md` score `17` because high-signal file: CLAUDE.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `.codex-plugin/README.md` score `11` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration
- `CHANGELOG.md` score `10` because matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `benchmarks/README.md` score `10` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `CONTRIBUTING.md` score `10` because matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `benchmarks/longmemeval_bench.py` score `8` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `.claude-plugin/README.md` score `8` because high-signal file: README.md, matches repo capability: cli workflow and configuration, matches repo capability: packaging and import hygiene
- `MISSION.md` score `7` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `ROADMAP.md` score `7` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration

## Decision Summary

- Adopt: 16
- Adapt: 24
- Store: 0
- Reject: 0

## Guardrail Warnings

- 6 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### 0adefdb87b - ADOPT

- Source: `benchmarks/HYBRID_MODE.md`
- Section: `The Problem Hybrid Mode Solves`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The raw mode (`--mode raw`) gets **96.6% R@5** on LongMemEval. That's already excellent. But looking at the failures, two clear patterns emerged: **1. Specific nouns that embeddings underweight.** Examples of questions that failed in raw mode but pass in hybrid: "What degree did I graduate with?" → answer: "Business Administration" — semantically generic, but the exact phrase is findable via keyword match
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.28)

### 6299980dbe - ADOPT

- Source: `benchmarks/HYBRID_MODE.md`
- Section: `then re-query with the original question`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: full_text_collection = build_collection(top_sessions, include_assistant=True) results = semantic_search(full_text_collection, question, top_k=5) ``` This gives assistant-reference questions a full-text index to search, without polluting the global index that semantic questions depend on.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.29)

### 0ed2371d21 - ADOPT

- Source: `benchmarks/HYBRID_MODE.md`
- Section: `LongMemEval (500 questions, session granularity)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Mode | R@5 | R@10 | NDCG@10 | vs Raw | |------|-----|------|---------|--------| | **Raw (baseline)** | 96.6% | 98.2% | 0.889 | — | | **Hybrid v1 w=0.30** | 97.8% | 98.8% | 0.930 | +1.2pp / +0.6pp / +0.041 |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-performance/modes/performance-foundation/PLAYBOOK.md (playbook, similarity 0.20)

### 280d9886ef - ADOPT

- Source: `README.md`
- Section: `Knowledge graph`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: MemPalace includes a temporal entity-relationship graph with validity windows — add, query, invalidate, timeline — backed by local SQLite. Usage and tool reference: [mempalaceofficial.com/concepts/knowledge-graph](https://mempalaceofficial.com/concepts/knowledge-graph.html).
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.27)

### 57d8a7007c - ADOPT

- Source: `README.md`
- Section: `Docs`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Getting started → [mempalaceofficial.com/guide/getting-started](https://mempalaceofficial.com/guide/getting-started.html) CLI reference → [mempalaceofficial.com/reference/cli](https://mempalaceofficial.com/reference/cli.html) Python API → [mempalaceofficial.com/reference/python-api](https://mempalaceofficial.com/reference/python-api.html) Full benchmark methodology → [benchmarks/BENCHMARKS.md](benchmarks/BENCHMARKS.m
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.27)

### b43f0fcfc0 - ADOPT

- Source: `CHANGELOG.md`
- Section: `Packaging`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Remove `chromadb<0.7` upper bound — unblocks installs against chromadb 1.x palaces (#690) Bump version to 3.2.0 across `pyproject.toml`, `mempalace/version.py`, README badge, and OpenClaw SKILL (#761)
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/stored-items/REGISTRY.md (reference, similarity 0.24)

### a3adfcacce - ADOPT

- Source: `CHANGELOG.md`
- Section: `New Features`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: i18n support — 8 languages (en, es, fr, de, ja, ko, zh-CN, zh-TW) (#718) New MCP tools: get/list/update drawer, hook settings, export (#667, #635) `mempalace migrate` — recover palaces from different ChromaDB versions (#502) Add OpenClaw/ClawHub skill (#491)
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/overdrive/PLAYBOOK.md (playbook, similarity 0.23)

### f33468131d - ADOPT

- Source: `benchmarks/README.md`
- Section: `Quick test`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: python benchmarks/convomem_bench.py --category user_evidence --limit 10 ``` **Categories available:** `user_evidence`, `assistant_facts_evidence`, `changing_evidence`, `abstention_evidence`, `preference_evidence`, `implicit_connection_evidence` **Expected output (all categories, 50 each):**
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.24)

### f00480a84c - ADOPT

- Source: `benchmarks/README.md`
- Section: `What Each Benchmark Tests`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Benchmark | What it measures | Why it matters | |---|---|---| | **LongMemEval** | Can you find a fact buried in 53 sessions? | Tests basic retrieval quality — the "needle in a haystack" | | **LoCoMo** | Can you connect facts across conversations over weeks? | Tests multi-hop reasoning and temporal understanding |
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-researcher/SKILL.md (skill, similarity 0.28)

### 62e06bcede - ADOPT

- Source: `benchmarks/BENCHMARKS.md`
- Section: `ConvoMem (Salesforce, 75K+ QA pairs)`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | System | Score | Notes | |---|---|---| | **MemPal** | **92.9%** | Verbatim text, semantic search | | Gemini (long context) | 70–82% | Full history in context window |
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-debugging/SKILL.md (skill, similarity 0.29)

### c7ddc58ea6 - ADOPT

- Source: `benchmarks/BENCHMARKS.md`
- Section: `What's clean and what isn't`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The 96.6% raw baseline is fully clean. No heuristics were tuned on the test set. Store verbatim text, query with ChromaDB's default embeddings, score. Exactly reproducible. The hybrid v4 improvements (quoted phrase boost, person name boost, nostalgia patterns) were developed by directly examining the three specific questions that failed in every prior mode: `d6233ab6` — `'sexual compulsions'` assistant question → fix
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-reviewer/SKILL.md (skill, similarity 0.23)

### f811741066 - ADOPT

- Source: `benchmarks/BENCHMARKS.md`
- Section: `LongMemEval held-out 450 — hybrid_v4 (no rerank, clean score)`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **98.4% R@5, 99.8% R@10 on 450 questions hybrid_v4 was never tuned on.** This is the honest publishable number. hybrid_v4's fixes (quoted phrase boost, person name boost, nostalgia patterns) were developed by examining 3 questions from the full 500. The held-out 450 were never seen during development. | Metric | Score | |---|---|
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.25)

### 59c1a026d1 - ADOPT

- Source: `benchmarks/convomem_bench.py`
- Section: `Sample files per category (1_evidence = single-message evidence, simplest)`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: SAMPLE_FILES = { "user_evidence": "1_evidence/0050e213-5032-42a0-8041-b5eef2f8ab91_Telemarketer.json", "assistant_facts_evidence": None, # will discover "changing_evidence": None,
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-history/references/session-continuity-patterns.md (reference, similarity 0.29)

### 01200a2be3 - ADOPT

- Source: `.claude-plugin/commands/init.md`
- Section: `Document`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt:  description: Set up MemPalace — install the package, initialize a palace, configure MCP server, and verify everything works. allowed-tools: Bash, Read, Write, Edit, Glob, Grep 
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.26)

### 9212f399a3 - ADOPT

- Source: `benchmarks/HYBRID_MODE.md`
- Section: `Remaining 3 misses (after hybrid v3 + LLM rerank)`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Only 3 questions remain unresolved out of 500.** Hybrid v3 fixed the preference and assistant failures that v2 left behind: preference: 93.3% → **96.7%** (synthetic preference docs bridged the vocabulary gap) assistant: 96.4% → **98.2%** (expanded top-20 rerank pool caught rank-11-12 sessions)
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-docs/SKILL.md (skill, similarity 0.25)

### a8bf0714a3 - ADOPT

- Source: `benchmarks/HYBRID_MODE.md`
- Section: `Fix 2: Expanded LLM rerank pool (20 instead of 10)`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Some assistant-reference failures had the correct session at rank 11-12 — just outside the window Haiku sees. Expanding to top-20 catches these with negligible prompt cost.
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.27)

### f3b72db462 - ADAPT

- Source: `CHANGELOG.md`
- Section: `Bug Fixes`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Set `hnsw:space=cosine` metadata on all collection creation sites — fixes broken similarity scoring under ChromaDB's default L2 distance (#807, #218) File-level locking prevents duplicate drawers when agents mine the same file concurrently (#784, #826) Hybrid closet+drawer retrieval — closets boost ranking, never gate results (#795) Stop hooks from making agents write in chat — saves tokens on every turn (#786)
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/polish/PLAYBOOK.md (playbook, similarity 0.20)

### 8540f36c51 - ADAPT

- Source: `CONTRIBUTING.md`
- Section: `Fork the repo on GitHub first, then clone your fork`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: git clone https://github.com/<your-username>/mempalace.git cd mempalace git remote add upstream https://github.com/MemPalace/mempalace.git pip install -e ".[dev]" # installs with dev dependencies (pytest, build, twine)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.20)

### c94058460c - ADAPT

- Source: `CONTRIBUTING.md`
- Section: `Community`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Discord**: [Join us](https://discord.com/invite/ycTQQCu6kn) **Issues**: Bug reports and feature requests welcome **Discussions**: For questions and ideas
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.29)

### 9c6e970341 - ADAPT

- Source: `ROADMAP.md`
- Section: `v3.1.1 — Stability Patch (this week)`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Bug fixes and hardening merged to `develop`, releasing soon. **Merged:** Security hardening: input validation, KG threading locks, WAL permission fixes (#647) MCP tools: drawer CRUD, paginated export, hook settings (#667)
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-security/SKILL.md (skill, similarity 0.28)

### 8530244f63 - ADAPT

- Source: `.pre-commit-config.yaml`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: repos: repo: https://github.com/astral-sh/ruff-pre-commit # Keep in lock-step with the ruff version pinned in .github/workflows/ci.yml # (>=0.4.0,<0.5). Using a newer rev here produces a different formatter
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/stored-items/README.md (reference, similarity 0.28)

### 8b8e4e85c3 - ADAPT

- Source: `benchmarks/BENCHMARKS.md`
- Section: `4. bge-large on LoCoMo top-10`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Same purpose as #2: isolate the contribution of a better embedding model from the contribution of heuristics. ```bash python benchmarks/locomo_bench.py /tmp/locomo/data/locomo10.json \ mode raw --granularity session --top-k 10 --embed-model bge-large
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/SKILL.md (skill, similarity 0.26)

### 718434e105 - ADAPT

- Source: `benchmarks/HYBRID_MODE.md`
- Section: `Run hybrid v2 + LLM rerank (local-friendly, no preference extraction)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: python benchmarks/longmemeval_bench.py /tmp/longmemeval-data/longmemeval_s_cleaned.json \ mode hybrid_v2 --llm-rerank
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-data-ai/references/skill-map.md (reference, similarity 0.25)

### 6dd3e77083 - ADAPT

- Source: `CHANGELOG.md`
- Section: `Documentation`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Add CLAUDE.md and mission/principles to AGENTS.md (#720) Add VitePress documentation site (#439) Add warning about fake MemPalace websites (#598) Fix stale org URLs and PR branch target in contributor docs (#679)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.27)
- Warning: Touches multiple target skills; review destination carefully.

### 97a348d781 - ADAPT

- Source: `CHANGELOG.md`
- Section: `Bug Fixes`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: MCP null args hang, repair infinite recursion, OOM on large files (#399) Release ChromaDB handles before rmtree on Windows (#392) Use `os.utime` in mtime test for Windows compatibility (#392) Negotiate MCP protocol version instead of hardcoding (#324)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.20)
- Warning: Long section; likely needs summarization before reuse.

### 0b7a1d05f2 - ADAPT

- Source: `benchmarks/README.md`
- Section: `Next Benchmarks (Planned)`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Scale testing** — ConvoMem at 50/100/300 conversations per item **Hybrid AAAK** — search raw text, deliver AAAK-compressed results **End-to-end QA** — retrieve + generate answer + measure F1 (needs LLM API key)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/color-and-contrast.md (support, similarity 0.20)
- Warning: Touches multiple target skills; review destination carefully.

### faad0c036b - ADAPT

- Source: `benchmarks/longmemeval_bench.py`
- Section: `=============================================================================`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: def build_palace_and_retrieve_hybrid_v3( entry, granularity="session", n_results=50, hybrid_weight=0.30 ): """
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.27)
- Warning: Long section; likely needs summarization before reuse.

### df822d129c - ADAPT

- Source: `benchmarks/BENCHMARKS.md`
- Section: `The Core Finding`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Every competitive memory system uses an LLM to manage memory: Mem0 uses an LLM to extract facts Mastra uses GPT-5-mini to observe conversations Supermemory uses an LLM to run agentic search passes
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/references/request-recipes.md (reference, similarity 0.20)
- Warning: Touches multiple target skills; review destination carefully.

### 7040848bd4 - ADAPT

- Source: `benchmarks/locomo_bench.py`
- Section: `=============================================================================`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: def llm_rerank_locomo( question, retrieved_ids, retrieved_docs,
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-data-ai/references/skill-map.md (reference, similarity 0.25)
- Warning: Long section; likely needs summarization before reuse.

### de70a90645 - ADAPT

- Source: `.claude-plugin/README.md`
- Section: `Hooks`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: MemPalace registers two hooks that run automatically: **Stop** -- Saves conversation context every 15 messages. **PreCompact** -- Preserves important memories before context compaction. Set the `MEMPAL_DIR` environment variable to a directory path to automatically run `mempalace mine` on that directory during each save trigger.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.41)

### d8971ab8a5 - ADAPT

- Source: `CLAUDE.md`
- Section: `Design Principles`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: These are non-negotiable. Every PR, every feature, every refactor must honor them. **Verbatim always** — Never summarize, paraphrase, or lossy-compress user data. The system searches the index and returns the original words. If a user said it, we store exactly what they said. This is the foundational promise. **Incremental only** — Append-only ingest after initial build. Never destroy existing data to rebuild. A cras
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.30)
- Warning: Touches multiple target skills; review destination carefully.

### 0aa38d612e - ADAPT

- Source: `benchmarks/README.md`
- Section: `Requirements`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Python 3.9+ `chromadb` (the only dependency) ~300MB disk for LongMemEval data ~5 minutes for each full benchmark run
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.47)
- Warning: Touches multiple target skills; review destination carefully.

### 314ac79196 - ADAPT

- Source: `benchmarks/longmemeval_bench.py`
- Section: `None = use ChromaDB default (all-MiniLM-L6-v2).`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: _bench_embed_fn = None def _make_embed_fn(model_name: str): """ Return a ChromaDB-compatible embedding function for the given model.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/bolder/PLAYBOOK.md (playbook, similarity 0.31)
- Warning: Long section; likely needs summarization before reuse.

### 4455ba702c - ADAPT

- Source: `benchmarks/longmemeval_bench.py`
- Section: `=============================================================================`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: def build_palace_and_retrieve(entry, granularity="session", n_results=50): """ Build a fresh MemPal palace from haystack sessions, then retrieve. Args:
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.31)
- Warning: Long section; likely needs summarization before reuse.

### 48c45a8404 - ADAPT

- Source: `benchmarks/longmemeval_bench.py`
- Section: `=============================================================================`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: def _load_or_create_split(split_file: str, data: list, dev_size: int = 50, seed: int = 42) -> dict: """ Load an existing train/test split or create a new one. Returns {"dev": [question_id, ...], "held_out": [question_id, ...]}
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.32)
- Warning: Long section; likely needs summarization before reuse.

### f0fbdcc68b - ADAPT

- Source: `benchmarks/longmemeval_bench.py`
- Section: `=============================================================================`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: if __name__ == "__main__": parser = argparse.ArgumentParser(description="MemPal × LongMemEval Benchmark") parser.add_argument("data_file", help="Path to longmemeval_s_cleaned.json") parser.add_argument(
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.35)
- Warning: Long section; likely needs summarization before reuse.

### bb6e3a3156 - ADAPT

- Source: `MISSION.md`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: MemPalace: The Mission By: Milla Jovovich Hey everyone! First of all thank you all for embracing MemPalace and trying it, catching bugs and issues and finding cool ways to personalize it into your workflows! A few things I want to say.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-reviewer/SKILL.md (skill, similarity 0.34)
- Warning: Long section; likely needs summarization before reuse.

### 29a7f0d459 - ADAPT

- Source: `benchmarks/BENCHMARKS.md`
- Section: `The Two Honest Numbers`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: These are different claims. They need to be presented as a pair. | Mode | LongMemEval R@5 | LLM Required | Cost per Query | |---|---|---|---| | **Raw ChromaDB** | **96.6%** | None | $0 |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/onboard/PLAYBOOK.md (playbook, similarity 0.33)
- Warning: Touches multiple target skills; review destination carefully.

### cc217b31e8 - ADAPT

- Source: `benchmarks/BENCHMARKS.md`
- Section: `Comparison vs Published Systems (LongMemEval)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: > **Important caveat — read before quoting this table.** > MemPal's `R@5` in this table is **retrieval recall**: is the labelled > session for this question inside the top-5 retrieved candidates? >
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/spatial-design.md (support, similarity 0.37)
- Warning: Long section; likely needs summarization before reuse.

### 4706b74df4 - ADAPT

- Source: `benchmarks/locomo_bench.py`
- Section: `── Optional bge-large embeddings ────────────────────────────────────────────`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: _fastembed_model = None def _get_embedder(model_name: str): """Lazy-load a fastembed model. Cached globally after first load.""" global _fastembed_model
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/optimize/PLAYBOOK.md (playbook, similarity 0.33)
- Warning: Long section; likely needs summarization before reuse.
