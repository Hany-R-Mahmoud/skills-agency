# Repo Evolution Report

- Generated: 2026-04-17T09:40:42.384838+00:00
- Repo: `https://github.com/yigitkonur/cli-continues`
- Source mode: `git-cache`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `cross-tool parsing and extraction, session continuity and handoff, cli workflow and configuration, verification and quality gates, packaging and import hygiene`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, AGENTS.md, CLAUDE.md, REVIEW.md, package.json, src/cli.ts, src/index.ts`
- Summary: # continues > You hit the rate limit mid-debug. 30 messages of context — file changes, architecture decisions, half-finished refactors — and now you either wait hours or start fresh in another tool. **`continues` grabs your session from whichever AI coding tool you were using and hands it off to another one.** Conversation history, file changes, working state — all of it comes along. ```bash npx continues

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 233
- Files selected: 20
- Sections seen: 178
- Sections kept: 160
- Candidates produced: 12

### Top Files

- `AGENTS.md` score `20` because high-signal file: AGENTS.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `README.md` score `19` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `CLAUDE.md` score `19` because high-signal file: CLAUDE.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `REVIEW.md` score `19` because high-signal file: REVIEW.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `.greptile/config.json` score `18` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `docs/parser-documentation/README.md` score `18` because high-signal file: README.md, implementation or validation support file, matches repo capability: session continuity and handoff
- `package.json` score `18` because high-signal file: package.json, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `docs/parser-documentation/prompts/2026-04-15-internet-adversarial-verification-pad.md` score `17` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `docs/parser-documentation/99-open-questions.md` score `17` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `src/cli.ts` score `16` because entrypoint source file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction

## Decision Summary

- Adopt: 0
- Adapt: 12
- Store: 0
- Reject: 0

## Guardrail Warnings

- 6 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### ffef123628 - ADAPT

- Source: `AGENTS.md`
- Section: `Anti-Patterns to Avoid`
- Category: `workflow improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Writing to tool storage directories** — the tool is read-only. Any write to `~/.claude/`, `~/.codex/`, etc. is a severe bug. **`exec()` with string interpolation** — always use `spawn()` with an argument array in `resume.ts`. Session IDs and paths can contain shell metacharacters. **`fs.readFileSync`/`fs.writeFileSync` in parsers** — these block the event loop. Use async fs APIs or shared streaming helpers. **Dupli
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-history/SKILL.md (skill, similarity 0.27)

### 56644e7313 - ADAPT

- Source: `CLAUDE.md`
- Section: `2. Create the parser — `src/parsers/newtool.ts``
- Category: `workflow improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Export two functions following the established pattern: `parseNewtoolSessions(): Promise<UnifiedSession[]>` — Discovers session files from the tool's storage directory, reads metadata (id, cwd, repo, branch, timestamps, summary), and returns `UnifiedSession[]` sorted by `updatedAt` descending. `extractNewtoolContext(session: UnifiedSession): Promise<SessionContext>` — Reads the full session, extracts `ConversationMes
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-history/SKILL.md (skill, similarity 0.26)

### 3169e59556 - ADAPT

- Source: `docs/parser-documentation/prompts/2026-04-15-cto-session-schema-audit.md`
- Section: `Definition Of Done`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: A markdown document exists in the assigned context folder for every supported tool relevant to this repo’s canonical tool list, unless you provide evidence that documentation is impossible for a specific tool. Every tool document distinguishes documented fact, observed example, inference, and unresolved uncertainty. Every tool document includes a direct-access section explaining how deeper data could be retrieved fro
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/frontend-design/reference/ux-writing.md (support, similarity 0.30)

### dba0df8a5e - ADAPT

- Source: `docs/parser-documentation/handoff-pointers/00-overview.md`
- Section: `Sources`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Local repo anchors: `src/config/verbosity.ts`, `src/utils/markdown.ts`, `src/utils/resume.ts`, `src/parsers/*.ts` (read 2026-04-15) Canonical tool list: `src/types/tool-names.ts` (read 2026-04-15) Mission brief and context docs in `docs/parser-documentation/` (read 2026-04-15)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-history/SKILL.md (skill, similarity 0.25)

### b67cafa126 - ADAPT

- Source: `docs/parser-documentation/README.md`
- Section: `Parser Documentation Research`
- Category: `workflow improvement`
- Targets: `agent-orchestrator, agent-composer`
- Destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: This directory is the evidence base for schema accuracy work in `continues`. The immediate driver is a parser-quality problem: session extraction is inconsistent across tools verbosity reduction is too open-ended at the top level
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/critique/PLAYBOOK.md (playbook, similarity 0.30)
- Warning: Touches multiple target skills; review destination carefully.

### 6ad8f7018b - ADAPT

- Source: `docs/parser-documentation/01-parser-redesign-backlog.md`
- Section: `6. Antigravity source-of-truth correction`
- Category: `workflow improvement`
- Targets: `agent-orchestrator, agent-composer`
- Destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Current anchor: `src/parsers/antigravity.ts` Required outcome: verify canonical session store
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.27)
- Warning: Touches multiple target skills; review destination carefully.

### 6a72e7562d - ADAPT

- Source: `docs/parser-documentation/01-parser-redesign-backlog.md`
- Section: `8. Crush and Amp discovery correction`
- Category: `routing improvement`
- Targets: `agent-orchestrator, agent-composer`
- Destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Current anchor: `src/parsers/crush.ts` `src/parsers/amp.ts` `src/parsers/registry.ts`
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/optimize/PLAYBOOK.md (playbook, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 0ae0da918b - ADAPT

- Source: `docs/parser-documentation/00-overview.md`
- Section: `What Is Now Complete`
- Category: `routing improvement`
- Targets: `agent-orchestrator, agent-composer`
- Destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `storage-format/`: verified or challenged current storage-root assumptions `message-schema/`: documented assistant-message and chronology models `tool-call-map/`: mapped exact tool-call encoding and fidelity losses `access-recipes/`: documented how to inspect deeper raw data directly
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-architect/SKILL.md (skill, similarity 0.23)
- Warning: Touches multiple target skills; review destination carefully.

### 12d8d7c9ff - ADAPT

- Source: `docs/parser-documentation/prompts/2026-04-15-cto-session-schema-audit.md`
- Section: `Context Block`
- Category: `workflow improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: This mission exists because the handoff quality in `continues` is constrained by inconsistent parser behavior and insufficient technical orientation at session start. The product works, but the extraction layer is uneven: verbosity is currently expressed through four presets in `src/config/verbosity.ts`, the shared markdown renderer in `src/utils/markdown.ts` does not begin with a deep-access technical pointer block,
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/frontend-design/PLAYBOOK.md (playbook, similarity 0.25)
- Warning: Long section; likely needs summarization before reuse.

### a199f45fe8 - ADAPT

- Source: `docs/parser-documentation/handoff-pointers/00-overview.md`
- Section: `Full-mode contract`
- Category: `routing improvement`
- Targets: `agent-orchestrator, agent-composer`
- Destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `full` should keep the same first six fields, then add only backend-specific depth: Companion artifacts such as sidecar settings, tool-results folders, subagent logs, checkpoints, or DB tables Record-type counts when the backend is append-only and counting is practical Two to four direct retrieval commands or SQL queries
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-implementer/references/specialty-execution-map.md (reference, similarity 0.27)
- Warning: Touches multiple target skills; review destination carefully.

### e4f1235526 - ADAPT

- Source: `docs/parser-documentation/handoff-pointers/00-overview.md`
- Section: `Strongest findings`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `Claude`, `Copilot`, `Cline`, `Roo Code`, `Kilo Code`, `Kimi`, `Crush`, and `Qwen Code` all support high-value pointer blocks because their raw stores are deterministic enough to name concrete files and retrieval commands. `OpenCode` needs a variant-aware pointer because real installations may have both legacy JSON storage and SQLite, and migration behavior is a known source of drift. `Codex` needs a split pointer be
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-orchestrator/SKILL.md (skill, similarity 0.27)
- Warning: Long section; likely needs summarization before reuse.

### 3cf194c0be - ADAPT

- Source: `docs/parser-documentation/handoff-pointers/00-overview.md`
- Section: `High-risk comparisons with current code`
- Category: `workflow improvement`
- Targets: `agent-orchestrator, agent-composer`
- Destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `src/utils/markdown.ts` currently exposes the raw session file too late and never names the backend format. `src/config/verbosity.ts` currently uses four user-facing preset names; the redesign goal is two clear modes without losing retrieval depth. Several parsers flatten or normalize data before the receiver sees it: `codex` prefers merged conversation messages and grouped tool summaries over raw record-type context
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-history/SKILL.md (skill, similarity 0.25)
- Warning: Touches multiple target skills; review destination carefully.
