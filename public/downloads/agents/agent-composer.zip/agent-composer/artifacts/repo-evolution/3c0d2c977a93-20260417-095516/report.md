# Repo Evolution Report

- Generated: 2026-04-17T09:55:16.162168+00:00
- Repo: `https://github.com/yigitkonur/cli-continues`
- Source mode: `git-cache`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `cross-tool parsing and extraction, session continuity and handoff, cli workflow and configuration, verification and quality gates, packaging and import hygiene`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, AGENTS.md, CLAUDE.md, REVIEW.md, package.json, src/cli.ts, src/index.ts`
- Summary: # continues > You hit the rate limit mid-debug. 30 messages of context — file changes, architecture decisions, half-finished refactors — and now you either wait hours or start fresh in another tool. **`continues` grabs your session from whichever AI coding tool you were using and hands it off to another one.** Conversation history, file changes, working state — all of it comes along. ```bash npx continues

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 233
- Files selected: 20
- Sections seen: 178
- Sections kept: 160
- Candidates produced: 12

### Top Files

- `AGENTS.md` score `20` because high-signal file: AGENTS.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `README.md` score `19` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `CLAUDE.md` score `19` because high-signal file: CLAUDE.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `REVIEW.md` score `19` because high-signal file: REVIEW.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `.greptile/config.json` score `18` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `docs/parser-documentation/README.md` score `18` because high-signal file: README.md, implementation or validation support file, matches repo capability: session continuity and handoff
- `package.json` score `18` because high-signal file: package.json, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `docs/parser-documentation/prompts/2026-04-15-internet-adversarial-verification-pad.md` score `17` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `docs/parser-documentation/99-open-questions.md` score `17` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `src/cli.ts` score `16` because entrypoint source file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction

## Decision Summary

- Adopt: 0
- Adapt: 12
- Store: 0
- Reject: 0

## Guardrail Warnings

- 7 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### ffef123628 - ADAPT

- Source: `AGENTS.md`
- Section: `Anti-Patterns to Avoid`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Writing to tool storage directories** — the tool is read-only. Any write to `~/.claude/`, `~/.codex/`, etc. is a severe bug. **`exec()` with string interpolation** — always use `spawn()` with an argument array in `resume.ts`. Session IDs and paths can contain shell metacharacters. **`fs.readFileSync`/`fs.writeFileSync` in parsers** — these block the event loop. Use async fs APIs or shared streaming helpers. **Dupli
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.27)
- Warning: Touches multiple target skills; review destination carefully.

### 56644e7313 - ADAPT

- Source: `CLAUDE.md`
- Section: `2. Create the parser — `src/parsers/newtool.ts``
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Export two functions following the established pattern: `parseNewtoolSessions(): Promise<UnifiedSession[]>` — Discovers session files from the tool's storage directory, reads metadata (id, cwd, repo, branch, timestamps, summary), and returns `UnifiedSession[]` sorted by `updatedAt` descending. `extractNewtoolContext(session: UnifiedSession): Promise<SessionContext>` — Reads the full session, extracts `ConversationMes
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.26)
- Warning: Touches multiple target skills; review destination carefully.

### e6954919d8 - ADAPT

- Source: `REVIEW.md`
- Section: `Security`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: section is about session continuity, handoff, or context extraction and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Session data is **read-only**. Any PR that writes to tool storage directories (`~/.claude/`, `~/.codex/`, `~/.copilot/`, etc.) is a severe bug. External process spawning in `resume.ts` must use `spawn()` with arguments as an array, never `exec()` with string interpolation. This prevents command injection via session IDs or file paths containing shell metacharacters. The `--dangerously-skip-permissions` / `--dangerous
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.28)
- Warning: Touches multiple target skills; review destination carefully.

### b67cafa126 - ADAPT

- Source: `docs/parser-documentation/README.md`
- Section: `Parser Documentation Research`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: This directory is the evidence base for schema accuracy work in `continues`. The immediate driver is a parser-quality problem: session extraction is inconsistent across tools verbosity reduction is too open-ended at the top level
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/critique/PLAYBOOK.md (playbook, similarity 0.30)
- Warning: Touches multiple target skills; review destination carefully.

### 0ae0da918b - ADAPT

- Source: `docs/parser-documentation/00-overview.md`
- Section: `What Is Now Complete`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `storage-format/`: verified or challenged current storage-root assumptions `message-schema/`: documented assistant-message and chronology models `tool-call-map/`: mapped exact tool-call encoding and fidelity losses `access-recipes/`: documented how to inspect deeper raw data directly
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.23)
- Warning: Touches multiple target skills; review destination carefully.

### 52f069ca5c - ADAPT

- Source: `AGENTS.md`
- Section: `Dependencies`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **`@clack/prompts`** — all interactive TUI prompts and spinners. Do not use `readline` or `inquirer`. **`chalk`** — terminal color. Chalk v4 is installed (CommonJS compat import); do not upgrade to v5+ (ESM-only). **`commander`** — CLI argument parsing. **`ora`** — non-interactive spinners.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/interaction-design.md (support, similarity 0.33)

### 1b92c0b85c - ADAPT

- Source: `README.md`
- Section: `Development`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash git clone https://github.com/yigitkonur/cli-continues cd cli-continues pnpm install
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.45)

### 6ada7f8fd6 - ADAPT

- Source: `CLAUDE.md`
- Section: `3. Register in the adapter registry — `src/parsers/registry.ts``
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Add an entry to the registry with all metadata, parser functions, and resume commands: ```ts import { parseNewtoolSessions, extractNewtoolContext } from './newtool.js'; register({
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/skill-map.md (reference, similarity 0.44)

### 6f96e90eb0 - ADAPT

- Source: `CLAUDE.md`
- Section: `Key Conventions`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ESM-only (`"type": "module"` in package.json). All local imports use `.js` extensions. `process.exitCode` is set instead of calling `process.exit()` directly. The tool suppresses `ExperimentalWarning` from `node:sqlite` at the top of `cli.ts`. Session data is **read-only** — the tool never modifies source session files.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.32)

### 97cb18af6a - ADAPT

- Source: `docs/parser-documentation/storage-format/03-copilot.md`
- Section: `Documented Fact`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `none`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Default config root: `~/.copilot` Overrides: `COPILOT_HOME` `--config-dir` takes precedence over `COPILOT_HOME`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.40)

### e7dd4dc9ff - ADAPT

- Source: `README.md`
- Section: `Verbosity control`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: section is about session continuity, handoff, or context extraction
- Proposed destination: `agent-history/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Not every handoff needs to be a novel. Four presets control how much detail goes in: | Preset | Messages | Tool samples | Subagent detail | When to use | |:-------|:---------|:-------------|:----------------|:------------| | `minimal` | 3 | 0 | None | Quick context, token-constrained targets |
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/polish/PLAYBOOK.md (playbook, similarity 0.38)
- Warning: Touches multiple target skills; review destination carefully.

### ef3635e231 - ADAPT

- Source: `CLAUDE.md`
- Section: `What This Project Is`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: section is about session continuity, handoff, or context extraction and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-history/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: `continues` is a CLI tool that lets users resume AI coding sessions across Claude Code, GitHub Copilot CLI, Gemini CLI, Codex CLI, OpenCode, Factory Droid, and Cursor AI. It reads each tool's native session storage (read-only), extracts context (messages, file changes, tool activity, AI reasoning), and injects it into a different tool as a structured markdown handoff document.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.43)
- Warning: Touches multiple target skills; review destination carefully.
