# Repo Evolution Report

- Generated: 2026-04-17T11:39:18.662238+00:00
- Repo: `/tmp/agent-composer-ccmanager/ccmanager-main`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `cli workflow and configuration, session continuity and handoff, verification and quality gates, packaging and import hygiene, cross-tool parsing and extraction`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, AGENTS.md, CLAUDE.md, package.json`
- Summary: # CCManager - AI Code Agent Session Manager [![Mentioned in Awesome Gemini CLI](https://awesome.re/mentioned-badge.svg)](https://github.com/Piebald-AI/awesome-gemini-cli) CCManager is a CLI application for managing multiple AI coding assistant sessions (Claude Code, Gemini CLI, Codex CLI, Cursor Agent, Copilot CLI, Cline CLI, OpenCode, Kimi CLI) across Git worktrees and projects. https://github.com/user-attachments/a

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 191
- Files selected: 20
- Sections seen: 296
- Sections kept: 246
- Candidates produced: 40

### Top Files

- `package.json` score `14` because high-signal file: package.json, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `.kiro/steering/tech.md` score `13` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `README.md` score `12` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration
- `.kiro/steering/structure.md` score `12` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `AGENTS.md` score `12` because high-signal file: AGENTS.md, matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration
- `CLAUDE.md` score `12` because high-signal file: CLAUDE.md, matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration
- `.claude/commands/kiro/validate-gap.md` score `11` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `.kiro/specs/result-pattern-error-handling-2/design.md` score `10` because matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `.claude/commands/kiro/spec-design.md` score `10` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `docs/worktree-hooks.md` score `10` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration

## Decision Summary

- Adopt: 0
- Adapt: 40
- Store: 0
- Reject: 0

## Guardrail Warnings

- 11 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### 44f3000262 - ADAPT

- Source: `.kiro/steering/structure.md`
- Section: `Types Directory (`src/types/`)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Purpose**: Shared TypeScript type definitions ``` types/ └── index.ts # Central type definitions export
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/skill-map.md (reference, similarity 0.22)

### 729dd0da86 - ADAPT

- Source: `docs/multi-project.md`
- Section: `Project Discovery`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: CCManager automatically discovers git repositories by: Recursively scanning the root directory Identifying directories containing `.git` folders Excluding git worktrees (they're managed separately within their parent project)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.22)

### 98d74135f0 - ADAPT

- Source: `docs/multi-project.md`
- Section: `Data Structures`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```typescript interface GitProject { path: string; // Absolute path to git repository name: string; // Project name (directory name)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.27)

### c17ff5efb0 - ADAPT

- Source: `docs/multi-project.md`
- Section: `Best Practices`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. **Organize Projects**: Keep git repositories in a dedicated directory structure 2. **Use Recent Projects**: Take advantage of the recent projects feature for quick access 3. **Keyboard Navigation**: Learn the number key shortcuts for faster navigation 4. **Search Efficiently**: Use `/` search to quickly filter large project lists
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/onboard/PLAYBOOK.md (playbook, similarity 0.29)

### a99b9f8288 - ADAPT

- Source: `README.md`
- Section: `Features`
- Category: `routing improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Automatic project discovery**: Recursively finds all git repositories **Recent projects**: Frequently used projects appear at the top **Vi-like search**: Press `/` to filter projects or worktrees **Session persistence**: Sessions remain active when switching projects
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.26)
- Warning: Touches multiple target skills; review destination carefully.

### f54126bad6 - ADAPT

- Source: `.kiro/specs/result-pattern-error-handling-2/design.md`
- Section: `WorktreeService (src/services/worktreeService.ts)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Responsibility & Boundaries** **Primary Responsibility**: Manage Git worktree operations (list, create, delete, merge) **Domain Boundary**: Git worktree domain **Data Ownership**: Worktree metadata, Git repository state
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.28)
- Warning: Long section; likely needs summarization before reuse.

### 383749b929 - ADAPT

- Source: `.claude/commands/kiro/spec-design.md`
- Section: `Error Categories and Responses`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **User Errors** (4xx): Invalid input → field-level validation; Unauthorized → auth guidance; Not found → navigation help **System Errors** (5xx): Infrastructure failures → graceful degradation; Timeouts → circuit breakers; Exhaustion → rate limiting **Business Logic Errors** (422): Rule violations → condition explanations; State conflicts → transition guidance **Process Flow Visualization** (when complex business log
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/clarify/PLAYBOOK.md (playbook, similarity 0.23)
- Warning: Touches multiple target skills; review destination carefully.

### 3285b39b41 - ADAPT

- Source: `src/services/sessionManager.test.ts`
- Section: `Document`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import {describe, it, expect, beforeEach, afterEach, vi} from 'vitest'; import {Effect, Either} from 'effect'; import {ValidationError} from '../types/errors.js'; import {spawn, type IPty} from './bunTerminal.js';
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/overdrive/PLAYBOOK.md (playbook, similarity 0.25)
- Warning: Long section; likely needs summarization before reuse.

### c7e990a786 - ADAPT

- Source: `src/components/NewWorktree.test.tsx`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import React from 'react'; import {render} from 'ink-testing-library'; import NewWorktree from './NewWorktree.js'; import {vi, describe, it, expect, beforeEach, afterEach} from 'vitest';
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.23)
- Warning: Long section; likely needs summarization before reuse.

### 6c605cbe96 - ADAPT

- Source: `.kiro/steering/tech.md`
- Section: `Multi-Project Mode`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **CCMANAGER_MULTI_PROJECT_ROOT**: Root directory for automatic git repository discovery ```bash export CCMANAGER_MULTI_PROJECT_ROOT="/path/to/projects" ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.36)

### 85f8c838d2 - ADAPT

- Source: `README.md`
- Section: `Features`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Run multiple AI assistant sessions in parallel across different Git worktrees **Multi-project support**: Manage multiple git repositories from a single interface Support for multiple AI coding assistants (Claude Code, Gemini CLI, Codex CLI, Cursor Agent, Copilot CLI, Cline CLI, OpenCode, Kimi CLI) Switch between sessions seamlessly
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/overdrive/PLAYBOOK.md (playbook, similarity 0.32)

### 03990c8cf5 - ADAPT

- Source: `README.md`
- Section: `Per-Project Configuration`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: CCManager supports per-project configuration by placing a `.ccmanager.json` file in your git repository root. Project settings are merged with the global config (`~/.config/ccmanager/config.json`), with project settings always taking priority. For detailed configuration options and examples, see [docs/project-config.md](docs/project-config.md).
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.38)

### e3935add76 - ADAPT

- Source: `README.md`
- Section: `Multi-Project Mode`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: CCManager can manage multiple git repositories from a single interface, allowing you to organize and navigate between different projects and their worktrees efficiently.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/critique/PLAYBOOK.md (playbook, similarity 0.35)

### 3a2e3d3922 - ADAPT

- Source: `.kiro/steering/structure.md`
- Section: `Import Order (by convention)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. External dependencies (React, Ink, node-pty, etc.) 2. Internal components (relative imports from `components/`) 3. Internal services (relative imports from `services/`) 4. Internal types (relative imports from `types/`)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/audit/PLAYBOOK.md (playbook, similarity 0.36)

### 5bc6b6cf9c - ADAPT

- Source: `.kiro/steering/structure.md`
- Section: `Path Style`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Relative imports**: Used throughout the codebase (`../services/sessionManager`) **No path aliases**: Project does not use TypeScript path mapping
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/extract/PLAYBOOK.md (playbook, similarity 0.38)

### cf3b81a862 - ADAPT

- Source: `.claude/commands/kiro/validate-gap.md`
- Section: `1. Current State Investigation`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Existing Codebase Analysis**: Identify files and modules related to the feature domain Map current architecture patterns, conventions, and tech stack usage Document existing services, utilities, and reusable components
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/extract/PLAYBOOK.md (playbook, similarity 0.42)

### e3a809d508 - ADAPT

- Source: `.kiro/specs/result-pattern-error-handling-2/design.md`
- Section: `Decision 1: Effect vs Either for Different Operation Types`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Decision**: Use `Effect<A, E>` for asynchronous operations and `Either<E, A>` for synchronous operations. **Context**: CCManager has both synchronous operations (configuration parsing, path manipulation) and asynchronous operations (Git commands, file I/O, PTY spawning). We need to choose the appropriate type for each use case. **Alternatives**: 1. Use Effect for all operations (synchronous and asynchronous)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/modes/plan-execution/PLAYBOOK.md (playbook, similarity 0.39)

### 94f38e0747 - ADAPT

- Source: `.kiro/specs/result-pattern-error-handling-2/design.md`
- Section: `Worktree Config Utilities (src/utils/worktreeConfig.ts)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Responsibility & Boundaries** **Primary Responsibility**: Read and write Git worktree config extensions **Domain Boundary**: Git worktree config domain **Data Ownership**: Worktree parent branch configuration
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/SKILL.md (skill, similarity 0.41)

### a12b2b267a - ADAPT

- Source: `.kiro/specs/result-pattern-error-handling-2/design.md`
- Section: `Claude Dir Utilities (src/utils/claudeDir.ts)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Responsibility & Boundaries** **Primary Responsibility**: Resolve Claude Code project directory paths **Domain Boundary**: Claude directory resolution domain **Data Ownership**: No persistent state, pure path transformations
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-implementer/SKILL.md (skill, similarity 0.37)

### 1bb5b6ae18 - ADAPT

- Source: `docs/worktree-hooks.md`
- Section: `Environment Variables`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: When a worktree hook is executed, the following environment variables are available: `CCMANAGER_WORKTREE_PATH`: The absolute path to the newly created worktree `CCMANAGER_WORKTREE_BRANCH`: The branch name of the worktree `CCMANAGER_GIT_ROOT`: The root path of the git repository
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md (playbook, similarity 0.45)

### dfcda61348 - ADAPT

- Source: `docs/multi-project.md`
- Section: `Multi-Project Mode`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: CCManager's multi-project mode allows you to manage multiple git repositories from a single interface, making it easy to work across different projects without running multiple CCManager instances.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/SKILL.md (skill, similarity 0.41)

### 5f138d65fe - ADAPT

- Source: `docs/multi-project.md`
- Section: `Overview`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: In multi-project mode, CCManager discovers all git repositories within a specified root directory and presents them in an organized interface. You can quickly switch between projects, manage their worktrees, and maintain active AI assistant sessions across all projects simultaneously.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.34)

### 838d6378af - ADAPT

- Source: `docs/multi-project.md`
- Section: `Environment Variable`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Multi-project mode requires setting the `CCMANAGER_MULTI_PROJECT_ROOT` environment variable: ```bash export CCMANAGER_MULTI_PROJECT_ROOT="/path/to/your/projects" ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.33)

### d4a22be932 - ADAPT

- Source: `README.md`
- Section: `🚀 No tmux dependency`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: CCManager is completely self-contained. No need to install or configure tmux - it works out of the box. Perfect if you don't use tmux or want to keep your tmux setup separate from Claude Code management.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/normalize/PLAYBOOK.md (playbook, similarity 0.40)
- Warning: Touches multiple target skills; review destination carefully.

### 0aa5139da1 - ADAPT

- Source: `README.md`
- Section: `Quick Start`
- Category: `workflow improvement`
- Primary target: `agent-pilot`
- Secondary targets: `agent-composer`
- Why target: section is mainly about phased execution, gates, or coordinated delivery
- Proposed destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. Navigate to **Global Configuration** → **Other & Experimental** 2. Enable **Auto Approval (experimental)** 3. (Optional) Configure a custom command for verification For detailed configuration and usage, see [docs/auto-approval.md](docs/auto-approval.md).
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-pilot, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-docs/SKILL.md (skill, similarity 0.32)
- Warning: Touches multiple target skills; review destination carefully.

### dd822d3c4f - ADAPT

- Source: `README.md`
- Section: `Navigation`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. **Project List**: Select from all discovered git repositories 2. **Worktree Menu**: Manage worktrees for the selected project 3. **Session View**: Interact with your AI assistant Use `B` key to navigate back from worktrees to project list.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.36)
- Warning: Touches multiple target skills; review destination carefully.

### 83a0151bdf - ADAPT

- Source: `.kiro/steering/structure.md`
- Section: `2. Service-Oriented Architecture`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Business logic isolated in service classes Clear separation between UI and logic Dependency injection via context or props
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/normalize/PLAYBOOK.md (playbook, similarity 0.36)
- Warning: Touches multiple target skills; review destination carefully.

### 88f5678f81 - ADAPT

- Source: `.kiro/specs/result-pattern-error-handling-2/design.md`
- Section: `Non-Goals`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Implementing Effect's dependency injection system (Context/Layer) in the initial migration Migrating to Effect's streaming or scheduling capabilities Replacing all existing async code with Effect-based implementations in a single release Using Effect Schema for validation (future consideration)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/overdrive/PLAYBOOK.md (playbook, similarity 0.33)
- Warning: Touches multiple target skills; review destination carefully.

### a575e4dc7b - ADAPT

- Source: `.kiro/specs/result-pattern-error-handling-2/design.md`
- Section: `ProjectManager (src/services/projectManager.ts)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Responsibility & Boundaries** **Primary Responsibility**: Discover and manage multiple Git projects in multi-project mode **Domain Boundary**: Multi-project orchestration domain **Data Ownership**: Project cache, recent projects list
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-pilot/SKILL.md (skill, similarity 0.35)
- Warning: Long section; likely needs summarization before reuse.

### 0a23d0df72 - ADAPT

- Source: `.kiro/specs/result-pattern-error-handling-2/design.md`
- Section: `Git Status Utilities (src/utils/gitStatus.ts)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Responsibility & Boundaries** **Primary Responsibility**: Execute Git status commands and parse output **Domain Boundary**: Git status query domain **Data Ownership**: Git status information (files changed, ahead/behind counts)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.33)
- Warning: Long section; likely needs summarization before reuse.

### e02e357fa9 - ADAPT

- Source: `.kiro/specs/result-pattern-error-handling-2/design.md`
- Section: `Phase 2: Utility Layer Migration (Week 2)`
- Category: `workflow improvement`
- Primary target: `agent-pilot`
- Secondary targets: `agent-orchestrator`
- Why target: Retargeted toward agent-pilot because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Goal**: Migrate all utility functions to Effect types **Tasks**: 1. Migrate src/utils/gitStatus.ts to return Effect types Replace GitOperationResult<T> with Effect<T, GitError>
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-pilot, agent-orchestrator. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.31)
- Warning: Touches multiple target skills; review destination carefully.

### ce500c0452 - ADAPT

- Source: `.claude/commands/kiro/spec-design.md`
- Section: `[Component Name]`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Responsibility & Boundaries** **Primary Responsibility**: Single, clear statement of what this component does **Domain Boundary**: Which domain/subdomain this belongs to **Data Ownership**: What data this component owns and manages
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/colorize/PLAYBOOK.md (playbook, similarity 0.40)
- Warning: Long section; likely needs summarization before reuse.

### 32a5d18d89 - ADAPT

- Source: `.claude/commands/kiro/spec-design.md`
- Section: `Migration Strategy`
- Category: `workflow improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-orchestrator/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **REQUIRED**: Include Mermaid flowchart showing migration phases **Process**: Phase breakdown, rollback triggers, validation checkpoints </structured-document> 
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-orchestrator/references/autonomy-patterns.md (reference, similarity 0.44)
- Warning: Touches multiple target skills; review destination carefully.

### 404d893410 - ADAPT

- Source: `docs/worktree-hooks.md`
- Section: `Execution Context`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The working directory for hooks depends on the hook type: | Hook | Working Directory | Worktree Exists? | |------|-------------------|------------------| | `pre_creation` | Git root directory | No |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/arrange/PLAYBOOK.md (playbook, similarity 0.43)
- Warning: Touches multiple target skills; review destination carefully.

### f2458a9639 - ADAPT

- Source: `src/services/autoApprovalVerifier.ts`
- Section: `Document`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import {Effect} from 'effect'; import {ProcessError} from '../types/errors.js'; import {AutoApprovalResponse} from '../types/index.js'; import {configReader} from './config/configReader.js';
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/interaction-design.md (support, similarity 0.30)
- Warning: Long section; likely needs summarization before reuse.

### 681da9c3f9 - ADAPT

- Source: `docs/multi-project.md`
- Section: `Future Enhancements`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Planned improvements for multi-project mode: Project grouping and categorization Global session overview across all projects Project-specific configuration overrides
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-stitch/modes/shadcn-integration/PLAYBOOK.md (playbook, similarity 0.39)
- Warning: Touches multiple target skills; review destination carefully.

### ee25707045 - ADAPT

- Source: `docs/auto-approval.md`
- Section: `Custom Command (optional power users)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Purpose: replace the default `claude --model haiku` call (uses your installed `claude` CLI; CCManager does not bundle it) with any executable or script you control. How CCManager calls it: Runs via your shell: `spawn(customCommand, [], {shell: true})`. Environment variables provided:
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/PLAYBOOK.md (playbook, similarity 0.33)
- Warning: Long section; likely needs summarization before reuse.

### cd1e016587 - ADAPT

- Source: `.kiro/steering/tech.md`
- Section: `Terminal & Process Management`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **node-pty**: ^1.0.0 - PTY (pseudoterminal) interface for spawning processes **@xterm/headless**: ^5.5.0 - Terminal emulator without DOM **strip-ansi**: ^7.1.0 - ANSI escape code processing
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/SKILL.md (skill, similarity 0.22)

### 5b9941c3b6 - ADAPT

- Source: `.kiro/steering/tech.md`
- Section: `Optional Tools`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Claude Code CLI (`claude` command) Gemini CLI (`gemini` command) Docker/Devcontainer CLI (for container integration) tmux or similar (optional, not required unlike Claude Squad)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.29)

### 3c7ca84af6 - ADAPT

- Source: `.kiro/steering/tech.md`
- Section: `Installation`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash npm install -g ccmanager # Global installation npm install # Local development setup ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.22)
