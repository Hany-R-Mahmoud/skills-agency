# Repo Evolution Report

- Generated: 2026-04-17T12:31:25.785180+00:00
- Repo: `/tmp/claude-code-templates-main`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `verification and quality gates, cli workflow and configuration, packaging and import hygiene, cross-tool parsing and extraction, session continuity and handoff`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, CLAUDE.md, package.json`
- Summary: [![npm version](https://img.shields.io/npm/v/claude-code-templates.svg)](https://www.npmjs.com/package/claude-code-templates) [![npm downloads](https://img.shields.io/npm/dt/claude-code-templates.svg)](https://www.npmjs.com/package/claude-code-templates) [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT) [![PRs Welcome](https://img.shields.io/badge/PRs-welcome-

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 5525
- Files selected: 20
- Sections seen: 700
- Sections kept: 384
- Candidates produced: 40

### Top Files

- `cli-tool/components/skills/workflow-automation/n8n/n8n-node-configuration/README.md` score `16` because high-signal file: README.md, implementation or validation support file, matches repo capability: cross-tool parsing and extraction
- `cli-tool/components/skills/ai-research/loki-mode/autonomy/README.md` score `16` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `CLAUDE.md` score `15` because high-signal file: CLAUDE.md, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `cli-tool/src/validation/README.md` score `15` because high-signal file: README.md, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `cli-tool/components/skills/development/web-to-markdown/README.md` score `15` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `api/README.md` score `15` because high-signal file: README.md, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `cli-tool/templates/ruby/examples/rails-app/CLAUDE.md` score `14` because high-signal file: CLAUDE.md, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `cli-tool/components/skills/ai-research/qa-test-planner/README.md` score `14` because high-signal file: README.md, implementation or validation support file, matches repo capability: cross-tool parsing and extraction
- `cli-tool/templates/ruby/CLAUDE.md` score `14` because high-signal file: CLAUDE.md, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `cli-tool/components/skills/development/dependency-updater/README.md` score `14` because high-signal file: README.md, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration

## Decision Summary

- Adopt: 12
- Adapt: 28
- Store: 0
- Reject: 0

## Guardrail Warnings

- 1 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### 0b3ec8829e - ADOPT

- Source: `CLAUDE.md`
- Section: `Statuslines with Python Scripts`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Statuslines can reference Python scripts that are auto-downloaded to `.claude/scripts/`: ```javascript // In src/index.js:installIndividualSetting() if (settingName.includes('statusline/')) {
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md (playbook, similarity 0.29)

### a6c049e814 - ADOPT

- Source: `CLAUDE.md`
- Section: `Featured Pages (`/featured/[slug]`)`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Featured partner integrations shown on the dashboard homepage. Two files to edit: **`dashboard/src/lib/constants.ts`** — `FEATURED_ITEMS` array. Each entry has: `name`, `description`, `logo`, `url` (`/featured/slug`), `tag`, `tagColor`, `category` `ctaLabel`, `ctaUrl`, `websiteUrl`
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-reviewer/modes/adversarial-review/PLAYBOOK.md (playbook, similarity 0.24)

### ffea440d1a - ADOPT

- Source: `CLAUDE.md`
- Section: `Legacy Static Site (docs/)`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The `docs/` directory contains the old static HTML site (no longer deployed to www). Blog articles in `docs/blog/` are still referenced externally.
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/bolder/PLAYBOOK.md (playbook, similarity 0.29)

### 2914e523aa - ADOPT

- Source: `cli-tool/src/validation/README.md`
- Section: `Scoring Algorithm`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```javascript componentScore = ( structuralScore * 0.25 + integrityScore * 0.20 +
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/interaction-design.md (support, similarity 0.25)

### 629f491fcf - ADOPT

- Source: `cli-tool/src/validation/README.md`
- Section: `Integration with Component Generation`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The security validation system integrates with `scripts/generate_components_json.py`: 1. **Automatic Validation** - Runs before generating components.json 2. **Metadata Inclusion** - Security scores, hashes, validation status 3. **Download Statistics** - Combined with Supabase analytics
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.29)

### b35a040fa3 - ADOPT

- Source: `cli-tool/components/skills/development/dependency-updater/README.md`
- Section: `Purpose`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The Dependency Updater skill provides intelligent, language-agnostic dependency management that: **Auto-detects your project type** by scanning for package files (package.json, go.mod, Cargo.toml, etc.) **Applies safe updates automatically** (minor and patch versions) **Prompts for major updates individually** to prevent breaking changes
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.26)

### 22e61ecceb - ADOPT

- Source: `cli-tool/components/skills/development/openapi-to-typescript/README.md`
- Section: `Type Mapping`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Primitives**: `string` → `string` `number` / `integer` → `number` `boolean` → `boolean`
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/harden/PLAYBOOK.md (playbook, similarity 0.20)

### b16d37b585 - ADOPT

- Source: `cli-tool/components/skills/development/openapi-to-typescript/README.md`
- Section: `Related Tools`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: This skill complements: **openapi-validator**: Validate OpenAPI specs before conversion **api-client-generator**: Generate full API clients using these types **schema-diff**: Compare OpenAPI versions to track type changes
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.28)

### 98f3210282 - ADOPT

- Source: `cli-tool/components/skills/workflow-automation/n8n/n8n-workflow-patterns/README.md`
- Section: `Last Updated`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 2025-10-20 **Part of**: n8n-skills repository **Conceived by**: Romuald Członkowski - [www.aiadvisors.pl/en](https://www.aiadvisors.pl/en)
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.27)

### 732c8bd98e - ADOPT

- Source: `cli-tool/components/skills/development/typescript-expert/SKILL.md`
- Section: `Monorepo Management`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Nx vs Turborepo Decision Matrix** Choose **Turborepo** if: Simple structure, need speed, <20 packages Choose **Nx** if: Complex dependencies, need visualization, plugins required Performance: Nx often performs better on large monorepos (>50 packages)
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.25)

### 4251c8546a - ADOPT

- Source: `cli-tool/components/skills/development/typescript-expert/SKILL.md`
- Section: `Performance Considerations`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: [ ] Type complexity doesn't cause slow compilation [ ] No excessive type instantiation depth [ ] Avoid complex mapped types in hot paths [ ] Use `skipLibCheck: true` in tsconfig
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/arrange/PLAYBOOK.md (playbook, similarity 0.26)

### f0d50d408a - ADOPT

- Source: `cli-tool/components/skills/development/typescript-expert/SKILL.md`
- Section: `"Which tool should I use?"`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ``` Type checking only? → tsc Type checking + linting speed critical? → Biome Type checking + comprehensive linting? → ESLint + typescript-eslint
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/optimize/PLAYBOOK.md (playbook, similarity 0.27)

### f1951c734e - ADAPT

- Source: `cli-tool/components/skills/development/swarmvault/README.md`
- Section: `Quickstart`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `5` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash swarmvault init --obsidian --profile personal-research swarmvault init --obsidian --profile reader,timeline swarmvault demo --no-serve
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 5/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.09)
- Warning: Long section; likely needs summarization before reuse.

### 5ed46c66a1 - ADAPT

- Source: `CLAUDE.md`
- Section: `pulse (Weekly KPI Report)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Collects metrics from GitHub, Discord, Supabase, Vercel, and Google Analytics every Sunday at 14:00 UTC and sends a consolidated report via Telegram. **Architecture:** Single `index.js` file (no npm dependencies at runtime). All source collectors, formatter, and Telegram sender in one file. **Cron:** `0 14 * * 0` (Sundays 14:00 UTC / 11:00 AM Chile) ```bash
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-architect/SKILL.md (skill, similarity 0.20)

### c6b97bef49 - ADAPT

- Source: `CLAUDE.md`
- Section: `Test single source`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: curl -X POST "https://pulse-weekly-report.SUBDOMAIN.workers.dev/trigger?source=github" \ H "Authorization: Bearer $TRIGGER_SECRET"
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.20)

### bb33fb17d6 - ADAPT

- Source: `CLAUDE.md`
- Section: `Dry run (no Telegram)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: curl -X POST "https://pulse-weekly-report.SUBDOMAIN.workers.dev/trigger?send=false" \ H "Authorization: Bearer $TRIGGER_SECRET" ``` **Secrets (Cloudflare):**
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-security/SKILL.md (skill, similarity 0.29)

### 230f49cc72 - ADAPT

- Source: `CLAUDE.md`
- Section: `Important Notes`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Component catalog**: Always regenerate after adding/modifying components **API tests**: Required before production deploy (breaks download tracking) **Secrets**: Never commit API keys (use environment variables) **Paths**: Use relative paths for all project files
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/PLAYBOOK.md (playbook, similarity 0.27)

### f9581f0c77 - ADAPT

- Source: `cli-tool/src/validation/README.md`
- Section: `Performance Optimization`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Validation of 372 components: ~20 seconds Parallel validation with async/await Cached hash registry for faster checks JSON report generation optimized
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-reviewer/SKILL.md (skill, similarity 0.28)

### c007f1326c - ADAPT

- Source: `cli-tool/components/skills/development/web-to-markdown/README.md`
- Section: `How It Works`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The skill uses the `web2md` CLI tool which: 1. **Launches a real browser** (Chrome/Chromium/Brave/Edge) via Puppeteer 2. **Renders the page** including all JavaScript and dynamic content 3. **Extracts main content** using Mozilla's Readability library
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.27)

### 8cd98c8d5a - ADAPT

- Source: `cli-tool/components/skills/workflow-automation/n8n/n8n-workflow-patterns/README.md`
- Section: `Evaluations`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 5 scenarios (100% coverage expected): 1. **eval-001**: Webhook workflow structure 2. **eval-002**: HTTP API integration pattern 3. **eval-003**: Database sync pattern
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.24)

### 843e995d04 - ADAPT

- Source: `cli-tool/components/skills/workflow-automation/n8n/n8n-workflow-patterns/README.md`
- Section: `Files`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **SKILL.md** (486 lines) - Pattern overview, selection guide, checklist **webhook_processing.md** (554 lines) - Webhook patterns, data structure, auth **http_api_integration.md** (763 lines) - REST APIs, pagination, rate limiting **database_operations.md** (854 lines) - DB operations, batch processing, security
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-security/SKILL.md (skill, similarity 0.24)

### e9e9c61c4e - ADAPT

- Source: `cli-tool/templates/python/examples/fastapi-app/CLAUDE.md`
- Section: `Background Tasks`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```python from fastapi import BackgroundTasks @app.post("/send-email/") async def send_email(background_tasks: BackgroundTasks):
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/skill-map.md (reference, similarity 0.23)

### bc49504c89 - ADAPT

- Source: `cli-tool/templates/python/examples/fastapi-app/CLAUDE.md`
- Section: `Getting Started`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. Clone repository 2. Create virtual environment: `python -m venv venv` 3. Install dependencies: `pip install -r requirements.txt` 4. Set environment variables
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.21)

### 6c4f020100 - ADAPT

- Source: `cli-tool/templates/python/examples/fastapi-app/CLAUDE.md`
- Section: `Code Quality`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Black** - Code formatting **isort** - Import sorting **mypy** - Type checking **pytest** - Testing framework
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.25)

### c3a3fa5738 - ADAPT

- Source: `cli-tool/components/skills/development/swarmvault/README.md`
- Section: `SwarmVault Skill`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Use the SwarmVault skill when you want a local-first knowledge vault that compiles books, articles, notes, transcripts, chat exports, emails, calendars, datasets, spreadsheets, slide decks, screenshots, URLs, code, and research captures into durable markdown pages, a searchable graph, dashboards, and reviewable outputs on disk. SwarmVault is built on the [LLM Wiki](https://gist.github.com/karpathy/442a6bf555914893e98
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.26)

### 7ebd80de63 - ADAPT

- Source: `cli-tool/components/skills/security/aws-penetration-testing/references/advanced-aws-pentesting.md`
- Section: `Malicious Lambda code to escalate privileges`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import boto3 import json def handler(event, context): iam = boto3.client("iam")
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.22)

### 4fffc38138 - ADAPT

- Source: `cli-tool/components/skills/development/dependency-updater/README.md`
- Section: `Related Tools`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Tool | Language | Purpose | Link | |------|----------|---------|------| | taze | Node.js | Smart dependency updates | [GitHub](https://github.com/antfu-collective/taze) | | npm-check-updates | Node.js | Alternative to taze | [GitHub](https://github.com/raineorshine/npm-check-updates) |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.22)
- Warning: Touches multiple target skills; review destination carefully.

### 8de165cbe9 - ADAPT

- Source: `cli-tool/components/skills/workflow-automation/n8n/n8n-node-configuration/README.md`
- Section: `File Structure`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ``` n8n-node-configuration/ ├── SKILL.md (692 lines) │ Main configuration guide
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-security/SKILL.md (skill, similarity 0.38)

### d1c0dde584 - ADAPT

- Source: `cli-tool/src/validation/README.md`
- Section: `5. Provenance Validation`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Validates component authorship and origin. **Checks:** ✅ Author metadata in frontmatter ✅ Repository information
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/normalize/PLAYBOOK.md (playbook, similarity 0.36)

### bfccc164a6 - ADAPT

- Source: `cli-tool/src/validation/README.md`
- Section: `GitHub Actions Workflow`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: The repository includes a GitHub Actions workflow that automatically validates components on: ✅ Pull requests modifying components ✅ Pushes to main branch **File:** `.github/workflows/component-security-validation.yml`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.41)

### 19b9109bdc - ADAPT

- Source: `cli-tool/src/validation/README.md`
- Section: `Failed Components`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. agents/security/penetration-tester.md Error: Dangerous command detected: `rm -rf /tmp` Score: 50/100 [View Full Report](artifacts/security-report.json)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-tester/references/eval-regression-patterns.md (reference, similarity 0.38)

### 2afb999fcf - ADAPT

- Source: `cli-tool/src/validation/README.md`
- Section: `Provenance (PROV_*)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Code | Type | Message | |------|------|---------| | `PROV_E001` | Error | Missing author information | | `PROV_W001` | Warning | No repository information |
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/ux-writing.md (support, similarity 0.33)

### 4db2cf69e5 - ADAPT

- Source: `cli-tool/src/validation/README.md`
- Section: `For Repository Maintainers`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. **Review PR Validation Results:** Check GitHub Actions status Review security scores Investigate failed components
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-debugging/SKILL.md (skill, similarity 0.42)

### 13650d0f42 - ADAPT

- Source: `cli-tool/components/skills/development/web-to-markdown/README.md`
- Section: `When to Use`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Use this skill when you need to: Extract article content from news sites, blogs, or documentation Convert JavaScript-heavy pages that simple HTTP fetching can't handle Archive web content in a readable, portable format
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.34)

### 97a218bfe5 - ADAPT

- Source: `cli-tool/components/skills/development/web-to-markdown/README.md`
- Section: `Interactive Mode (Login Walls)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Handle pages requiring login or human verification: ```bash use the skill web-to-markdown to convert https://example.com/protected-article in interactive mode ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.40)

### 3eee3e1d50 - ADAPT

- Source: `cli-tool/components/skills/ai-research/qa-test-planner/README.md`
- Section: `5. Bug Report Documentation`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Generates structured bug reports with: Clear reproduction steps Environment details (OS, browser, device, build) Expected vs actual behavior
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-debugging/SKILL.md (skill, similarity 0.44)

### fa389a385a - ADAPT

- Source: `cli-tool/components/skills/ai-research/qa-test-planner/README.md`
- Section: `Example 5: Create Bug Report`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Input:** ``` /qa-test-planner Create a bug report for: Form validation doesn't prevent submission when email field is empty
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/clarify/PLAYBOOK.md (playbook, similarity 0.44)

### 6061a30156 - ADAPT

- Source: `cli-tool/components/skills/ai-research/qa-test-planner/README.md`
- Section: `Bug Report Checklist`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Reproducible steps provided Environment documented completely Screenshots or evidence attached Severity and priority set appropriately
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.36)

### 410f833373 - ADAPT

- Source: `cli-tool/components/skills/ai-research/qa-test-planner/README.md`
- Section: `Bug Reporting`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Provide clear reproduction steps anyone can follow Include screenshots, videos, or console logs Specify exact environment details Describe impact on users
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-debugging/SKILL.md (skill, similarity 0.42)

### b035653b54 - ADAPT

- Source: `cli-tool/components/skills/ai-research/qa-test-planner/README.md`
- Section: `Getting Started`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. Activate the skill: `/qa-test-planner` 2. Describe what you need (test plan, test cases, bug report, etc.) 3. Review and customize the generated documentation 4. Copy to your tracking system (Jira, Linear, etc.)
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/normalize/PLAYBOOK.md (playbook, similarity 0.44)
