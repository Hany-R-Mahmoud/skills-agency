# Repo Evolution Report

- Generated: 2026-04-17T09:01:57.722031+00:00
- Repo: `/Users/hanyramadan/.codex/skills`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Decision Summary

- Adopt: 0
- Adapt: 8
- Store: 0
- Reject: 0

## Guardrail Warnings

- 2 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### 54b6bf23fe - ADAPT

- Source: `agent-impeccable/modes/onboard/PLAYBOOK.md`
- Section: `Technical approaches:`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `routing improvements, import hygiene, playbook structure`
- Excerpt: **Tooltip libraries**: Tippy.js, Popper.js **Tour libraries**: Intro.js, Shepherd.js, React Joyride **Modal patterns**: Focus trap, backdrop, ESC to close **Progress tracking**: LocalStorage for "seen" states
- Rationale: Category: routing improvement. Priorities matched: routing improvements, import hygiene, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/frontend-design/reference/motion-design.md (support, similarity 0.27)

### 8ce0fc0213 - ADAPT

- Source: `atlassian-mcp/PLAYBOOK.md`
- Section: `Knowledge Reference`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: Atlassian MCP Server (official), mcp-atlassian (sooperset), atlassian-mcp (xuanxt), JQL (Jira Query Language), CQL (Confluence Query Language), OAuth 2.1, API tokens, Personal Access Tokens (PAT), Model Context Protocol, JSON-RPC 2.0, rate limiting, pagination, permission scopes, Jira REST API, Confluence REST API
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/clarify/PLAYBOOK.md (playbook, similarity 0.17)

### 5b010a23c6 - ADAPT

- Source: `chatgpt-apps/references/window-openai-patterns.md`
- Section: `Runtime APIs`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: `window.openai.callTool(name, args)`: call another MCP tool from the widget `window.openai.sendFollowUpMessage({ prompt, scrollToBottom? })`: ask ChatGPT to post a widget-authored follow-up message `window.openai.openExternal({ href, redirectUrl? })`: open an external URL through ChatGPT's vetted flow `window.openai.requestDisplayMode({ mode })`: request `inline`, `pip`, or `fullscreen`
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-pilot/SKILL.md (skill, similarity 0.25)

### c82bceb923 - ADAPT

- Source: `game-developer/references/performance-optimization.md`
- Section: `Occlusion Culling`
- Category: `routing improvement`
- Targets: `agent-orchestrator`
- Destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: ```csharp // Setup in Unity: // 1. Mark static objects as "Occluder Static" and "Occludee Static" // 2. Window > Rendering > Occlusion Culling
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-orchestrator. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-debugging/references/observability-debugging.md (reference, similarity 0.15)

### 7672c70fe3 - ADAPT

- Source: `openai-docs/PLAYBOOK.md`
- Section: `OpenAI product snapshots`
- Category: `workflow improvement`
- Targets: `agent-pilot`
- Destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `routing improvements, evaluation loops, playbook structure`
- Excerpt: 1. Apps SDK: Build ChatGPT apps by providing a web component UI and an MCP server that exposes your app's tools to ChatGPT. 2. Responses API: A unified endpoint designed for stateful, multimodal, tool-using interactions in agentic workflows. 3. Chat Completions API: Generate a model response from a list of messages comprising a conversation. 4. Codex: OpenAI's coding agent for software development that can write, und
- Rationale: Category: workflow improvement. Priorities matched: routing improvements, evaluation loops, playbook structure. Likely targets: agent-pilot. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.23)

### f4f04ce018 - ADAPT

- Source: `.system/openai-docs/SKILL.md`
- Section: `OpenAI product snapshots`
- Category: `workflow improvement`
- Targets: `agent-pilot`
- Destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `routing improvements, evaluation loops, playbook structure`
- Excerpt: 1. Apps SDK: Build ChatGPT apps by providing a web component UI and an MCP server that exposes your app's tools to ChatGPT. 2. Responses API: A unified endpoint designed for stateful, multimodal, tool-using interactions in agentic workflows. 3. Chat Completions API: Generate a model response from a list of messages comprising a conversation. 4. Codex: OpenAI's coding agent for software development that can write, und
- Rationale: Category: workflow improvement. Priorities matched: routing improvements, evaluation loops, playbook structure. Likely targets: agent-pilot. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.23)
- Warning: Comes from a system skill; verify that local skill-pack conventions still fit.

### df03fccf62 - ADAPT

- Source: `chatgpt-apps/PLAYBOOK.md`
- Section: `8. Plan Production Hosting and Deployment`
- Category: `routing improvement`
- Targets: `agent-orchestrator, agent-composer`
- Destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `routing improvements, playbook structure`
- Excerpt: When the user asks to deploy or prepare for launch, generate hosting guidance for the MCP server (and widget assets if hosted separately). Host behind a stable public HTTPS endpoint (not a tunnel) with dependable TLS Preserve low-latency streaming behavior on `/mcp` Configure secrets outside the repo (environment variables / secret manager)
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 454bb3c817 - ADAPT

- Source: `chatgpt-apps/references/apps-sdk-docs-workflow.md`
- Section: `Suggested `openai-docs` / MCP Queries`
- Category: `workflow improvement`
- Targets: `agent-pilot, agent-composer`
- Destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, playbook structure`
- Excerpt: Use focused searches before fetching: `ChatGPT Apps SDK build MCP server register resource template resourceUri outputTemplate` `ChatGPT Apps SDK build ChatGPT UI MCP Apps bridge ui/notifications/tool-result` `ChatGPT Apps SDK examples React widget upload modal Pizzaz`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure. Likely targets: agent-pilot, agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 3/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/frontend-design/reference/motion-design.md (support, similarity 0.19)
- Warning: Touches multiple target skills; review destination carefully.
