# Repo Evolution Report

- Generated: 2026-04-17T11:49:48.859850+00:00
- Repo: `/tmp/agent-composer-clauditor/clauditor-main`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Repo Profile

- Kind: `continuity-cli`
- Capabilities: `cli workflow and configuration, session continuity and handoff, cross-tool parsing and extraction, verification and quality gates, packaging and import hygiene`
- Likely targets: `agent-composer, agent-orchestrator, agent-pilot`
- Key files: `README.md, package.json, src/cli.ts, src/index.ts`
- Summary: <p align="center"> <h1 align="center">clauditor</h1> <p align="center"> <strong>Stop Claude Code from burning through your quota in 20 minutes.</strong>

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Extraction Diagnostics

- Files scanned: 98
- Files selected: 20
- Sections seen: 55
- Sections kept: 51
- Candidates produced: 40

### Top Files

- `README.md` score `14` because high-signal file: README.md, matches repo capability: session continuity and handoff, matches repo capability: cli workflow and configuration
- `package.json` score `13` because high-signal file: package.json, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `src/cli.ts` score `12` because entrypoint source file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `src/hooks/session-start.ts` score `11` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `src/index.ts` score `11` because entrypoint source file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction
- `package-lock.json` score `10` because matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration, matches repo capability: verification and quality gates
- `src/features/handoff-quality.ts` score `10` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `src/hooks/user-prompt-submit.ts` score `10` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `src/hooks/post-compact.ts` score `10` because matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction, matches repo capability: cli workflow and configuration
- `src/features/skill-suggest.test.ts` score `10` because implementation or validation support file, matches repo capability: session continuity and handoff, matches repo capability: cross-tool parsing and extraction

## Decision Summary

- Adopt: 1
- Adapt: 39
- Store: 0
- Reject: 0

## Guardrail Warnings

- 7 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### 0cc872fc7f - ADOPT

- Source: `README.md`
- Section: `Legal`
- Category: `packaging improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/SKILL.md`
- Scores: novelty `4` | utility `4` | fit `5` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: MIT License. Not affiliated with or endorsed by Anthropic. No leaked source code was referenced or used All features derived from official docs, public community discussions, and independent observation "clauditor" = "Claude" + "auditor", used in a descriptive, nominative sense
- Rationale: Category: packaging improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 5/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/PLAYBOOK.md (playbook, similarity 0.29)

### e00e524bd8 - ADAPT

- Source: `README.md`
- Section: `Why both?`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Research shows LLM-generated summaries suffer from knowledge overwriting and semantic drift ([Size-Fidelity Paradox](https://arxiv.org/abs/2602.09789)). Mechanical extraction preserves files and commits deterministically. Claude's prose captures reasoning the transcript can't. Together they give the next session the best possible starting point. ```bash clauditor handoff-report # see what your last handoff contains `
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.23)

### 9dc86bebc8 - ADAPT

- Source: `README.md`
- Section: `Team knowledge sync (optional, beta)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: For teams, clauditor can optionally connect to a hub for shared knowledge: ```bash clauditor login ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/references/command-packaging-patterns.md (reference, similarity 0.27)

### 9fb8643928 - ADAPT

- Source: `README.md`
- Section: `Version-aware warnings`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: clauditor detects if your sessions ran on Claude Code versions 2.1.69-2.1.89, which have a [confirmed prompt caching bug](https://github.com/anthropics/claude-code/issues/34629) that causes 10-20x token consumption. The warning appears in `clauditor report` and via real-time hooks.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-debugging/SKILL.md (skill, similarity 0.26)

### 8a0f8a1392 - ADAPT

- Source: `src/index.ts`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: export type { SessionRecord, UserRecord, AssistantRecord,
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.20)

### 187f50b903 - ADAPT

- Source: `README.md`
- Section: `Limitations`
- Category: `routing improvement`
- Primary target: `agent-orchestrator`
- Secondary targets: `agent-composer`
- Why target: section is mainly about planning, checkpoints, or execution structure
- Proposed destination: `agent-orchestrator/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Cannot reduce Claude Code's context assembly.** We observe and advise — we don't modify what Claude Code sends to the API. **Cannot see quota.** Anthropic doesn't expose quota data. The waste factor is a proxy based on token growth. **Cache reads may or may not count toward quota.** The exact quota accounting for Max plan subscribers is not published. **Web sessions not supported.** Only CLI and IDE extensions writ
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/PLAYBOOK.md (playbook, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 2a6a8da52b - ADAPT

- Source: `src/features/skill-suggest.test.ts`
- Section: `Document`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import { describe, it, expect } from 'vitest' import { detectWorkflowPatterns, generateSkillSuggestions } from './skill-suggest.js' import type { SessionState, TokenUsage, CacheHealth, LoopState, ResumeAnomaly, QuotaBurnRate } from '../types.js' function makeSession(label: string, toolCalls: Array<{ name: string; inputHash: string }>): SessionState {
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/overdrive/PLAYBOOK.md (playbook, similarity 0.20)
- Warning: Long section; likely needs summarization before reuse.

### 7eaa75ffe5 - ADAPT

- Source: `src/features/skill-suggest.ts`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import type { SessionState, TurnMetrics, ToolCallSummary } from '../types.js' import type { SubagentSignal } from './subagent-intel.js' export interface WorkflowPattern { /** Normalized sequence of tool calls */
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/references/composition-standards.md (reference, similarity 0.24)
- Warning: Long section; likely needs summarization before reuse.

### c506443d4b - ADAPT

- Source: `src/daemon/parser.test.ts`
- Section: `Document`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import { describe, it, expect } from 'vitest' import { parseJsonlLine, extractTurns, aggregateUsage } from './parser.js' import type { AssistantRecord, UserRecord, ToolResultRecord, SessionRecord } from '../types.js' describe('parseJsonlLine', () => {
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/overdrive/PLAYBOOK.md (playbook, similarity 0.20)
- Warning: Long section; likely needs summarization before reuse.

### 82ca485d3c - ADAPT

- Source: `src/features/session-state-extraction.test.ts`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import { describe, it, expect, beforeEach, afterEach, vi } from 'vitest' import { mkdtempSync, writeFileSync, mkdirSync, rmSync } from 'node:fs' import { join } from 'node:path' import { tmpdir } from 'node:os'
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.27)
- Warning: Long section; likely needs summarization before reuse.

### dd97a9af6e - ADAPT

- Source: `README.md`
- Section: `All commands`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: | Command | Description | |---|---| | `clauditor` | Show quota report (default) | | `clauditor install` | Register hooks into Claude Code (one-time) |
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/SKILL.md (skill, similarity 0.40)

### e6846e258e - ADAPT

- Source: `README.md`
- Section: `or: npm install -g @iyadhk/clauditor`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: clauditor report # see waste across all sessions clauditor time # peak vs off-peak token analysis clauditor sessions # per-session breakdown clauditor doctor # scan for cache bugs
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/audit/PLAYBOOK.md (playbook, similarity 0.30)

### ce4d3831a3 - ADAPT

- Source: `src/hooks/session-start.ts`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import { resolve } from 'node:path' import { homedir } from 'node:os' import { readdir, stat } from 'node:fs/promises' import type { HookDecision } from '../types.js'
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.42)
- Warning: Long section; likely needs summarization before reuse.

### 10199af4a1 - ADAPT

- Source: `src/hooks/post-tool-use.ts`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import { readFile } from 'node:fs/promises' import { homedir } from 'node:os' import { resolve } from 'node:path' import type { PostToolUseHookInput, HookDecision, TurnMetrics } from '../types.js'
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.38)
- Warning: Long section; likely needs summarization before reuse.

### 7cf2def1b5 - ADAPT

- Source: `src/daemon/parser.ts`
- Section: `Document`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import { createHash } from 'node:crypto' import { readFile } from 'node:fs/promises' import type { SessionRecord,
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.33)
- Warning: Long section; likely needs summarization before reuse.

### ccb5482a0b - ADAPT

- Source: `src/features/handoff-quality.test.ts`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition and closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import { describe, it, expect, beforeEach, afterEach } from 'vitest' import { mkdtempSync, rmSync, writeFileSync } from 'node:fs' import { join, resolve } from 'node:path' import { tmpdir } from 'node:os'
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.33)
- Warning: Long section; likely needs summarization before reuse.

### 5e78e9f355 - ADAPT

- Source: `README.md`
- Section: `Peak vs off-peak analysis`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `5` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash clauditor time ``` Shows token costs by hour of day to detect if peak hours burn more quota:
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 5/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/colorize/PLAYBOOK.md (playbook, similarity 0.14)

### 402a45864f - ADAPT

- Source: `README.md`
- Section: `Install`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash brew install IyadhKhalfallah/clauditor/clauditor clauditor install ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.20)

### 0747a92708 - ADAPT

- Source: `README.md`
- Section: `Works alongside other tools`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: clauditor operates at the **session boundary** layer — it monitors waste and rotates sessions. Other tools work at different layers and are fully compatible: | Tool | Layer | What it does | Conflicts? | |---|---|---|---| | [Headroom](https://github.com/chopratejas/headroom) | API proxy | Compresses tool output tokens (~34% savings per turn) | No — works at HTTP level |
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.28)

### 4373da1223 - ADAPT

- Source: `README.md`
- Section: `Project memory`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: clauditor learns from your sessions and builds per-project knowledge at `~/.clauditor/knowledge/<project>/`. **Error index with confidence decay** — Records failed commands and their fixes. Each error has a confidence score (0–1) that decays with a 45-day half-life. Recent errors rank above old ones. Stale errors fade naturally instead of accumulating forever. ``` npm run build conf=0.85 (confirmed, 5x)
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/PLAYBOOK.md (playbook, similarity 0.24)

### b4a166b12d - ADAPT

- Source: `README.md`
- Section: `The problem`
- Category: `routing improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/request-recipes.md`
- Scores: novelty `4` | utility `4` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Every turn in a Claude Code session re-sends your entire conversation history to the API. A fresh session sends ~20k tokens per turn. A 200-turn session sends ~200k per turn. **Same work, 10x more quota.** ``` Turn 1: ██ 20k tokens Turn 50: ██████████ 100k tokens
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### aa37ef6c4e - ADAPT

- Source: `README.md`
- Section: ``PostToolUse` — blocks during autonomous work`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `4` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: When Claude is working autonomously (editing files, running commands), there's no user prompt to intercept. The PostToolUse hook catches this — after each tool call, it checks the waste factor and blocks if too high. Uses exit code 2, which Claude Code treats as a blocking error. Claude acknowledges it, writes a handoff summary, and stops. Also detects: cache degradation, token spikes, resume anomalies, edit thrashin
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 4/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.28)
- Warning: Touches multiple target skills; review destination carefully.

### 819c1e41a9 - ADAPT

- Source: `README.md`
- Section: `Document`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: <p align="center"> <h1 align="center">clauditor</h1> <p align="center"> <strong>Stop Claude Code from burning through your quota in 20 minutes.</strong>
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/reference/spatial-design.md (support, similarity 0.38)

### 541f7c58b6 - ADAPT

- Source: `README.md`
- Section: `The solution`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: clauditor monitors your session size and **blocks Claude when you're wasting quota**, saving your progress so you can start fresh without losing context. ``` ╔══════════════════════════════════════════════════════════════╗ ║ clauditor: Session using 9x more quota than necessary ║
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-stitch/modes/stitch-foundation/PLAYBOOK.md (playbook, similarity 0.42)

### c0478525dd - ADAPT

- Source: `README.md`
- Section: ``UserPromptSubmit` — blocks before tokens are wasted`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Before Claude processes your prompt, clauditor checks two things: 1. **Waste factor** — if the session is burning too much quota, it blocks with exit code 2. 2. **"Continue" detection** — if you type "continue", "resume", "pick up where I left off", etc., it blocks with your saved session choices and copyable prompts. ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/arrange/PLAYBOOK.md (playbook, similarity 0.31)

### dc3dc066e2 - ADAPT

- Source: `README.md`
- Section: ``PreCompact` — saves context before compaction`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Fires at the exact moment before Claude Code compacts your context. Saves session state as a fallback in case PostCompact doesn't fire.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/normalize/PLAYBOOK.md (playbook, similarity 0.39)

### 07f08f4af7 - ADAPT

- Source: `README.md`
- Section: ``PostCompact` — captures Claude's summary + mechanical state`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Fires after compaction. Merges Claude's own LLM-generated summary with mechanically extracted structured data (files, commits, commands) from the JSONL transcript.
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.33)

### 622c1bed2e - ADAPT

- Source: `README.md`
- Section: ``PreToolUse` — prevents known errors`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Before Claude runs a command, clauditor checks the local error index (and optionally the team hub) for previous failures with the same binary. If a known fix exists with sufficient confidence, it injects it as context — non-blocking, so Claude can adapt without being stopped. ``` [clauditor]: `npm run build` has failed 5 times on this project. Last error: Module not found: Cannot resolve @/lib/db
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-pilot/references/shared-team-contract.md (reference, similarity 0.35)

### 643e727c22 - ADAPT

- Source: `README.md`
- Section: `Real data`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: From a real user's Claude Code usage over 7 days: ``` TURNS BASE NOW WASTE TOKENS ──────────────────────────────────────────────────────────
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-co-pilot/SKILL.md (skill, similarity 0.38)

### 05045c869d - ADAPT

- Source: `README.md`
- Section: `Dashboard (optional)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: ```bash clauditor watch ``` ```
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/README.md (script, similarity 0.33)

### e3f83dff86 - ADAPT

- Source: `README.md`
- Section: `Audit-only mode (no hooks)`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Don't want clauditor to block or modify your sessions? Skip `clauditor install` and use it as a read-only analytics tool: ```bash brew install IyadhKhalfallah/clauditor/clauditor
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/frontend-design/PLAYBOOK.md (playbook, similarity 0.33)

### b71a237842 - ADAPT

- Source: `README.md`
- Section: `Configuration`
- Category: `routing improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: best ownership fit based on section semantics and current local overlap
- Proposed destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Everything works out of the box. One config file at `~/.clauditor/config.json`: ```json { "rotation": {
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-impeccable/modes/teach-impeccable/PLAYBOOK.md (playbook, similarity 0.45)

### 40150154ab - ADAPT

- Source: `README.md`
- Section: `Per-session storage`
- Category: `workflow improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: closest meaningful local overlap points to the same skill
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `3` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Each handoff is saved as a separate timestamped file: ``` ~/.clauditor/sessions/<encoded-project-path>/<timestamp>.md ```
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 2/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.33)

### 635f2ba96a - ADAPT

- Source: `README.md`
- Section: `Contributing`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Contributions welcome. Rules: **No leaked source code.** Do not reference or derive logic from non-public Anthropic code. **Attributable knowledge only.** Official docs, public GitHub issues, community posts, or independent observation. **Clean-room implementation.** If unsure about a knowledge source, don't contribute it.
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 4/5, risk 2/5.
- Overlap check: Closest local match: agent-orchestrator/SKILL.md (skill, similarity 0.38)

### c9ef03ab58 - ADAPT

- Source: `README.md`
- Section: `Structured handoff template`
- Category: `heuristic or reference improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `3` | utility `4` | fit `4` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: When clauditor blocks a session for rotation, it tells Claude to write its handoff in a structured format: ``` TASK: (what you were working on) COMPLETED: (what's done)
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 3/5, utility 4/5, fit 4/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.40)
- Warning: Touches multiple target skills; review destination carefully.

### f252724a4d - ADAPT

- Source: `README.md`
- Section: `Mechanical extraction`
- Category: `workflow improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `3` | utility `4` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: Every handoff also includes structured data extracted mechanically from the JSONL transcript: Files modified and read Git commits (verbatim messages) Key commands and results (builds, tests, deploys)
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.38)
- Warning: Touches multiple target skills; review destination carefully.

### 3cc517b811 - ADAPT

- Source: `README.md`
- Section: `Session resume flow`
- Category: `routing improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/request-recipes.md`
- Scores: novelty `3` | utility `4` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: 1. clauditor blocks your session (or `/compact` fires) 2. Context is saved — structured template + mechanical data 3. You open a new session and type "continue" 4. clauditor blocks with your saved sessions and copyable prompts
- Rationale: Category: routing improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.41)
- Warning: Touches multiple target skills; review destination carefully.

### b56bfb1b2a - ADAPT

- Source: `src/tui/alerts.tsx`
- Section: `Document`
- Category: `heuristic or reference improvement`
- Primary target: `agent-composer`
- Secondary targets: `none`
- Why target: section is mainly about skill packaging, import hygiene, or composition
- Proposed destination: `agent-composer/references/`
- Scores: novelty `3` | utility `4` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import React from 'react' import { Box, Text } from 'ink' import type { SessionState } from '../types.js' interface AlertsProps {
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-composer. Scores - novelty 3/5, utility 4/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-impeccable/modes/audit/PLAYBOOK.md (playbook, similarity 0.36)
- Warning: Long section; likely needs summarization before reuse.

### a2f6ce7a22 - ADAPT

- Source: `README.md`
- Section: `Technical details`
- Category: `heuristic or reference improvement`
- Primary target: `agent-history`
- Secondary targets: `agent-composer`
- Why target: Retargeted toward agent-history because the section semantics and closest local overlap both point there.
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `3` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: **Why sessions get expensive:** Every Claude Code API call sends: `tools` → `system prompt` → `CLAUDE.md` → `conversation history`. The conversation history grows linearly. Cache makes the prefix cheap (cache_read), but the growing tail requires cache_create each turn. ``` API call = tools (cached) + system (cached) + history (grows every turn)
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history, agent-composer. Scores - novelty 4/5, utility 3/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-history/SKILL.md (skill, similarity 0.29)
- Warning: Touches multiple target skills; review destination carefully.

### 97221ffb34 - ADAPT

- Source: `src/hooks/user-prompt-submit.ts`
- Section: `Document`
- Category: `heuristic or reference improvement`
- Primary target: `agent-history`
- Secondary targets: `none`
- Why target: section is about session continuity, handoff, or context extraction
- Proposed destination: `agent-history/references/`
- Scores: novelty `4` | utility `3` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene, playbook structure, routing improvements`
- Excerpt: import { readFileSync } from 'node:fs' import { saveSessionState as saveSState, extractSessionStateFromTranscript, readRecentHandoffs, extractHandoffDescription } from '../features/session-state.js' import { readConfig } from '../config.js' import { loadCalibration } from '../features/calibration.js'
- Rationale: Category: heuristic or reference improvement. Priorities matched: evaluation loops, import hygiene, playbook structure, routing improvements. Likely targets: agent-history. Scores - novelty 4/5, utility 3/5, fit 3/5, risk 3/5.
- Overlap check: Closest local match: agent-composer/scripts/repo_evolution.py (script, similarity 0.25)
- Warning: Long section; likely needs summarization before reuse.
