# Repo Evolution Report

- Generated: 2026-04-17T09:00:13.496309+00:00
- Repo: `/Users/hanyramadan/.codex/skills`
- Source mode: `local-path`
- Skills reviewed: `19`
- Default focus: `agent-pilot, agent-composer, agent-orchestrator`

## Default Contract

- Goal: compare the repo against local `agent-*` skills and keep only useful, non-duplicative, safe improvements.
- Guardrails: dry-run first, prefer updating playbooks and references before SKILL.md, no bloat, no over-engineering, no breaking current routing, show adopt/adapt/store/reject for each candidate
- Priorities: routing improvements, evaluation loops, import hygiene, playbook structure

## Decision Summary

- Adopt: 0
- Adapt: 12
- Store: 0
- Reject: 0

## Guardrail Warnings

- 3 candidate(s) touch multiple skills; keep edits sequential and narrow.

## Candidates

### 54b6bf23fe - ADAPT

- Source: `agent-impeccable/modes/onboard/PLAYBOOK.md`
- Section: `Technical approaches:`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `routing improvements, import hygiene, playbook structure`
- Excerpt: **Tooltip libraries**: Tippy.js, Popper.js **Tour libraries**: Intro.js, Shepherd.js, React Joyride **Modal patterns**: Focus trap, backdrop, ESC to close **Progress tracking**: LocalStorage for "seen" states
- Rationale: Category: routing improvement. Priorities matched: routing improvements, import hygiene, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/frontend-design/reference/motion-design.md (support, similarity 0.27)

### 8ce0fc0213 - ADAPT

- Source: `atlassian-mcp/PLAYBOOK.md`
- Section: `Knowledge Reference`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `routing improvements, playbook structure`
- Excerpt: Atlassian MCP Server (official), mcp-atlassian (sooperset), atlassian-mcp (xuanxt), JQL (Jira Query Language), CQL (Confluence Query Language), OAuth 2.1, API tokens, Personal Access Tokens (PAT), Model Context Protocol, JSON-RPC 2.0, rate limiting, pagination, permission scopes, Jira REST API, Confluence REST API
- Rationale: Category: routing improvement. Priorities matched: routing improvements, playbook structure. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/clarify/PLAYBOOK.md (playbook, similarity 0.17)

### 7672c70fe3 - ADAPT

- Source: `openai-docs/PLAYBOOK.md`
- Section: `OpenAI product snapshots`
- Category: `workflow improvement`
- Targets: `agent-pilot`
- Destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `2`
- Priorities: `routing improvements, evaluation loops, playbook structure`
- Excerpt: 1. Apps SDK: Build ChatGPT apps by providing a web component UI and an MCP server that exposes your app's tools to ChatGPT. 2. Responses API: A unified endpoint designed for stateful, multimodal, tool-using interactions in agentic workflows. 3. Chat Completions API: Generate a model response from a list of messages comprising a conversation. 4. Codex: OpenAI's coding agent for software development that can write, und
- Rationale: Category: workflow improvement. Priorities matched: routing improvements, evaluation loops, playbook structure. Likely targets: agent-pilot. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.23)

### f4f04ce018 - ADAPT

- Source: `.system/openai-docs/SKILL.md`
- Section: `OpenAI product snapshots`
- Category: `workflow improvement`
- Targets: `agent-pilot`
- Destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `routing improvements, evaluation loops, playbook structure`
- Excerpt: 1. Apps SDK: Build ChatGPT apps by providing a web component UI and an MCP server that exposes your app's tools to ChatGPT. 2. Responses API: A unified endpoint designed for stateful, multimodal, tool-using interactions in agentic workflows. 3. Chat Completions API: Generate a model response from a list of messages comprising a conversation. 4. Codex: OpenAI's coding agent for software development that can write, und
- Rationale: Category: workflow improvement. Priorities matched: routing improvements, evaluation loops, playbook structure. Likely targets: agent-pilot. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-composer/references/browser-composition.md (reference, similarity 0.23)
- Warning: Comes from a system skill; verify that local skill-pack conventions still fit.

### 454bb3c817 - ADAPT

- Source: `chatgpt-apps/references/apps-sdk-docs-workflow.md`
- Section: `Suggested `openai-docs` / MCP Queries`
- Category: `workflow improvement`
- Targets: `agent-pilot, agent-composer`
- Destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, playbook structure`
- Excerpt: Use focused searches before fetching: `ChatGPT Apps SDK build MCP server register resource template resourceUri outputTemplate` `ChatGPT Apps SDK build ChatGPT UI MCP Apps bridge ui/notifications/tool-result` `ChatGPT Apps SDK examples React widget upload modal Pizzaz`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure. Likely targets: agent-pilot, agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 3/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/frontend-design/reference/motion-design.md (support, similarity 0.19)
- Warning: Touches multiple target skills; review destination carefully.

### 9efd82e079 - ADAPT

- Source: `codex-primary-runtime/slides/SKILL.md`
- Section: `Conventions and gotchas`
- Category: `workflow improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene`
- Excerpt: New deck: `Presentation.create({ slideSize: { width: 1280, height: 720 } })`. `Presentation` is the in-memory deck object; `PresentationFile` is for `.pptx` import/export. Existing deck: `PresentationFile.importPptx(await FileBlob.load("input.pptx"))`. Export: `const pptx = await PresentationFile.exportPptx(presentation); await pptx.save("output.pptx")`.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene. Likely targets: agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-impeccable/modes/frontend-design/reference/ux-writing.md (support, similarity 0.30)
- Warning: Long section; likely needs summarization before reuse.

### c87b25d84b - ADAPT

- Source: `codex-primary-runtime/spreadsheets/SKILL.md`
- Section: `Tools + Contract`
- Category: `workflow improvement`
- Targets: `agent-pilot`
- Destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `routing improvements, evaluation loops, import hygiene, playbook structure`
- Excerpt: Author, edit, inspect, render, and export workbooks only with the JavaScript `@oai/artifact-tool` spreadsheet APIs from the managed Codex runtime. Put the executable JavaScript builder under the runtime Node tree so bare ESM `@oai/artifact-tool` imports resolve from the installed runtime `node_modules`: ```bash set -e
- Rationale: Category: workflow improvement. Priorities matched: routing improvements, evaluation loops, import hygiene, playbook structure. Likely targets: agent-pilot. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-architect/SKILL.md (skill, similarity 0.29)
- Warning: Long section; likely needs summarization before reuse.

### b77fdf12cb - ADAPT

- Source: `codex-primary-runtime/spreadsheets/SKILL.md`
- Section: `Build Rules`
- Category: `workflow improvement`
- Targets: `agent-orchestrator, agent-composer`
- Destination: `agent-orchestrator/references/`
- Scores: novelty `4` | utility `5` | fit `4` | risk `3`
- Priorities: `evaluation loops, playbook structure`
- Excerpt: Prefer block writes (`range.values`, `range.formulas`) over per-cell loops. Matrix shape must match the target range (for example `"D4:M4"` should be a 1x10 matrix, row x col). Seed scalar formulas once, then `fillDown()` / `fillRight()`. For dynamic-array formulas (`SEQUENCE`, `UNIQUE`, `FILTER`, `SORT`, `VSTACK`, `HSTACK`), write only the anchor cell and let the result spill after. Use `range.displayFormulas` plus 
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, playbook structure. Likely targets: agent-orchestrator, agent-composer. Scores - novelty 4/5, utility 5/5, fit 4/5, risk 3/5.
- Duplicate signal: Closest local match: agent-composer/references/repo-evolution-workflow.md (reference, similarity 0.26)
- Warning: Touches multiple target skills; review destination carefully.

### c82dae3d71 - ADAPT

- Source: `codex-primary-runtime/spreadsheets/SKILL.md`
- Section: `Core workbook/file APIs`
- Category: `workflow improvement`
- Targets: `agent-pilot, agent-composer`
- Destination: `agent-pilot/references/learned-patterns.md`
- Scores: novelty `4` | utility `5` | fit `3` | risk `3`
- Priorities: `evaluation loops, import hygiene`
- Excerpt: `import { FileBlob, SpreadsheetFile, Workbook } from "@oai/artifact-tool"` `const workbook = Workbook.create(); const sheet = workbook.worksheets.add("Sheet1")` `const workbook = await SpreadsheetFile.importXlsx(arrayBufferOrFileBlob)` `const xlsx = await SpreadsheetFile.exportXlsx(workbook); await xlsx.save("output.xlsx")`
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene. Likely targets: agent-pilot, agent-composer. Scores - novelty 4/5, utility 5/5, fit 3/5, risk 3/5.
- Duplicate signal: Closest local match: agent-stitch/references/skill-map.md (reference, similarity 0.24)
- Warning: Touches multiple target skills; review destination carefully.

### 16358632f2 - ADAPT

- Source: `AGENT_FIRST_REFACTOR.md`
- Section: `Conflict Rules`
- Category: `workflow improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `evaluation loops, import hygiene, playbook structure`
- Excerpt: 1. Workflow fit beats popularity. 2. Existing strong agents beat imported duplicates. 3. Architecture patterns are preferred over content imports. 4. Internalization beats public expansion when the idea is useful but noisy.
- Rationale: Category: workflow improvement. Priorities matched: evaluation loops, import hygiene, playbook structure. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md (playbook, similarity 0.46)

### 155a4195c5 - ADAPT

- Source: `INDEX.md`
- Section: `Internal Operational Playbooks`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `4` | risk `2`
- Priorities: `routing improvements, evaluation loops, playbook structure`
- Excerpt: These are still useful, but intentionally not public picker entries: | Folder | Document | Notes | | --- | --- | --- | | `others/bug-triage` | `PLAYBOOK.md` | issue classification and Plane routing |
- Rationale: Category: routing improvement. Priorities matched: routing improvements, evaluation loops, playbook structure. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 4/5, risk 2/5.
- Duplicate signal: Closest local match: agent-architect/SKILL.md (skill, similarity 0.41)

### ffe69c7b0f - ADAPT

- Source: `INDEX.md`
- Section: `Removed During Agent-First Refactor`
- Category: `routing improvement`
- Targets: `agent-composer`
- Destination: `agent-composer/references/request-recipes.md`
- Scores: novelty `3` | utility `5` | fit `3` | risk `2`
- Priorities: `routing improvements, evaluation loops, import hygiene, playbook structure`
- Excerpt: The following noise-heavy or duplicate families were removed from the public surface during this refactor: `agent-impeccable` standalone internal modes as public skills duplicate report/review helpers under `others/`
- Rationale: Category: routing improvement. Priorities matched: routing improvements, evaluation loops, import hygiene, playbook structure. Likely targets: agent-composer. Scores - novelty 3/5, utility 5/5, fit 3/5, risk 2/5.
- Duplicate signal: Closest local match: agent-impeccable/SKILL.md (skill, similarity 0.48)
