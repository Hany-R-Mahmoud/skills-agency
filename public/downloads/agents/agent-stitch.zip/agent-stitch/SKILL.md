---
name: agent-stitch
description: Unified Stitch design and design-to-code agent for this skill pack. Use when Codex should handle Stitch prompt design, DESIGN.md synthesis, screen generation or editing, accessibility-aware design refinement, optional generated media support, React handoff, shadcn integration, walkthrough creation, or iterative Stitch build loops through one local entry point.
---

# Agent Stitch

Provide a single public entry point for this repository's Stitch-oriented
design, generation, and handoff workflows.

Act as a router plus executor: choose the smallest set of Stitch modes needed,
sequence them well, and avoid loading irrelevant guidance.

Do not expose each imported Stitch workflow as its own public skill. Keep one
public surface and move the imported complexity into private modes, references,
and playbooks so the picker stays clean.

## Invocation Contract

Invoke this skill directly as `$agent-stitch` whenever the prompt is about
Stitch-based design generation, prompt enhancement, design-system capture,
screen editing, design-to-code handoff, Stitch-powered site loops, or
Stitch-driven delivery workflows.

When explicitly invoked, do not ask the user to choose internal modes unless
there is a real strategic tradeoff. Infer the likely path from the prompt, map
it to the minimum useful mode set, and proceed.

The user should not need to know or name the internal modes. Treat them as
private implementation details.

## Use This Skill For

- generating new screens or variants with Stitch
- editing an existing Stitch screen while preserving the established visual
  language
- creating or refreshing `.stitch/DESIGN.md` as a semantic source of truth
- improving weak Stitch prompts before generation
- converting Stitch output into React component systems
- integrating Stitch-driven UI work with shadcn/ui projects
- building walkthrough videos or iterative Stitch site loops
- pressure-testing generated work against a stricter taste and anti-slop bar
- improving accessibility expectations for Stitch prompts, designs, and handoff
- generating or refining supporting visual assets when the Stitch workflow
  benefits from external media generation

## Do Not Use This Skill For

- generic frontend implementation that does not involve Stitch workflows
- non-UI code review unrelated to Stitch, design generation, or handoff quality
- one-off design critique when Stitch is not part of the workflow

## Quick Start

If the request sounds like one of these, use the matching route immediately:

- "design a new page with Stitch":
  `stitch-foundation`, then usually `prompt-enhancement`, `generate-design`
- "edit this Stitch screen":
  `stitch-foundation`, then `edit-design`; optionally `taste-calibration`
- "create or update DESIGN.md":
  `stitch-foundation`, then `design-system`
- "make this prompt better for Stitch":
  `stitch-foundation`, then `prompt-enhancement`
- "make this accessible":
  `stitch-foundation`, then `accessibility-design`
- "generate supporting art or imagery for this Stitch workflow":
  `stitch-foundation`, then `inference-media`
- "turn this Stitch screen into React":
  `stitch-foundation`, then `react-handoff`; optionally
  `shadcn-integration`
- "use shadcn with this generated UI":
  `stitch-foundation`, then `shadcn-integration`; optionally
  `react-handoff`
- "make a walkthrough video from Stitch screens":
  `stitch-foundation`, then `remotion-walkthrough`
- "run an iterative Stitch build loop":
  `stitch-foundation`, then `stitch-loop`; often add `design-system`
- "make the output less generic":
  `stitch-foundation`, then `taste-calibration`; often add
  `prompt-enhancement`

If the user explicitly invokes `$agent-stitch`, default to automatic routing.
Only surface the chosen modes briefly when it helps explain the path.

## Core Workflow

1. Inspect the request and classify it:
   - new generation
   - targeted edit
   - design-system capture
   - prompt optimization
   - code handoff
   - UI library integration
   - walkthrough or delivery artifact
   - iterative autonomous loop
2. Load `modes/stitch-foundation/PLAYBOOK.md` first for shared Stitch workflow
   rules, context gathering, and asset hygiene.
3. If design context is weak or absent, use `prompt-enhancement` before any
   generation or edit call.
4. If design consistency matters across screens, use `design-system` before
   generation whenever `.stitch/DESIGN.md` is missing, stale, or obviously weak.
5. Choose the minimum set of additional modes from
   `references/skill-map.md` and `references/request-recipes.md`.
6. Execute in a sane order:
   - understand current project and assets
   - strengthen the prompt or design system
   - generate or edit in Stitch
   - sync local artifacts if needed
   - hand off to code, shadcn, video, or loop workflows
   - apply taste hardening if the result needs a stronger bar
7. Keep output cohesive. If multiple modes are used, resolve conflicts instead
   of stacking contradictory guidance.

## Automatic Routing Rule

When the prompt contains Stitch or design-generation intent but does not
specify a mode:

- infer the dominant intent from the prompt language
- choose one primary mode
- add only the minimum supporting modes needed
- continue without asking the user to pick from internal skills

Escalate only when the prompt genuinely points to incompatible outcomes, such
as "preserve the existing design exactly" and "reinvent the whole design
language" at the same time.

## Routing Rules

Default to these bundles:

- New Stitch page or feature:
  `stitch-foundation` plus `prompt-enhancement`, `generate-design`, optionally
  `taste-calibration`
- Existing Stitch project alignment:
  `stitch-foundation` plus `design-system`, then `generate-design` or
  `edit-design`
- Targeted refinement:
  `stitch-foundation` plus `edit-design`; add `taste-calibration` or
  `accessibility-design` when needed
- Stitch to code:
  `stitch-foundation` plus `react-handoff`; add `shadcn-integration` when the
  target stack uses shadcn/ui
- Delivery artifacts:
  `stitch-foundation` plus `remotion-walkthrough`; add `inference-media` when
  generated assets are part of the deliverable
- Autonomous website iteration:
  `stitch-foundation` plus `stitch-loop`, often with `design-system`

If a request is narrow, stay narrow. A prompt rewrite should not pull in full
code handoff, Remotion, and loop-planning by default.

Prefer a primary mode and at most 2-4 supporting modes for most tasks. Pull in
more only when the request is genuinely broad.

## Conflict Resolution

Some modes pull in opposite directions. Resolve them deliberately:

- `design-system` vs `fast one-off generation`:
  prefer `design-system` when the work will extend beyond one screen; prefer
  speed only for clearly disposable exploration
- `edit-design` vs `generate-design`:
  prefer `edit-design` when the structure mostly exists and the user wants
  targeted changes
- `react-handoff` vs `shadcn-integration`:
  use `react-handoff` for structure and code decomposition; add
  `shadcn-integration` only when the target codebase already wants shadcn/ui
- `taste-calibration` vs `strict fidelity`:
  preserve fidelity first unless the user explicitly asks to raise the design
  bar

## Default Execution Standards

Regardless of which modes are selected:

- inspect nearby local patterns before introducing new structure
- keep Stitch project IDs, screen IDs, and downloaded assets explicit
- treat `.stitch/DESIGN.md`, `.stitch/SITE.md`, and `.stitch/metadata.json` as
  first-class workflow context when they exist
- prefer targeted edits over full regeneration when a screen already exists
- make downloads, screenshots, and local artifact paths reproducible
- keep prompt quality, state tracking, and verification as part of correctness
- treat accessibility expectations as part of prompt and handoff correctness
- keep generated supporting media clearly scoped as optional workflow support,
  not as a substitute for design clarity
- avoid spawning many public skills for adjacent Stitch tasks

## User Request Translation

Users often describe outcomes, not modes. Translate intent like this:

- "make this prompt work better" usually means `prompt-enhancement`
- "keep future screens consistent" usually means `design-system`
- "build this page in Stitch" usually means `generate-design`
- "change this existing screen" usually means `edit-design`
- "make this Stitch work more accessible" usually means `accessibility-design`
- "generate visuals to support this Stitch design" usually means
  `inference-media`
- "implement this generated design" usually means `react-handoff`
- "make it work with shadcn" usually means `shadcn-integration`
- "make a product walkthrough" usually means `remotion-walkthrough`
- "keep iterating on the site automatically" usually means `stitch-loop`
- "this still looks generic" usually means `taste-calibration`

If the prompt mixes several Stitch desires, prioritize in this order unless the
user says otherwise:

1. preserve project consistency and local asset hygiene
2. improve prompt and design-system quality
3. generate or edit the right Stitch artifact
4. hand off cleanly to code or delivery workflows
5. raise the taste bar further

## Output Shape

Match the task:

- For generation or editing work:
  summarize the chosen modes, explain the sequence briefly, then perform the
  workflow
- For import or packaging work:
  summarize what was kept, what was adapted, and what was intentionally kept
  private
- For handoff work:
  describe the asset path, code strategy, and verification expectations

Always name the modes you chose when that helps the user understand the path.

## Reference

Use these references as needed:

- `references/skill-map.md`: compact map of all internal Stitch modes
- `references/request-recipes.md`: common user phrasing to mode bundles

Read only the relevant entries rather than reloading every playbook in full.
