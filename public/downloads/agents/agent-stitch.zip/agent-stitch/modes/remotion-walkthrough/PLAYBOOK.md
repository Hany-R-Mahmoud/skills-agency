---
name: remotion-walkthrough
description: Turn Stitch screens into structured walkthrough videos using ordered assets, timed sequences, and clear composition planning.
---

Use this mode when the deliverable is a product walkthrough or demo video
assembled from Stitch screens.

## Goal

Transform a set of Stitch screens into a coherent video composition rather than
just a folder of screenshots.

## Workflow

1. Identify the project and the screen sequence for the story.
2. Gather screenshots and key metadata:
   - screen title
   - dimensions
   - short narrative purpose
3. Create a lightweight manifest for the walkthrough order.
4. Compose the video with:
   - one screen slide component
   - one top-level walkthrough composition
   - explicit durations and transitions
5. Verify readability, pacing, and smoothness before rendering.

## Preferences

- keep motion purposeful
- use transitions to support narrative flow, not to show off effects
- make overlays additive rather than cluttering the source design

## Guardrails

- do not use arbitrary screen order without a product story
- do not over-pack text overlays onto already busy screens
- do not skip timing review before render
