---
name: generate-design
description: Generate new Stitch screens or variants from a strong prompt while keeping project-level consistency and local artifact paths explicit.
---

Use this mode when the user wants a new Stitch screen, a variant, or a first
pass design direction.

## Preparation

Run `stitch-foundation` first. If the prompt is weak, run
`prompt-enhancement`. If consistency matters and `.stitch/DESIGN.md` is weak or
missing, run `design-system` first.

## Workflow

1. Confirm the target project and device context.
2. Prepare the final prompt with:
   - page purpose
   - visual direction
   - design-system cues
   - explicit structure
3. Choose the right generation path:
   - new screen when structure does not exist yet
   - variant generation when exploring options around an existing concept
4. After generation, capture the important outputs:
   - resulting screen identity
   - any text descriptions or suggestions returned by the tool
   - local HTML and screenshot paths if artifacts are synced
5. Summarize what changed and what the next logical edit would be.

## Quality Bar

- prefer coherent structure over prompt verbosity
- preserve the project's visual language when extending an existing system
- surface meaningful generator suggestions to the user rather than hiding them

## Guardrails

- Do not regenerate repeatedly without learning from prior outputs
- Do not ignore returned hints or component suggestions
- Do not leave generated assets unnamed or detached from the project state
