---
name: stitch-foundation
description: Shared Stitch workflow foundation covering context gathering, project state, asset hygiene, and safe sequencing before any Stitch-specific mode runs.
---

Use this playbook before any other `agent-stitch` mode.

## Core Goal

Establish enough Stitch context to make good decisions without guessing:

- which project or screen we are working on
- whether local `.stitch/` artifacts already exist
- whether the task is generation, editing, design-system work, code handoff,
  video creation, or an iterative loop
- whether design consistency matters across more than one screen

## Context Gathering

Confirm or discover the minimum useful context:

1. **Project identity**
   - Prefer explicit project references when the user provides them
   - Otherwise inspect local `.stitch/metadata.json`, `.stitch/SITE.md`, or
     project notes before inventing IDs
2. **Current asset state**
   - Check for `.stitch/DESIGN.md`
   - Check for `.stitch/designs/*.html` and `.stitch/designs/*.png`
   - Treat downloaded assets as reusable context, not disposable clutter
3. **Workflow type**
   - New screen or variant
   - Edit to an existing screen
   - Design-system capture
   - Code handoff
   - Video artifact
   - Iterative baton loop
4. **Consistency bar**
   - One-off exploration can move faster
   - Multi-screen or handoff workflows need stronger design-system discipline

## Default Rules

- Prefer targeted edits over full regeneration when the user already has a
  usable Stitch screen
- Prefer using `.stitch/DESIGN.md` when it exists and still matches the project
- Keep project IDs, screen IDs, and file paths explicit in the working state
- Treat downloads, screenshots, and generated HTML as part of correctness
- If local assets already exist, avoid unnecessary refresh unless freshness
  clearly matters

## Asset Hygiene

- Use `.stitch/designs/` as the local staging area for Stitch outputs
- Keep artifact naming stable and page-oriented
- Preserve metadata files that future edits or loops rely on
- Record whether a file is canonical, stale, or exploratory

## Sequencing Bias

- Prompt quality before generation
- Design-system quality before multi-screen work
- Editing before regeneration when structure already exists
- Code handoff only after asset quality is good enough
- Loop continuation only after current state is written back clearly

## Guardrails

- Do not start with code handoff when the design intent is still unstable
- Do not regenerate screens casually when the user asked for a narrow fix
- Do not rely on vague prompt wording if you can strengthen it first
- Do not treat Stitch output as done until local state and paths are coherent
