---
name: edit-design
description: Make targeted Stitch screen changes while preserving the established design language, limiting unnecessary regeneration, and keeping edits explicit.
---

Use this mode when a screen already exists and the user wants to refine,
correct, or extend it.

## Goal

Prefer narrow, high-signal edits over broad regeneration.

## Workflow

1. Identify the exact screen and the smallest meaningful edit scope.
2. Preserve current design language:
   - reuse the active project style
   - pull from `.stitch/DESIGN.md` when present
3. Rewrite the request as a targeted change brief:
   - location
   - visual behavior
   - constraints
   - what must remain unchanged
4. Execute the edit path and capture updated artifacts if needed.
5. Summarize the delta instead of restating the whole screen.

## Best Practices

- ask for or infer the smallest useful edit zone
- keep surrounding structure stable unless the user requested a wider redesign
- favor iterative polish over destructive replacement

## Guardrails

- do not switch to full generation unless the existing screen is unusable
- do not drift the design system during a targeted edit
- do not bundle unrelated changes into one edit pass
