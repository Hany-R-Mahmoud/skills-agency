---
name: taste-calibration
description: Raise the Stitch quality bar by encoding stronger atmosphere, typography, color discipline, motion intent, and explicit anti-generic rules.
---

Use this mode when the output feels generic, too safe, or visibly AI-generated.

## Goal

Strengthen prompts or design-system rules so Stitch outputs feel more curated,
distinctive, and intentional.

## What To Tune

- atmosphere and density
- asymmetry vs predictability
- typography character and hierarchy
- palette discipline
- component restraint
- motion philosophy
- explicit bans on known AI-tell patterns

## Defaults

- favor one strong accent over many competing accents
- avoid pure black, pure white, neon glows, and generic purple-blue AI palettes
- avoid generic hero structures, equal-card grids, and filler marketing copy
- treat layout rhythm and typography as primary design tools

## Use Cases

- premium landing pages that feel too templated
- multi-screen work that is drifting into blandness
- DESIGN.md documents that need a stronger opinionated bar

## Guardrails

- do not invent a taste profile that conflicts with the product's intent
- do not force maximalism onto utilitarian software UIs
- do not use "premium" as an excuse for vague aesthetic language
