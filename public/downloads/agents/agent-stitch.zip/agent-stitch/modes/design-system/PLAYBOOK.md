---
name: design-system
description: Analyze Stitch project assets and synthesize or refresh `.stitch/DESIGN.md` as the semantic source of truth for future prompts and edits.
---

Use this mode when the project needs stronger consistency across Stitch
generations or when `.stitch/DESIGN.md` is missing, stale, or weak.

## Goal

Turn Stitch project evidence into an opinionated, natural-language design
system that future prompts can reuse.

## Evidence Sources

Prefer real project evidence over guesses:

- project metadata and theme settings
- existing screen screenshots
- downloaded HTML/CSS artifacts
- recurring spacing, shape, shadow, and typography patterns

## Synthesis Workflow

1. Identify the project and screen context worth modeling.
2. Extract the atmosphere:
   - mood
   - density
   - polish level
   - visual personality
3. Map the palette:
   - descriptive color name
   - exact hex code when known
   - functional role in the interface
4. Translate technical values into natural design language:
   - shape and roundness
   - elevation and shadow style
   - typography hierarchy
   - layout rhythm
5. Write `.stitch/DESIGN.md` as a source-of-truth document, not as raw CSS
   notes.

## Include

- visual theme and atmosphere
- color palette and roles
- typography rules
- component styling guidance
- layout principles
- motion or interaction cues when they materially affect prompting
- explicit anti-patterns if the project needs strong guardrails

## Guardrails

- Prefer descriptive design language backed by real values
- Do not dump raw utility classes into the final document
- Do not fabricate design intent that the current project contradicts
- Keep the document reusable for future prompts, not locked to one screen only
