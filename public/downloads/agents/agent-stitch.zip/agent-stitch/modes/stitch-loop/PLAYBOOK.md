---
name: stitch-loop
description: Run a baton-based Stitch site-building loop with explicit next-step state, project metadata, and local artifact updates between iterations.
---

Use this mode when the user wants repeatable page-by-page Stitch building
instead of a one-off design request.

## Goal

Keep the loop state explicit so each iteration can continue without guessing.

## Required State

- `.stitch/next-prompt.md` as the baton
- `.stitch/DESIGN.md` for visual consistency
- `.stitch/SITE.md` for roadmap, sitemap, and project intent
- `.stitch/metadata.json` for project and screen identifiers

## Workflow

1. Read the baton and extract the next page target.
2. Read the site and design context before generating anything.
3. Generate or update the page in Stitch.
4. Sync local artifacts and metadata.
5. Update the site plan to reflect what changed.
6. Write the next baton before finishing.

## Operating Rules

- the loop is not complete until the next baton exists
- metadata persistence matters as much as the generated page
- prefer extending the roadmap over inventing disconnected pages

## Guardrails

- do not lose track of the next page
- do not let generated files drift away from the documented sitemap
- do not keep the loop implicit in chat when files should hold the state
