---
name: shadcn-integration
description: Integrate Stitch-driven UI work into shadcn/ui projects through composition, theming, and project-safe customization.
---

Use this mode when the target codebase already uses shadcn/ui or when the user
explicitly wants Stitch output translated through shadcn patterns.

## Goal

Fit generated design intent into the shadcn/ui model without fighting the host
codebase.

## Workflow

1. Inspect whether shadcn/ui is already configured.
2. Identify which generated UI parts should map to existing shadcn components,
   blocks, or wrappers.
3. Prefer composition over forking:
   - keep `components/ui/` close to upstream expectations
   - place app-specific wrappers outside the raw UI primitives
4. Map theme and token decisions into the project's shadcn configuration and
   CSS variables where appropriate.
5. Preserve accessibility and responsive behavior while adapting the design.

## Best Practices

- use existing primitives when they fit
- create wrappers or higher-level composed components for project-specific UX
- keep class merging and variant logic consistent with the project's existing
  approach

## Guardrails

- do not force shadcn into a project that does not want it
- do not rewrite the whole stack just to match a generated screen literally
- do not edit shared UI primitives casually when wrappers solve the problem
