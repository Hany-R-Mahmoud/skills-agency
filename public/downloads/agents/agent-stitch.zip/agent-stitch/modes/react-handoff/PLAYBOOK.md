---
name: react-handoff
description: Convert Stitch output into modular React code with explicit asset handling, reusable components, and project-friendly decomposition.
---

Use this mode when Stitch-generated screens need to become maintainable React
code.

## Goal

Turn Stitch output into clean, modular frontend code rather than a one-file
dump.

## Workflow

1. Reuse local Stitch assets when available:
   - `.stitch/designs/{page}.html`
   - `.stitch/designs/{page}.png`
2. Read the screen structure and identify:
   - reusable component boundaries
   - data that should move into mocks or props
   - styling tokens that should map to project conventions
3. Generate code with clear decomposition:
   - small components
   - explicit prop types
   - data or content separated from presentation when useful
   - custom hooks only when real logic repetition exists
4. Wire the output into the target app entry points cleanly.
5. Validate the result against the project's TypeScript, architectural, and UI
   patterns.

## Preferences

- prefer component systems over giant page files
- prefer token and theme mapping over hardcoded colors
- prefer maintainable structure over pixel-perfect literal translation

## Guardrails

- do not hardcode random design values if the project already has tokens
- do not keep business logic embedded in generated UI components
- do not skip verification after generation
