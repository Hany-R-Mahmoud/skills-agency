---
name: prompt-enhancement
description: Transform vague UI ideas into structured Stitch-ready prompts with stronger component language, design-system cues, and clear page structure.
---

Use this mode when the user has a rough idea, a weak prompt, or inconsistent
generation results.

## Goal

Rewrite the user's request into a clearer Stitch prompt that improves output
quality without changing the core intent.

## Workflow

1. Assess what is missing:
   - platform and device bias
   - page or flow type
   - visual direction or atmosphere
   - design-system constraints
   - section structure
   - component vocabulary
2. If `.stitch/DESIGN.md` exists, pull the strongest relevant constraints into a
   compact "design system" block.
3. Replace vague wording with UI-specific language:
   - "nice header" becomes navigation, brand lockup, utility actions
   - "list of items" becomes card grid, media list, table, feed, or stack
4. Organize the prompt into a predictable structure:
   - intent and vibe
   - required design-system cues
   - explicit page structure or targeted edits
5. Keep the prompt actionable. More words are not automatically better.

## Output Shape

Prefer this format:

```md
[one-line purpose and vibe]

**DESIGN SYSTEM (REQUIRED):**
- Platform: ...
- Theme: ...
- Primary Accent: ...
- Surface: ...
- Shape / shadow guidance: ...

**Page Structure:**
1. **Header:** ...
2. **Primary area:** ...
3. **Supporting sections:** ...
4. **Footer or closing area:** ...
```

For targeted edits, switch to a small "Specific changes" list instead of full
page regeneration structure.

## Guardrails

- Do not overwrite a strong existing design system with generic defaults
- Do not add invented product facts, metrics, or business claims
- Do not over-design when the user asked for a narrow or utilitarian change
