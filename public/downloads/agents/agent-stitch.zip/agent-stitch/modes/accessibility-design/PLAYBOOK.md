---
name: accessibility-design
description: Add accessibility-aware constraints to Stitch prompts, design-system rules, and code handoff expectations so generated work is more inclusive from the start.
---

Use this mode when accessibility should shape Stitch generation or refinement,
not just be patched later.

## Focus Areas

- semantic page structure in prompts
- visible hierarchy and sufficient contrast expectations
- keyboard-friendly interaction patterns
- target sizes and touch affordances
- reduced motion and non-color cues
- handoff notes for labels, roles, and announcements when code work follows

## Guardrails

- do not rely on post-hoc accessibility fixes if the prompt can encode the
  right constraints early
- do not turn accessibility requirements into vague slogans; make them concrete
- do not erase the intended visual language while improving inclusion
