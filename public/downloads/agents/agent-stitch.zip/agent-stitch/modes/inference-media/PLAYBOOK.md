---
name: inference-media
description: Use optional external model-backed media generation to create supporting visual assets that strengthen a Stitch workflow without replacing the core design system.
---

Use this mode when a Stitch flow benefits from generated imagery, concept art,
placeholder visuals, or supporting motion/media assets.

## Best Fit

- hero imagery or concept visuals that clarify a generated screen direction
- placeholder assets for demos or walkthroughs
- supporting illustrations or branded atmospherics for prototypes

## Workflow

1. Decide whether the media is actually needed.
2. Define the asset role precisely:
   - hero support
   - section illustration
   - walkthrough backing visual
   - prototype placeholder
3. Generate or refine the asset with explicit style constraints so it supports
   the Stitch design language.
4. Keep the media workflow separate from the core screen prompt so failures do
   not destabilize the whole Stitch task.

## Guardrails

- do not use generated media to paper over a weak layout or weak prompt
- do not let supporting visuals override the established design system
- do not make asset generation mandatory for otherwise clear Stitch work
