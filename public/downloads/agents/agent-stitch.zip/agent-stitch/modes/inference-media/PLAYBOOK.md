---
name: inference-media
description: Use optional external model-backed media generation to create supporting visual assets that strengthen a Stitch workflow without replacing the core design system.
---

Use this mode when a Stitch flow benefits from generated imagery, concept art,
placeholder visuals, or supporting motion/media assets.

## Best Fit

- hero imagery or concept visuals that clarify a generated screen direction
- placeholder assets for demos or walkthroughs
- supporting illustrations or branded atmospherics for prototypes

## Workflow

1. Decide whether the media is actually needed.
2. Define the asset role precisely:
   - hero support
   - section illustration
   - walkthrough backing visual
   - prototype placeholder
3. Structure the media brief so it stays reusable:
   - subject and scene
   - product role
   - visual style and mood
   - composition or motion behavior
   - explicit exclusions
4. Generate or refine the asset with explicit style constraints so it supports
   the Stitch design language.
5. Review the output before endorsing it:
   - brand fit
   - representation quality
   - artifact check
   - usefulness to the screen
6. Keep the media workflow separate from the core screen prompt so failures do
   not destabilize the whole Stitch task.

## Follow-Up Capture

If the media pass produces something worth reusing across later screens or
iterations, store the abstraction rather than the whole prompt dump:

- reusable visual constraints that belong in `.stitch/DESIGN.md`
- asset-role notes that belong in project working context
- negative constraints that should repeat in future media requests
- unresolved issues that should block broader reuse until checked

Prefer a short constraint block over a long style manifesto.

## Review Gate

Before treating the asset as good enough:

1. Does it strengthen the current Stitch screen instead of masking weak layout
   or weak copy?
2. Does it match the project's design-system cues and tone?
3. If people or places are shown, are they specific and respectful rather than
   generic?
4. Are there visible generation artifacts, implausible details, or inconsistent
   motion cues?
5. Is the next step to reuse the constraint, replace the asset, or drop media
   entirely?

## Guardrails

- do not use generated media to paper over a weak layout or weak prompt
- do not let supporting visuals override the established design system
- do not make asset generation mandatory for otherwise clear Stitch work
- do not store raw prompt bulk when a short reusable constraint block will do
