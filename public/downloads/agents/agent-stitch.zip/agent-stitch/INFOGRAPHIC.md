# Stitch Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for STITCH inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Product and Design department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: STITCH
- Subtitle: Stitch generation and design-to-code workflow specialist
- Commands:
  - /agent-stitch
  - $agent-stitch
- One-line value:
  The public entry point for Stitch-based design generation, prompt refinement, design-system capture, React handoff, and iterative Stitch delivery loops.
- Capabilities:
  - Stitch generation
  - design-to-code handoff
  - prompt enhancement
  - design-system capture
- How it works:
  - reads the design-generation task
  - chooses the smallest useful Stitch lanes
  - improves the prompt and workflow quality
  - returns a cleaner path from generation to handoff
- Best used when:
  - you are generating or editing screens in Stitch and want the workflow guided end to end
  - a weak prompt, stale DESIGN.md, or generic output is blocking design quality
  - you need a clean handoff from Stitch output into React or shadcn-based code
- Bottom summary:
  stitch-foundation, prompt-enhancement, design-system, react-handoff, taste-calibration
- Footer note:
  You ask for the outcome. Stitch tightens the loop.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
