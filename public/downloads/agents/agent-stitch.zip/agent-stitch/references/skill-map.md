# Skill Map

Use this file to route a request to the minimum useful subset of the internal
Stitch modes bundled inside `agent-stitch`.

## Foundation

- `stitch-foundation`: `modes/stitch-foundation/PLAYBOOK.md`, shared Stitch
  workflow rules, context gathering, asset hygiene, and state management

Always start with `stitch-foundation`.

## Prompt And Design-System Modes

- `prompt-enhancement`: `modes/prompt-enhancement/PLAYBOOK.md`, rewrite vague
  prompts into Stitch-ready structured prompts with stronger UI language
- `design-system`: `modes/design-system/PLAYBOOK.md`, create or refresh
  `.stitch/DESIGN.md` from project assets and metadata
- `taste-calibration`: `modes/taste-calibration/PLAYBOOK.md`, raise the visual
  quality bar and explicitly avoid generic AI design tells
- `accessibility-design`: `modes/accessibility-design/PLAYBOOK.md`, add
  accessibility-aware prompt guidance, inclusive interaction expectations, and
  handoff-ready accessibility constraints

Use when the problem is mostly about weak prompts, inconsistent output, or
missing design-system context.

## Generation Modes

- `generate-design`: `modes/generate-design/PLAYBOOK.md`, create new screens,
  variants, or first-pass Stitch outputs
- `edit-design`: `modes/edit-design/PLAYBOOK.md`, make targeted changes to an
  existing Stitch screen while preserving the current visual language

Use when the primary task is to create or modify Stitch screens.

## Handoff Modes

- `react-handoff`: `modes/react-handoff/PLAYBOOK.md`, convert Stitch output
  into modular React components and project-friendly assets
- `shadcn-integration`: `modes/shadcn-integration/PLAYBOOK.md`, integrate
  Stitch-driven UI work into a shadcn/ui codebase without fighting the stack

Use after generation when the result must land cleanly in application code.

## Delivery Modes

- `remotion-walkthrough`: `modes/remotion-walkthrough/PLAYBOOK.md`, turn Stitch
  screens into walkthrough video compositions
- `stitch-loop`: `modes/stitch-loop/PLAYBOOK.md`, run an iterative baton-based
  Stitch site-building loop with explicit next-step state
- `inference-media`: `modes/inference-media/PLAYBOOK.md`, generate or refine
  supporting images or media assets when the Stitch workflow benefits from
  external model-backed media generation

Use when the deliverable is a video artifact or a repeatable autonomous build
loop rather than a one-off screen.

## Recommended Bundles

- Design a new screen:
  `stitch-foundation`, then `prompt-enhancement`, `generate-design`; add
  `accessibility-design` when inclusion constraints matter
- Edit a screen safely:
  `stitch-foundation`, then `edit-design`; optionally `taste-calibration` or
  `accessibility-design`
- Make future generations consistent:
  `stitch-foundation`, then `design-system`, then `generate-design`
- Convert generated output to code:
  `stitch-foundation`, then `react-handoff`; add `shadcn-integration` when
  appropriate
- Accessibility-aware Stitch work:
  `stitch-foundation`, then `accessibility-design`; add `edit-design` or
  `react-handoff` depending on the workflow stage
- Create a polished walkthrough:
  `stitch-foundation`, then `remotion-walkthrough`
- Add generated supporting assets:
  `stitch-foundation`, then `inference-media`; often alongside
  `generate-design` or `remotion-walkthrough`
- Build iteratively with Stitch:
  `stitch-foundation`, then `stitch-loop`; often add `design-system`

## Anti-Pattern

Do not invoke every Stitch mode just because the upstream pack had many skills.
Pick the most likely primary mode, then add only the minimum supporting modes
needed to complete the workflow.
