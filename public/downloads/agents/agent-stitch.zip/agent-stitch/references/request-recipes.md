# Request Recipes

Use this file when the user describes a desired outcome instead of naming a
specific Stitch mode.

## Design Generation

- "Design this page in Stitch":
  start with `stitch-foundation`; usually add `prompt-enhancement`,
  `generate-design`
- "Create a few directions or variants":
  start with `stitch-foundation`; add `prompt-enhancement`,
  `generate-design`; optionally `taste-calibration`
- "Make this less generic":
  start with `stitch-foundation`; add `taste-calibration`; often add
  `prompt-enhancement`
- "Make this accessible":
  start with `stitch-foundation`; add `accessibility-design`; often add
  `edit-design`

## Design Editing

- "Edit this existing Stitch screen":
  start with `stitch-foundation`; add `edit-design`
- "Keep the design language but change this section":
  start with `stitch-foundation`; add `edit-design`; optionally
  `design-system`
- "Tighten this output without regenerating everything":
  start with `stitch-foundation`; add `edit-design`; optionally
  `taste-calibration`
- "Improve accessibility without changing the whole design":
  start with `stitch-foundation`; add `accessibility-design`; optionally
  `edit-design`

## Design-System Work

- "Create DESIGN.md":
  start with `stitch-foundation`; add `design-system`
- "Align future screens to this project":
  start with `stitch-foundation`; add `design-system`; then choose
  `generate-design` or `edit-design`
- "Analyze the current Stitch project style":
  start with `stitch-foundation`; add `design-system`

## Prompt Work

- "Improve this prompt for Stitch":
  start with `stitch-foundation`; add `prompt-enhancement`
- "Why are Stitch results weak?":
  start with `stitch-foundation`; add `prompt-enhancement`; optionally
  `design-system`

## Code Handoff

- "Turn this Stitch screen into React":
  start with `stitch-foundation`; add `react-handoff`
- "Use shadcn for this generated UI":
  start with `stitch-foundation`; add `shadcn-integration`; optionally
  `react-handoff`
- "Implement this design in my app":
  start with `stitch-foundation`; add `react-handoff`; add
  `shadcn-integration` only if the project already uses it
- "Add accessibility requirements before handoff":
  start with `stitch-foundation`; add `accessibility-design`; optionally
  `react-handoff`

## Delivery And Iteration

- "Create a walkthrough video from these screens":
  start with `stitch-foundation`; add `remotion-walkthrough`
- "Generate supporting visuals for this Stitch concept":
  start with `stitch-foundation`; add `inference-media`
- "Keep building this site page by page":
  start with `stitch-foundation`; add `stitch-loop`; often add `design-system`
- "Prepare the next Stitch iteration":
  start with `stitch-foundation`; add `stitch-loop`

## Guardrail

Do not map vague Stitch prompts to generation, editing, React handoff,
Remotion, and loop automation all at once. Pick the likely primary workflow,
then add only the supporting modes required to finish the task.
