# Stitch Guide

`agent-stitch` is the public Stitch generation and design-to-code workflow
specialist.

## What It Does

It guides Stitch-based design generation, prompt refinement, design-system
capture, React handoff, and iterative Stitch loops through one entry point.

It is best at:

- Stitch generation
- design-to-code handoff
- prompt enhancement
- design-system capture

## How To Use It

Call it with:

- `/agent-stitch`
- `$agent-stitch`

Use it when:

- you are generating or editing screens in Stitch and want the workflow guided
  end to end
- a weak prompt, stale `DESIGN.md`, or generic output is blocking design
  quality
- you need a clean handoff from Stitch output into React or shadcn-based code

## How It Works

It reads the design-generation problem, chooses the smallest useful Stitch
lanes, and keeps the workflow tight from prompt quality through handoff.

## Internal Playbooks

- `Stitch Foundation` (`stitch-foundation`): sets asset hygiene, context
  gathering, and workflow discipline for every Stitch task
- `Prompt Enhancement` (`prompt-enhancement`): transforms vague UI ideas into
  stronger Stitch-ready prompts
- `Design System` (`design-system`): refreshes or synthesizes the shared design
  language used across Stitch screens
- `React Handoff` (`react-handoff`): converts generated work into
  implementation-ready React structure and asset notes
- `Taste Calibration` (`taste-calibration`): pushes Stitch output away from
  generic layouts and toward a stronger bar

## Short Version

Use `/agent-stitch` or `$agent-stitch` when the design work lives in Stitch and
you want a cleaner loop from generation to handoff.
