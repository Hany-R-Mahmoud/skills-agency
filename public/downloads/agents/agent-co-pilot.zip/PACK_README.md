# Agent pack for agent-co-pilot

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-co-pilot`
- `agent-debugging`
- `agent-design`
- `agent-docs`
- `agent-fintech`
- `agent-implementer`
- `agent-product`
- `agent-reviewer`
- `agent-tester`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
