---
name: agent-co-pilot
description: Lightweight task orchestration entry point for small, obvious, or low-risk work. Trigger when the user explicitly invokes `$agent-co-pilot` anywhere in the prompt, or when they want a lightweight lead agent that stays fast and low-overhead while still allowing focused delegation.
---

# Agent Co-Pilot

## Scope
Use this skill as the lightest team entry point. It is for small tasks that may
benefit from minimal orchestration, but do not justify a full multi-phase
workflow.

## Invocation Contract
Use this skill immediately when the user explicitly includes `$agent-co-pilot`
anywhere in the prompt.

Treat the skill as an entry router. Decide whether the task should:
- stay mostly solo
- delegate one focused subtask
- delegate implementation, then run a quick review or verification pass

## Best Fit
- Small fixes or refinements
- Obvious implementation work in one narrow area
- Minor UI polish, bug fixes, docs tweaks, or isolated refactors
- Requests that need a little structure but should remain fast

## Avoid Using This Skill For
- Cross-cutting features with multiple dependencies
- Work that needs specification or architecture first
- Risky changes touching auth, persistence, migrations, or many modules

## Operating Rules
- Keep orchestration overhead low.
- Prefer one clear implementer over many teammates.
- If delegation is used, give the worker a tightly bounded file or concern
  scope.
- Escalate to `$agent-pilot` if the task turns out larger than expected or the
  risk profile increases.

## Shared Contract
Use the shared operating contract at
[`../agent-pilot/references/shared-team-contract.md`](../agent-pilot/references/shared-team-contract.md)
for artifact shape, ownership rules, and synthesis expectations.

For most `$agent-co-pilot` tasks, keep artifacts implicit unless they improve
clarity. If you need written artifacts, keep them to a very small version of
the shared contract:
- `summary`
- `owner`
- `file-scope`
- `next-step`

For context discipline, also use:
- [`../agent-pilot/references/context-efficiency-playbook.md`](../agent-pilot/references/context-efficiency-playbook.md)
- [`../agent-pilot/references/command-workflow-patterns.md`](../agent-pilot/references/command-workflow-patterns.md)

## Escalation Matrix
- Stay in `$agent-co-pilot` when:
  - one primary file area or one narrow concern is involved
  - implementation is obvious after a quick inspection
  - the risk of a wrong change is low
- Escalate to `$agent-pilot` when:
  - more than one meaningful implementation concern appears
  - review and testing become clearly necessary
  - more than one specialist would help
- De-escalate to solo execution when:
  - the task is a tiny one-shot fix and delegation adds no value

## Routing Rules
- For straightforward coding changes:
  use `agent-implementer`
- For quick validation after code changes:
  use `agent-tester`
- For a fast correctness pass on changed code:
  use `agent-reviewer`
- For bugs where root cause is still unclear:
  use `agent-debugging`
- For docs-only or explanation-heavy follow-up:
  use `agent-docs`

Use internal playbooks directly when they are the clearest fit:
- [`../frontend-react-and-next/PLAYBOOK.md`](../frontend-react-and-next/PLAYBOOK.md) for React, Next.js, or Ant Design specifics
- [`../backend-and-language-engineering/PLAYBOOK.md`](../backend-and-language-engineering/PLAYBOOK.md) for focused TS, JS, Python, NestJS, or CLI work
- [`../interface-and-design/PLAYBOOK.md`](../interface-and-design/PLAYBOOK.md) for quick UI direction or critique
- [`../openai-docs/PLAYBOOK.md`](../openai-docs/PLAYBOOK.md) for current OpenAI product guidance

## Default Flow
1. Inspect the touched area and infer whether the task is truly small.
2. Retrieve only the minimum code or docs context needed to decide the path.
3. Pick the smallest useful path:
   - solo
   - implement then verify
   - debug then implement
4. Delegate only the minimum useful work.
5. If the task crosses a meaningful boundary, write a short milestone summary.
6. Synthesize the outcome and call out any residual risk.

## Output
- Small-task summary
- Chosen path and why
- If delegated, the selected specialist or skill
- Residual risks or escalation recommendation
