---
name: team-lead
description: Standard team orchestration entry point for normal feature work. Trigger when the user explicitly invokes `$team-lead` anywhere in the prompt, or when they want a lead agent that plans, routes work to the right specialists, and ensures implementation is followed by review and verification.
---

# Team Lead

## Scope
Use this skill as the default team workflow for normal feature work. It owns
task framing, specialist routing, bounded delegation, and post-change quality
gates without introducing the heavier artifact discipline of the full mode.

## Invocation Contract
Use this skill immediately when the user explicitly includes `$team-lead`
anywhere in the prompt.

Treat it as the standard entry point when the task is meaningful enough to need
coordination, but not so risky that a full gated workflow is required.

## Best Fit
- Most feature work
- Multi-file changes with moderate risk
- Work that needs implementation plus review and testing
- Tasks that may benefit from one or two domain specialists in addition to core
  worker agents

## Avoid Using This Skill For
- Tiny edits that should stay close to solo mode
- Major migrations, high-risk security work, or vague cross-cutting initiatives
  that need stronger control

## Team Model
The lead should stay light on direct implementation and focus on routing,
monitoring, and synthesis. It may still perform small glue work when doing so is
faster and does not compromise the separation of concerns.

## Shared Contract
Use
[`references/shared-team-contract.md`](/Users/hanyramadan/.codex/skills/team-lead/references/shared-team-contract.md)
as the shared contract for:
- artifact shape
- file ownership
- specialist return format
- completion synthesis

When the task is substantial enough to benefit from written state, create a
small artifact set that follows the shared contract:
- `plan`
- `tasks`
- `review`
- `verification`

Keep them brief. They are coordination aids, not formal documents.

For context discipline and token efficiency, also use
[`references/context-efficiency-playbook.md`](/Users/hanyramadan/.codex/skills/team-lead/references/context-efficiency-playbook.md).

## Core Workflow
1. Inspect the request, nearby code, and repo conventions.
2. Use iterative retrieval to gather only the next most relevant context until
   the task shape is clear.
3. Decide whether the task is implementation-first, debugging-first,
   architecture-first, or research-first.
4. Route the main execution to the best specialist.
5. At phase boundaries, write short milestone summaries instead of carrying the
   full working history forward.
6. After implementation, require review and verification before considering the
   work complete.
7. Synthesize outcomes, open questions, and residual risk.

## Default Flow
- `agent-orchestrator` mindset for framing
- main execution through `agent-implementer`
- quality pass through `agent-reviewer`
- evidence pass through `agent-tester`

## Routing Rules
Use `agent-*` worker roles for ownership:
- `agent-implementer` for code changes
- `agent-reviewer` for correctness and regressions
- `agent-tester` for validation evidence
- `agent-debugging` when failure understanding comes before fixing
- `agent-security` for trust-boundary or auth-sensitive work
- `agent-docs` for documentation and explanation deliverables

Use internal playbooks whenever the task needs domain depth:
- [`frontend-react-and-next/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/frontend-react-and-next/PLAYBOOK.md) for React, Next.js, Cache Components, or Ant Design
- [`fullstack-engineering/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/fullstack-engineering/PLAYBOOK.md) for end-to-end feature delivery across UI, API, and persistence
- [`systems-architecture/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/systems-architecture/PLAYBOOK.md) for interface, schema, migration, or boundary design
- [`research-and-reasoning/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/research-and-reasoning/PLAYBOOK.md) for tradeoffs, pre-mortems, or evidence gathering
- [`backend-and-language-engineering/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/backend-and-language-engineering/PLAYBOOK.md) for focused application or CLI implementation
- [`mcp-development/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/mcp-development/PLAYBOOK.md) for MCP server, tool, schema, or protocol work
- [`interface-and-design/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/interface-and-design/PLAYBOOK.md) or `agent-impeccable` for UI or design-heavy tasks
- [`openai-docs/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/openai-docs/PLAYBOOK.md) for current official OpenAI guidance

## Escalation Rules
- Escalate to `$team-lead-full` when:
  - the task affects architecture, security, migrations, or multiple critical paths
  - the blast radius is unclear
  - the task needs formal artifacts or explicit approval gates
- De-escalate to `$team-lead-lite` when the task is truly small and isolated

## Routing Matrix
- Implementation-first:
  route to `agent-implementer`, then `agent-reviewer`, then `agent-tester`
- Debugging-first:
  route to `agent-debugging`, then `agent-implementer`, then `agent-tester`
- Architecture-first:
  route to `systems-architecture` or `research-and-reasoning`, then hand off to
  `agent-implementer`
- UI-first:
  route to `agent-impeccable`, `interface-and-design`, or
  `frontend-react-and-next`, then `agent-implementer` if code changes follow
- Security-sensitive:
  add `agent-security` before closure
- Documentation-heavy:
  add `agent-docs` before closure or handoff

## Output
- Goal and chosen workflow
- Specialists and domain skills selected
- Verification expectations
- Residual risks or escalation advice
