# Agent Config Security Scan

Use this reference when reviewing agent, automation, or assistant configuration
for security risks.

## Focus Areas
- prompt files and instruction documents
- tool permission lists and allowlists
- hooks and shell command templates
- MCP or external integration configuration
- dependency update workflows and release automation
- CI actions pinned by tag or commit SHA
- hardcoded credentials, tokens, or secrets
- unsafe bypass flags and dangerous defaults

## Common Findings

### Critical
- Hardcoded secrets in config or prompt files
- Unrestricted shell or tool permissions without clear need
- Command injection vectors in hooks or interpolated shell commands
- External integrations configured to run arbitrary code from untrusted sources

### High
- Missing deny lists or weak permission boundaries
- Auto-run instructions that expand prompt injection surface
- Agents with overly broad tool access relative to their role
- Dependency bump workflows with no provenance, age, or maintainer checks
- GitHub Actions updates that trust tags without verifying the pinned SHA

### Medium
- Silent error suppression that hides failures or abuse
- Risky auto-install behavior in tool or MCP setup
- Missing descriptions or unclear ownership around privileged integrations
- Review flows that cannot defer risky dependency updates for later follow-up

## Supply Chain Review Pattern

When a workflow updates dependencies or CI actions, review the supply chain
surface explicitly instead of treating it as routine maintenance.

Useful checks include:

- compare maintainers or publishers across the old and new versions
- note publish age and avoid blindly adopting very fresh releases
- check whether provenance, signatures, or attestations exist
- inspect tarball or package diffs for new runtime dependencies or suspicious
  code patterns
- defer questionable upgrades into an explicit follow-up bucket instead of
  auto-merging them

For GitHub Actions specifically:

- verify that a pinned commit SHA actually matches the claimed upstream tag
- treat a tag or SHA mismatch as a blocking integrity failure
- check whether the updated action changes required inputs, outputs, or runtime
  assumptions used by the workflow

## Review Guidance
- Treat configuration as executable policy, not inert metadata.
- Look for least-privilege violations first.
- Prefer environment-variable-based secret handling over literal values.
- Flag dangerous convenience features when they weaken trust boundaries.
- Recommend concrete remediation, not generic alarm.
