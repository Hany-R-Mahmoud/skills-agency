# Security Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for SECURITY inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Security and Platform department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: SECURITY
- Subtitle: Security-specific review and remediation specialist
- Commands:
  - /agent-security
  - $agent-security
- One-line value:
  Reviews work through a security lens when trust boundaries, secrets, permissions, auth, or sensitive data are involved.
- Capabilities:
  - AppSec review
  - auth and authorization
  - input validation
  - trust-boundary analysis
- How it works:
  - reads the trust boundary
  - chooses the smallest useful security lanes
  - identifies exposure and control gaps
  - returns actionable risk framing plus remediation guidance
- Best used when:
  - the task touches auth, permissions, secrets, public exposure, or sensitive data
  - you want a focused security review instead of a general code-quality pass
  - an agent, automation, or prompt configuration needs attack-surface judgment
- Bottom summary:
  security-engineering, systems-architecture, review-and-pr-operations, agent-config-security-scan
- Footer note:
  You ask for the outcome. Security checks the trust boundary.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
