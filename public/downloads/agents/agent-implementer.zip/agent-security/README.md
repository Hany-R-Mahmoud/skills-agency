# Security Guide

`agent-security` is the security-specific review and remediation specialist for
the system.

## What It Does

It reviews work through a security lens when trust boundaries, secrets,
permissions, auth, or sensitive data are involved.

It is best at:

- AppSec review
- auth and authorization
- input validation
- trust-boundary analysis

## How To Use It

Call it with:

- `/agent-security`
- `$agent-security`

Use it when:

- the task touches auth, permissions, secrets, public exposure, or sensitive
  data
- you want a focused security review instead of a general code-quality pass
- an agent, automation, or prompt configuration needs attack-surface judgment

## How It Works

It reads the trust boundary, chooses the smallest useful security lanes, and
returns actionable risk framing plus remediation guidance.

## Internal Playbooks

- `Security Engineering` (`security-engineering`): drives the threat model,
  remediation path, and least-privilege posture
- `Systems Architecture` (`systems-architecture`): helps evaluate
  security-sensitive boundaries and exposure paths
- `Review and PR Operations` (`review-and-pr-operations`): turns security
  issues into actionable findings with release-aware framing
- `Agent Config Security Scan` (`agent-config-security-scan`): examines
  prompts, tool permissions, and automation config as real attack surface

## Short Version

Use `/agent-security` or `$agent-security` when the problem touches trust,
exposure, secrets, or sensitive behavior.
