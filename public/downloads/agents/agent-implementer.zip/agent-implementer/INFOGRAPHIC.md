# Implementer Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for IMPLEMENTER inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Engineering and Systems department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: IMPLEMENTER
- Subtitle: Implementation owner for approved changes
- Commands:
  - /agent-implementer
  - $agent-implementer
- One-line value:
  The primary code-writing agent. Converts approved work into production code while loading the right internal engineering playbooks behind the scenes.
- Capabilities:
  - feature implementation
  - refactoring
  - frontend-first delivery
  - full-stack changes
- How it works:
  - reads the approved direction
  - chooses the smallest useful implementation lanes
  - makes the code changes
  - keeps the result ready for review and verification
- Best used when:
  - the implementation path is already clear enough to start editing
  - a plan exists and now someone needs to ship the code
  - the task spans frontend and backend together
- Bottom summary:
  frontend-react-and-next, backend-and-language-engineering, fullstack-engineering, interface-and-design, testing-and-verification
- Footer note:
  You ask for the outcome. Implementer ships the change.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
