# Language Workflow Family Map

Use this reference to borrow the family pattern from command sets like
`<lang>-build`, `<lang>-review`, and `<lang>-test` without importing each
command separately.

## Pattern

- use language-aware build validation when compile/runtime setup matters
- use language-aware review heuristics when idioms differ materially
- coordinate with `agent-tester` for the narrowest useful language-specific
  test path

## Guardrail

Do not create a new public implementer for every language. Keep one execution
agent and pull this family pattern when it materially improves the work.
