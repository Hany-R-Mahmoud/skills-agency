# Task Execution Contract

Use this reference when implementing a task that came from a larger approved
plan.

## Before Coding
- Read the task text and local context carefully.
- Read the task literally before expanding it into a bigger interpretation.
- Ask questions before coding if requirements, acceptance criteria, boundaries,
  or dependencies are unclear.
- Confirm assumptions early instead of hiding them in the implementation.
- Find the minimum surface area that can satisfy the task safely.

## While Coding
- Implement exactly what was requested.
- Prefer the smallest coherent diff that solves the problem.
- Follow the planned file structure when one exists.
- Keep files focused. If the task starts to demand broader restructuring, stop
  and raise the concern instead of inventing a larger architecture.
- Treat "while I'm here" improvements as follow-ups, not stealth scope
  expansion.
- Test the work proportionally to the risk and task type.
- Avoid premature abstraction. A few repeated lines are often lower-risk than a
  new helper or configuration surface.

## Self-Review
- Check completeness against the requested task.
- Check for overbuilding or unrequested extras.
- Walk the diff line by line and ask whether each added line is required by the
  task.
- Check naming, maintainability, and local pattern fit.
- Check that tests exercise behavior rather than merely mirroring the code.
- List meaningful follow-ups that were noticed but intentionally not done.

## Status Meanings
- `DONE`: implementation is complete and review-ready.
- `DONE_WITH_CONCERNS`: implementation is complete, but important concerns
  should be evaluated before trusting it.
- `NEEDS_CONTEXT`: missing information prevented safe completion.
- `BLOCKED`: the task needs a different breakdown, more context, or a different
  approach.

## Scope Self-Check

Use this quick check when the task looks like it could balloon:

- task as stated
- files touched and why each one is required
- tempting follow-ups intentionally excluded
- abstractions considered and rejected
- whether the diff could still be smaller
