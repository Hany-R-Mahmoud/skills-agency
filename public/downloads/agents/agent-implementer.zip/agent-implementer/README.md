# Implementer Guide

`agent-implementer` is the implementation owner for approved changes.

## What It Does

It is the primary code-writing agent and turns approved work into production
code while loading the right engineering playbooks behind the scenes.

It is best at:

- feature implementation
- refactoring
- frontend-first delivery
- full-stack changes

## How To Use It

Call it with:

- `/agent-implementer`
- `$agent-implementer`

Use it when:

- the implementation path is already clear enough to start editing
- a plan exists and now someone needs to ship the actual code
- the task is UI-heavy, interaction-heavy, or spans frontend and backend

## How It Works

It reads the approved direction, chooses the smallest useful implementation
lanes, makes the code changes, and keeps the result ready for review and
verification.

## Internal Playbooks

- `Frontend React and Next` (`frontend-react-and-next`): keeps React, Next.js,
  and Ant Design work aligned with local implementation patterns
- `Backend and Language Engineering` (`backend-and-language-engineering`):
  supports TS, JS, Python, and CLI changes when the work crosses layers
- `Fullstack Engineering` (`fullstack-engineering`): coordinates data flow,
  persistence, and UI behavior as one coherent delivery surface
- `Interface and Design` (`interface-and-design`): helps implementation
  preserve polish, readability, and product feel while coding
- `Testing and Verification` (`testing-and-verification`): builds the change in
  a way that review and validation can assess cleanly

## Short Version

Use `/agent-implementer` or `$agent-implementer` when the plan is set and the
main need is clean execution.
