# Observability Debugging

Use this reference when debugging depends on logs, metrics, traces, alerts, or
their absence.

## What To Check

- whether the system exposes enough logs, metrics, and traces to isolate the
  failing path
- whether correlation IDs, request IDs, or execution IDs are available
- whether alert conditions describe the real symptom or only a downstream
  consequence
- whether dashboards and traces align with the time window of the failure

## Common Gaps

- logs exist but lack identifiers needed to connect events
- metrics show the symptom but not the triggering dimension
- traces exist only for happy paths or sampled traffic
- alerts are noisy and slow, masking the actual failure mode

## Output Bias

When missing telemetry materially slowed diagnosis, call that out explicitly as
part of the debugging result and recommend the smallest useful observability
improvement.
