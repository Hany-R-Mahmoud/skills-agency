# Debugger Guide

`agent-debugging` is the reproduce-first debugging and root-cause analysis
specialist.

## What It Does

It investigates regressions, runtime errors, flaky behavior, and telemetry gaps
by separating symptom from actual cause before a fix is attempted.

It is best at:

- root-cause analysis
- reproduction
- observability review
- failure triage

## How To Use It

Call it with:

- `/agent-debugging`
- `$agent-debugging`

Use it when:

- something is broken and the real cause is not yet understood
- logs, traces, reproduction steps, or missing telemetry matter to the
  diagnosis
- you need evidence before implementing a fix safely

## How It Works

It reads the failure, chooses the smallest useful debugging lanes, reproduces
the issue when possible, and returns a safer path to the real fix.

## Internal Playbooks

- `Debugging and Diagnostics` (`debugging-and-diagnostics`): provides the
  reproduce-first method and hypothesis-testing discipline
- `Testing and Verification` (`testing-and-verification`): turns discoveries
  into regression guards and reproducible checks
- `Research and Reasoning` (`research-and-reasoning`): improves evidence
  gathering when the relevant path is still unclear
- `Observability Debugging` (`observability-debugging`): covers telemetry gaps
  that slow diagnosis and how to close them

## Short Version

Use `/agent-debugging` or `$agent-debugging` when you need the cause, not just
another guess.
