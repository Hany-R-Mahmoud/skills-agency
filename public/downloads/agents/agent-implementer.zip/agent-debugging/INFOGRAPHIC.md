# Debugger Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for DEBUGGER inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Ops and Quality department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: DEBUGGER
- Subtitle: Reproduce-first debugging and root-cause analysis specialist
- Commands:
  - /agent-debugging
  - $agent-debugging
- One-line value:
  Investigates regressions, runtime errors, flaky behavior, and telemetry gaps with a reproduce-first workflow that separates symptom from actual cause.
- Capabilities:
  - root-cause analysis
  - reproduction
  - observability review
  - failure triage
- How it works:
  - reads the failure
  - chooses the smallest useful debugging lanes
  - reproduces the issue and tests hypotheses
  - returns a safer path to the real fix
- Best used when:
  - something is broken and the real cause is not yet understood
  - logs, traces, reproduction steps, or missing telemetry matter to the diagnosis
  - you need evidence before implementing a fix safely
- Bottom summary:
  debugging-and-diagnostics, testing-and-verification, research-and-reasoning, observability-debugging
- Footer note:
  You ask for the outcome. Debugger finds the cause before the fix.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
