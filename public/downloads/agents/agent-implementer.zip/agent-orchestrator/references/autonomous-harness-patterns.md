# Autonomous Harness Patterns

Use this reference when designing persistent or scheduled agent workflows.

## Purpose
Support recurring, semi-autonomous operation without importing a monolithic
agent framework.

## Useful Patterns

### Scheduling
- Use recurring triggers only when the task benefits from periodic execution.
- Make the schedule part of the design: what runs, how often, and what success
  looks like.
- Design prompts or task definitions to include error handling and completion
  checks for unattended runs.

### Memory layering
- Separate in-session task state from cross-session memory.
- Keep long-term memory concise and structured enough to be useful later.
- Prefer summaries, state snapshots, or stable facts over raw logs.

### Persistent task queues
- Represent recurring or deferred work explicitly.
- Track active, blocked, and completed work in a way that survives sessions.
- Do not assume unattended runs share interactive context unless memory bridges
  them deliberately.

### Operator control
- Include pause, stop, and override semantics in the workflow design.
- Make it obvious how a human can inspect, interrupt, or redirect the system.
- Treat autonomous operation as supervised automation, not absolute independence.

## Constraints To Respect
- Scheduled runs may execute in isolated contexts.
- Permissions for browser or computer-use actions should never be assumed.
- Rate limits, flaky integrations, and partial failure need explicit handling.
- Long-running memory stores must be pruned or summarized to stay useful.
