# Plan Shim

Use this reference when the user needs a fast, execution-ready plan before any
implementation begins.

## Output Shape

- objective
- constraints
- problem statement
- goals and non-goals
- ordered phases
- dependencies
- decision points
- validation checkpoints
- launch or rollback considerations when relevant

## Product Framing Variant

When the task is closer to product or delivery framing than implementation
planning, prefer a compact shape:

- problem statement
- user or business goal
- non-goals
- options considered
- recommended path
- now / next / later follow-up framing if sequencing matters

## Rules

- planning only; do not start coding inside the plan step
- break work into phases that another agent can execute without guessing
- stop after the plan unless execution was explicitly requested

## Read-Only Orientation Variant

When the real need is onboarding or codebase orientation before planning,
prefer a fact-only shape:

- what was inspected
- key entry points
- main code paths
- important boundaries
- what remains uninspected

Do not mix orientation with redesign advice or speculative implementation
recommendations.
