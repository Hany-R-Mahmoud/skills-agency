# Iterative Retrieval

Use this reference when the relevant context is unclear and a single search pass
is likely to miss important files or repository terminology.

## Purpose
Improve context gathering by progressively refining retrieval instead of trying
to guess the right file set in one pass.

## Retrieval Loop
1. Start broad with likely paths, concepts, and obvious keywords.
2. Evaluate the returned files for relevance, terminology, and missing context.
3. Refine the search using:
   - terms discovered in the codebase
   - nearby abstractions and patterns
   - exclusions for clearly irrelevant files
4. Repeat for a small number of cycles.
5. Stop when the context is good enough to proceed safely.

## Good Signals
- A few files directly implement or govern the requested behavior.
- Repository-specific terminology becomes clear.
- Important gaps are shrinking instead of expanding.
- The next step can be assigned without guessing.

## Stop Conditions
- Enough high-relevance files are found to support planning or handoff.
- Additional search rounds mostly return duplicates or weakly related files.
- The remaining uncertainty is better handled by asking for clarification.

## Practical Guidance
- Start broad, then narrow. Do not over-specify the first query.
- Learn the repository's own terms instead of forcing outside vocabulary.
- Track missing context explicitly so refinements are intentional.
- Exclude dead ends once they are clearly irrelevant.
- Prefer a few high-value files over a long noisy list.
