# Autonomy Patterns

Use this reference when designing long-running or semi-autonomous workflows that
must keep momentum without losing verification or operator control.

## Purpose
Add structure to autonomous execution without importing a full product-specific
runtime or unsafe "never ask questions" behavior.

## Useful Patterns

### Explicit execution loop
- Use a named loop such as:
  - reason
  - act
  - reflect
  - verify
- Require each cycle to produce evidence, not just progress claims.
- Make failure handling explicit: retry with a changed approach, simplify, or
  escalate.

### Phase-based execution
- Break long workflows into named phases with clear exit conditions.
- Do not advance phases just because work was attempted; require quality gates
  or completion criteria.
- Keep the current phase and next transition legible to the controller.

### Checkpointing
- Capture progress in explicit milestones so work can resume safely.
- Prefer small coherent checkpoints over giant all-or-nothing runs.
- Treat rollback and resume paths as part of orchestration design.

### Safety defaults
- Define an explicit stop condition before starting a long-running loop.
- Check repo state, branch strategy, and required prerequisites before the
  first autonomous cycle.
- Let autonomy run in named modes such as `safe` and `fast`, where the
  difference is gate strictness rather than whether judgment is allowed.
- Require verification checkpoints at phase boundaries instead of deferring all
  validation to the end.
- If an automated approval or continuation helper is involved, require a
  fail-closed contract:
  - invalid output means pause
  - timeout means pause
  - execution error means pause
  - uncertain judgment means pause
- Distinguish between blocking preflight gates and non-blocking follow-up
  hooks:
  - preflight gates may abort the next phase when correctness depends on them
  - follow-up hooks should usually log and continue unless the workflow
    explicitly marks them as critical
- When a boundary check decides to block, stop cleanly and preserve the next
  step:
  - record the reason
  - capture the minimum useful handoff or checkpoint
  - avoid silently retrying past the same boundary
- Prefer boundary blocks that preserve operator control over ones that bury the
  warning inside normal progress output.

### Human intervention model
- Allow pause, stop, and clarification points.
- Keep collaboration possible even in highly autonomous modes.
- Never adopt blanket rules like "do not ask questions" without considering
  risk, ambiguity, and user intent.

## What To Borrow Carefully
- Structured loops
- Phase transitions
- Explicit checkpoints
- Observable status updates

## What Not To Copy
- Product-specific filesystem state machines
- Unconditional autonomy rules that suppress judgment
- Monolithic runtimes when a playbook or reference is enough
