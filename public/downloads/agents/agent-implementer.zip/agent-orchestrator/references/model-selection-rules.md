# Model Selection Rules

Use this reference when choosing how much reasoning power a task needs.

## Core Principle
Match model capability to task complexity. Do not spend top-tier reasoning on
 mechanical work, and do not underpower architecture or review tasks.

## Suggested Tiers

### Fast tier
Use for:
- focused edits in 1-2 files
- simple documentation changes
- basic lint or test fixes
- straightforward mechanical transformations

### Standard tier
Use for:
- multi-file feature work
- integration tasks with moderate ambiguity
- debugging with several plausible causes
- non-trivial review passes

### High tier
Use for:
- architecture and planning
- security-sensitive judgment
- deep debugging with uncertain scope
- review tasks that need broad codebase understanding
- work where a wrong call is expensive

## Selection Signals
- Small, fully specified, low coupling task: lower tier
- Ambiguous task with integration boundaries: standard tier
- High judgment, architecture, or risk: high tier

## Operational Advice
- Upgrade the tier when a task repeatedly comes back blocked for reasoning, not
  just missing context.
- Downgrade the tier for repetitive or deterministic subtasks.
- Keep model choice explicit in long workflows so cost and latency are a design
  choice, not an accident.
