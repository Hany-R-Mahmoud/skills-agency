# Codebase Orientation Pattern

Use this reference when the task is to help someone understand an unfamiliar
codebase quickly without drifting into redesign or implementation advice.

## Output Shape

- one-line summary of what the codebase is
- five-minute explanation of tasks, inputs, outputs, and key files
- deeper walkthrough of entry points, boundaries, and concrete code paths
- explicit list of what was inspected and what was not

## Rules

- state only facts grounded in inspected code
- quote file paths, entry points, routes, commands, or config keys exactly when
  they matter
- distinguish observed behavior from missing or uninspected areas
- optimize for reducing search cost for the next engineer

## Anti-Pattern

Do not smuggle review findings, refactor plans, or architecture proposals into
an onboarding-oriented walkthrough.
