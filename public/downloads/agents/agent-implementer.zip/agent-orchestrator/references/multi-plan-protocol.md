# Multi-Plan Protocol

Use this reference when the work is large enough to require phased planning
rather than one flattened implementation plan.

## Pattern

- decompose into bounded phases
- define stop-loss boundaries between phases
- verify each phase before entering the next
- keep later phases flexible when earlier evidence may change the route

## Prototype Variant

For rapid prototype or idea-validation work, phase around learning rather than
completeness:

- define the core hypothesis
- identify the minimum feature set needed to test it
- decide what evidence will count as validation
- stop before polishing work that does not change the learning outcome

## Experiment Variant

For experiment-driven work, phase around decision quality:

- define the hypothesis
- choose the success metric and guardrails
- note major risks or ethics constraints
- define how results will be interpreted
- state what decision changes if the experiment succeeds or fails

## Guardrails

- do not over-specify distant phases when near-term uncertainty is high
- do not let planning quietly turn into execution
