# NotebookLM Planning

Use this reference when pre-implementation planning should be grounded in a
trusted internal document corpus.

## Best Fit

- RFC-heavy projects
- internal API or platform documentation
- product specs and decision records
- runbooks and operational guidance that affect planning

## Planning Bias

- extract constraints before proposing the plan
- separate corpus-grounded facts from inferred decisions
- call out missing or contradictory source material early
