# Model Routing Heuristic

Use this lightweight heuristic when the task calls for explicit model-tier
selection or effort framing.

## Heuristic

- **low budget / mechanical work**:
  choose the lightest reliable path
- **default implementation and refactors**:
  choose the balanced path
- **architecture, ambiguity, or deep review**:
  choose the heaviest reasoning path

## Output Shape

- recommended tier
- confidence
- why it fits
- fallback if the first pass is insufficient
