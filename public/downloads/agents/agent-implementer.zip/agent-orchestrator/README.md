# Orchestrator Guide

`agent-orchestrator` is the planning and routing brain of the system.

## What It Does

It turns new or ambiguous work into execution-ready plans and decides which
public agents and internal playbooks should be involved.

It is best at:

- workflow planning
- task decomposition
- routing strategy
- context handoff

## How To Use It

Call it with:

- `/agent-orchestrator`
- `$agent-orchestrator`

Use it when:

- the task is new, ambiguous, or likely to affect architecture
- you want a concrete plan before anyone starts editing code
- multiple specialist agents may be needed and their order matters

## How It Works

It inspects the request, separates facts from assumptions, builds an ordered
plan, names the risky decisions, and routes the next step cleanly.

## Internal Playbooks

- `Coordination Playbook` (`coordination-playbook`): provides the framing
  discipline for turning a request into an execution-ready plan
- `Systems Architecture` (`systems-architecture`): helps identify
  boundary-sensitive decisions before implementation begins
- `Research and Reasoning` (`research-and-reasoning`): improves discovery
  quality when the first answer is not yet trustworthy
- `Plan Execution Mode` (`plan-execution`): converts approved plans into
  staged, dependency-aware workstreams
- `Quality Gate Patterns` (`quality-gate-patterns`): names the risky
  checkpoints so they are handled intentionally

## Short Version

Use `/agent-orchestrator` or `$agent-orchestrator` when you need a solid plan
before you need code.
