---
name: skill-system-architecture
description: Plan skill, plugin, hook, command, and agent packaging decisions with strong bias toward consolidation, internal modes, and low public-surface-area design.
path: skills/agent-orchestrator/modes/skill-system-architecture/PLAYBOOK.md
tags:
  - skills
  - plugins
  - packaging
  - orchestration
  - curation
---

# Skill System Architecture

## Scope
Use this internal mode when the task is about creating, evaluating,
consolidating, or improving skills, plugins, commands, hooks, agents, or
related capability packaging.

## Objectives
- Keep the public skill picker small and legible.
- Prefer strengthening existing public entry points over creating new ones.
- Add private modes, playbooks, references, or scripts when capability can be
  absorbed without increasing user-facing complexity.
- Create a new public skill only when the user-facing workflow, trigger shape,
  and mental model are clearly distinct.

## Decision Rules
- Start by locating the closest existing public skill that already owns the
  user's intent.
- If the new capability is mostly planning, routing, packaging, or evaluation,
  prefer `agent-orchestrator`.
- If the new capability is a specialized execution path inside an existing
  public skill, add an internal mode/playbook instead of a new public skill.
- If the capability mainly adds domain knowledge, add references or scripts
  before expanding the public surface area.
- Recommend a new public skill only when all of the following are true:
  - the workflow is recurring and materially distinct
  - existing public skills would become vague or overloaded by absorbing it
  - the trigger phrases are clear and non-overlapping
  - the new entry improves discoverability more than it harms menu simplicity

## Evaluation Lens
- Public entry fit: Does an existing public skill already cover the intent?
- Packaging boundary: Should this be a playbook, mode, reference, script, or
  new skill?
- Trigger quality: Are the user phrases specific enough to route reliably?
- Maintenance cost: Will this duplicate guidance that already exists?
- Dependency fit: Does it assume tools, frameworks, or environments not present
  in the current system?

## Repository Analysis Workflow
- Review the target repository's structure, README, manifests, and core source
  files.
- Skip minified, generated, vendored, or bundled assets unless they are the
  only available implementation evidence.
- Separate what the repository actually implements from what its README markets.
- Compare the repository against current local public skills, internal
  playbooks, and packaging patterns.
- Decide whether the best outcome is:
  - enhancement of an existing public skill
  - addition of an internal mode/playbook/reference/script
  - creation of a new public skill
  - rejection as not suitable

## Required Output Template
- Recommendation: `New Skill`, `Enhancement`, or `Not Suitable`
- Proposed Skill Name
- Integration Complexity: `Low`, `Medium`, or `High`
- Key Required Modifications
- Compatibility Notes
- Direct, actionable next step

## Packaging Recommendations
- Prefer language like "integrate into `agent-orchestrator` as an internal
  mode" over "create another orchestrator" when the job is still routing and
  planning.
- Prefer language like "add a reference pack under the existing skill" when the
  main addition is knowledge, examples, or templates.
- Prefer language like "add a script" when reliability or repeated code
  generation is the real problem.

## Anti-Patterns
- Do not create a new public skill just because a repository is interesting.
- Do not mirror an upstream plugin taxonomy one-to-one if local packaging uses a
  consolidated public surface.
- Do not treat README claims as implementation evidence.
- Do not add overlapping public skills with fuzzy routing boundaries.
