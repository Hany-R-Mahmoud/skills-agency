---
name: plan-execution
description: Execute an existing implementation plan task by task with explicit implementer status handling and two-stage review gates for spec compliance and code quality.
path: skills/agent-orchestrator/modes/plan-execution/PLAYBOOK.md
tags:
  - execution
  - plans
  - orchestration
  - review
  - handoff
---

# Plan Execution

## Scope
Use this internal mode when a plan already exists and the main job is to
execute it cleanly, task by task, without losing review discipline.

## When To Use
- The implementation plan is already written and approved.
- Tasks are independent enough to execute sequentially without broad replanning.
- The controller should stay focused on coordination, status tracking, and
  review gates rather than doing all coding inline.

## Do Not Use
- When the plan is still ambiguous or likely wrong.
- When tasks are tightly coupled and need live architectural decisions.
- When the work is so small that overhead would exceed value.

## Execution Loop
1. Read the plan once and extract all tasks with enough local context to route
   work cleanly.
2. Track the tasks explicitly so progress and blockers stay visible.
3. For each task, dispatch implementation with:
   - full task text
   - relevant context and dependencies
   - boundaries on what not to change
4. Handle implementer status exactly:
   - `DONE`: continue to review
   - `DONE_WITH_CONCERNS`: read and judge concerns before review
   - `NEEDS_CONTEXT`: provide missing context, then re-dispatch
   - `BLOCKED`: change something before retrying: context, decomposition, or
     approach
5. Run staged review after implementation:
   - first: spec compliance
   - second: code quality
6. Do not mark the task complete until required issues are addressed or an
   explicit decision is made to carry risk forward.
7. After all tasks, run a final holistic review when the change set is large
   enough to justify it.

## Implementer Contract
- Expect the implementer to ask questions before coding when requirements or
  constraints are unclear.
- Expect the implementer to self-review before reporting back.
- Expect the implementer to flag when the task is stretching beyond its planned
  file boundaries or responsibility.
- Do not force repeated retries without changing context or decomposition.

## Review Gates

### Gate 1: Spec Compliance
- Verify the implementation matches the plan or task text.
- Look for both missing requirements and unrequested additions.
- Do not trust the implementation summary alone; inspect the actual change.

### Gate 2: Code Quality
- Review cleanliness, maintainability, decomposition, and test quality.
- Check whether the change introduced hidden coupling, oversized units, or
  weak boundaries.
- Use severity-based findings and send fixes back through implementation.

## Controller Bias
- Prefer explicit task context over making the implementer rediscover the whole
  plan from scratch.
- Keep the implementer focused on one coherent task at a time.
- Preserve momentum, but do not skip review gates for speed.
- Prefer sequential task execution unless the write scopes are truly disjoint
  and safe.

## Output
- Current task and status
- Blockers or missing context
- Review findings and required follow-ups
- Completion state across the whole plan
