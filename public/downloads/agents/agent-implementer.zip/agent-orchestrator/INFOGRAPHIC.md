# Orchestrator Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for ORCHESTRATOR inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Command Center department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: ORCHESTRATOR
- Subtitle: Planning, decomposition, sequencing, and specialist routing
- Commands:
  - /agent-orchestrator
  - $agent-orchestrator
- One-line value:
  The routing brain of the system. Turns new or ambiguous tasks into execution-ready plans and decides which public agents and internal playbooks should be involved.
- Capabilities:
  - workflow planning
  - task decomposition
  - routing strategy
  - context handoff
- How it works:
  - reads the request
  - separates facts, assumptions, and decisions
  - routes through the smallest useful planning playbooks
  - returns an ordered execution path
- Best used when:
  - the task is new, ambiguous, or likely to affect architecture
  - you want a concrete plan before editing code
  - multiple specialist agents may be needed and their order matters
- Bottom summary:
  coordination-playbook, systems-architecture, research-and-reasoning, plan-execution, quality-gate-patterns
- Footer note:
  You ask for the outcome. Orchestrator maps the path.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
