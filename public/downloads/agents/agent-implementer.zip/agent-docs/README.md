# Docs Guide

`agent-docs` is the documentation and explanation specialist for code changes
and system behavior.

## What It Does

It writes and updates developer-facing documentation, JSDoc, README sections,
PR summaries, and usage guidance grounded in the actual implementation.

It is best at:

- technical documentation
- change summaries
- README and JSDoc updates
- knowledge transfer

## How To Use It

Call it with:

- `/agent-docs`
- `$agent-docs`

Use it when:

- a code change needs clearer docs, explanation, or onboarding support
- a PR or implementation needs a concise technical summary other humans can
  trust
- you want repo language and docs to stay aligned with the implementation

## How It Works

It reads the changed or target behavior, chooses the smallest useful doc lanes,
and writes durable documentation that matches reality.

## Internal Playbooks

- `Documentation and Doc Ops` (`documentation-and-doc-ops`): provides the core
  writing discipline for docs that stay maintainable over time
- `Doc` (`doc`): supports exactness, formatting, and fidelity when editing
  technical documents
- `Research and Reasoning` (`research-and-reasoning`): helps validate facts
  before they become part of durable documentation
- `Document Files` (`document-files`): covers structured doc workflows when
  files and artifacts need stronger handling

## Short Version

Use `/agent-docs` or `$agent-docs` when the code is done but the explanation
still needs to catch up.
