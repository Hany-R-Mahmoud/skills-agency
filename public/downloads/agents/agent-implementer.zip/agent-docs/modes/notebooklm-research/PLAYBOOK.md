---
name: notebooklm-research
description: Ground documentation work in a trusted NotebookLM notebook or document corpus before drafting summaries, explanations, or reference material.
---

Use this mode when the quality of the documentation depends on source-grounded
answers from an existing document collection rather than ad hoc recall.

## Best Fit

- internal docs and runbooks
- API references and design docs
- PRDs, RFCs, and onboarding corpora
- any writing task where citation-backed confidence matters

## Workflow

1. Identify the target notebook or corpus.
2. Ask focused, retrieval-friendly questions instead of broad open-ended ones.
3. Pull out the relevant grounded facts before writing prose.
4. Write the documentation in local repo language rather than copying source
   phrasing.
5. Call out any gaps where the notebook corpus was incomplete or ambiguous.

## Guardrails

- do not treat NotebookLM output as infallible; resolve contradictions
- do not paste large source excerpts when a concise synthesis is stronger
- do not use this mode when no trusted corpus exists and ordinary docs work is
  sufficient
