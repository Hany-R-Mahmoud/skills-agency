# Docs Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for DOCS inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Research and Continuity department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: DOCS
- Subtitle: Documentation and explanation specialist for code changes and system behavior
- Commands:
  - /agent-docs
  - $agent-docs
- One-line value:
  Writes and updates developer-facing documentation, JSDoc, README sections, PR summaries, and usage guidance grounded in the actual implementation.
- Capabilities:
  - technical documentation
  - change summaries
  - README and JSDoc updates
  - knowledge transfer
- How it works:
  - reads the changed or target behavior
  - chooses the smallest useful doc lanes
  - keeps wording aligned with implementation reality
  - returns durable documentation
- Best used when:
  - a code change needs clearer docs, explanation, or onboarding support
  - a PR or implementation needs a concise technical summary other humans can trust
  - you want repo language and docs to stay aligned with the implementation
- Bottom summary:
  documentation-and-doc-ops, doc, research-and-reasoning, document-files
- Footer note:
  You ask for the outcome. Docs makes the knowledge durable.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
