# Live Docs First

Use this reference when answering documentation-heavy questions that depend on
current library or platform behavior.

## Pattern

- understand before writing; do not document what has not been verified
- identify the audience and their entry point before drafting structure
- outline the document shape before filling in prose
- ask for the exact library, version, or surface when it matters
- prefer live primary docs over stale memory
- test examples and commands when practical
- keep a review and maintenance mindset, not a one-shot publishing mindset
- keep the final answer minimal and actionable
- state uncertainty explicitly when docs are incomplete or ambiguous
