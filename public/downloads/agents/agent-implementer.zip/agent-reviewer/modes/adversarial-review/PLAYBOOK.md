---
name: adversarial-review
description: Challenge whether the chosen implementation, design, and tradeoffs should ship, not just whether the code has obvious defects.
path: skills/agent-reviewer/modes/adversarial-review/PLAYBOOK.md
tags:
  - review
  - adversarial
  - challenge
  - design
  - regression
---

# Adversarial Review

## Scope
Use this internal mode when the right question is not "does the code work?" but
"should this approach ship, and what assumptions would have to hold for that to
be safe?"

## Instructions
- Keep the role review-only. Do not fix code, propose that you are about to fix
  code, or blur the line between reviewer and implementer.
- Challenge the chosen approach, design tradeoffs, and hidden assumptions.
- Look beyond obvious defects:
  - happy-path bias
  - empty and degraded states
  - retries and duplicate actions
  - stale or partially updated state
  - rollback and recovery behavior
  - second-order failures at boundaries and integrations
- Distinguish two kinds of problems:
  - implementation defect: the approach is reasonable, but the code is wrong
  - design risk: the approach itself is brittle, incomplete, or expensive to
    trust
- Ground every challenge in repository evidence, surrounding code patterns, or
  validation signals gathered during the review.
- If the implementation still looks sound after pressure-testing, say so
  plainly instead of forcing a finding.

## Output
- `No confirmed findings` when the challenged approach still looks acceptable
- Otherwise: high-signal findings with file references and a clear label for
  whether each issue is a design risk or an implementation defect
