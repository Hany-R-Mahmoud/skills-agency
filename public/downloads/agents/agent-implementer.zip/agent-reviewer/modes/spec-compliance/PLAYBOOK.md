---
name: spec-compliance
description: Verify that an implementation matches its requested scope exactly, checking for missing requirements, extra work, and requirement misunderstandings before broader quality review.
path: skills/agent-reviewer/modes/spec-compliance/PLAYBOOK.md
tags:
  - review
  - spec
  - compliance
  - scope
  - requirements
---

# Spec Compliance

## Scope
Use this internal mode when the main question is whether the implementation
matches the requested task or plan.

## Instructions
- Compare the requested work against the actual changed code.
- Do not trust the implementer's summary without inspection.
- Look for:
  - missing requirements
  - unrequested additions
  - requirement misunderstandings
  - false claims of completeness
- Prefer concrete file references when calling out gaps.
- If the implementation is spec compliant, say so plainly.

## Output
- `Spec compliant` when the implementation matches the request after inspection
- Otherwise: specific missing or extra items with file references
