# Code Quality Gate

Use this reference after spec compliance passes.

## Focus
- Maintainability
- Clarity of decomposition
- Test quality
- Hidden coupling
- Oversized files or units introduced by the change
- Boundary fit with the surrounding codebase

## Checks
- Does each touched or newly created file have one clear responsibility?
- Are interfaces and decomposition understandable without excessive mental load?
- Did the change follow the planned structure when one existed?
- Did the implementation introduce unnecessary complexity or overbuilding?
- Are tests meaningful for behavior and failure paths?
- Did this change significantly worsen file size or tangling in a way that
  should be called out?

## Reporting
- Keep strengths brief.
- Prioritize issues by severity.
- Distinguish correctness issues from maintainability issues.
