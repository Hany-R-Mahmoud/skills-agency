# Review Report Structure

Use this reference when the review should be reported with more structure and
repeatability.

## Preferred Sections

- overview of scope reviewed
- findings grouped by severity
- each finding anchored to file and line when possible
- validation gaps or missing evidence
- residual risk

## Severity Labels

- `Blocker`: must-fix issue that makes the change unsafe or incorrect
- `Suggestion`: should-fix issue with meaningful quality, safety, or
  maintainability impact
- `Nit`: optional improvement that should not distract from higher-signal review

Use the lightest label that matches the actual risk.

## Bias

- findings first, summary second
- separate correctness issues from style or preference comments
- keep the report scannable and decision-oriented
- explain why a finding matters, not just what to change
- prefer one complete review packet over drip-fed feedback when the evidence is
  already available
- call out genuinely good patterns when doing so helps reinforce the right
  behavior
