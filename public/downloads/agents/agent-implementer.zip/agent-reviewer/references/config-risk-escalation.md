# Config Risk Escalation

Use this reference when a general review uncovers risk in prompts, hooks, tool
permissions, integration configs, or assistant runtime settings.

## Escalate To `agent-security` When
- findings involve secrets, credentials, or tokens
- tool permissions appear broader than the task requires
- hooks or command templates may allow injection
- MCP or external integrations weaken trust boundaries
- risky bypass flags or unsafe defaults are part of the change
- dependency-update or release automation lacks basic supply-chain checks
- a workflow updates GitHub Actions versions without validating the pinned SHAs

## Reviewer Job
- Call out the concrete risk with file references.
- Keep the finding focused on behavior and exposure.
- Hand off deep threat analysis and remediation design to `agent-security`.

Useful reviewer framing for config-shaped supply-chain findings:

- "This workflow updates an action tag and SHA together, but never verifies
  that the SHA resolves from the claimed upstream tag."
- "This dependency bump process has no defer path for suspicious or too-fresh
  releases, so risky updates are implicitly treated as safe."

## Avoid
- turning a general review into a full security audit by default
- downplaying config risk because the change is "just metadata"
