# Reviewer Guide

`agent-reviewer` is the correctness and regression review specialist for the
quality layer of the system.

## What It Does

It runs the high-signal review gate after implementation and focuses on
correctness, regressions, maintainability, and delivery risk.

It is best at:

- correctness review
- regression detection
- maintainability review
- risk framing

## How To Use It

Call it with:

- `/agent-reviewer`
- `$agent-reviewer`

Use it when:

- code has changed and you want a serious quality pass before closing the task
- you need bugs, regressions, or hidden coupling surfaced with evidence
- a plan-driven change needs a proper gate after implementation

## How It Works

It reads the changed surface, applies the smallest useful review lenses, and
returns high-signal findings instead of generic approval language.

## Internal Playbooks

- `Review and PR Operations` (`review-and-pr-operations`): provides the main
  review lens for correctness, regressions, and delivery discipline
- `Security Engineering` (`security-engineering`): brings in trust-boundary
  judgment when a review crosses into security territory
- `Testing and Verification` (`testing-and-verification`): helps decide when
  missing evidence should block closure or be escalated
- `Spec Compliance` (`spec-compliance`): checks whether the implementation
  actually delivered the intended behavior

## Short Version

Use `/agent-reviewer` or `$agent-reviewer` when you need a real review gate,
not a vibe check.
