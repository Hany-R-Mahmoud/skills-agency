# Reviewer Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for REVIEWER inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Ops and Quality department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: REVIEWER
- Subtitle: Correctness and regression review specialist
- Commands:
  - /agent-reviewer
  - $agent-reviewer
- One-line value:
  Runs the high-signal quality gate after implementation. Focuses on correctness, regressions, maintainability, and PR judgment while pulling internal review playbooks as needed.
- Capabilities:
  - correctness review
  - regression detection
  - maintainability review
  - risk framing
- How it works:
  - reads the changed surface
  - applies the smallest useful review lenses
  - looks for correctness and regression risk
  - returns high-signal findings
- Best used when:
  - code has changed and you want a serious quality pass before closing the task
  - you need bugs, regressions, or hidden coupling surfaced with evidence
  - a plan-driven change needs a proper gate after implementation
- Bottom summary:
  review-and-pr-operations, security-engineering, testing-and-verification, spec-compliance
- Footer note:
  You ask for the outcome. Reviewer checks whether it really holds.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
