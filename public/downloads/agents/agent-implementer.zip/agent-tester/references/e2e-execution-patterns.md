# E2E Execution Patterns

Use this reference when E2E testing needs tighter scope and clearer artifact
capture.

## Pattern

- run only the most relevant end-to-end paths first
- capture artifacts for failures and flaky behavior
- report pass/fail plus instability risk
- distinguish app failure from test harness failure
- keep one explicit evidence packet for each meaningful scenario:
  - scenario name
  - steps executed
  - observed result
  - artifact pointers
  - residual doubt
