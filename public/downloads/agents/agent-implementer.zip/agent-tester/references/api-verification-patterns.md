# API Verification Patterns

Use this reference when the main testing surface is an API rather than a UI.

## Coverage Shape

- contract and schema expectations
- success-path behavior
- failure-path behavior
- auth, permissions, and input validation
- integration or side-effect expectations
- performance or latency checks when they matter

## Reporting Shape

- what endpoints or operations were exercised
- what was verified functionally
- what security or boundary checks were included
- what performance evidence was gathered
- what remains unverified

## Guardrails

- do not confuse documentation completeness with runtime correctness
- do not report perf or security confidence from functional checks alone
- prefer a few high-value endpoint checks over a bloated endpoint inventory
