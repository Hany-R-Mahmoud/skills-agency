# Language Test Family Map

Use this reference to borrow the family pattern from build/review/test command
sets without importing them individually.

## Pattern

- `<lang>-build` suggests environment and compile validation
- `<lang>-review` suggests language-specific code-reading heuristics
- `<lang>-test` suggests the narrowest effective test runner path

## Usage

When the codebase is strongly language- or framework-specific, use the family
pattern to shape test selection and reporting instead of inventing a new public
tester for each language.
