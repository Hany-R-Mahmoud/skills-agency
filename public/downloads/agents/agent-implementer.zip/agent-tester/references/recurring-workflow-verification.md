# Recurring Workflow Verification

Use this reference when testing scheduled, persistent, or semi-autonomous
workflows.

## Check Areas
- isolated-run behavior versus interactive-session assumptions
- persistence of task state or memory across runs
- pause, stop, retry, or override controls
- handling of partial failure, rate limits, and flaky integrations
- success criteria for unattended runs

## Verification Questions
- Does the workflow still behave correctly when no interactive context exists?
- Can the run resume or retry safely after interruption or failure?
- Are stored summaries or task queues updated consistently?
- Can a human inspect or interrupt the workflow when needed?
- Does the system surface failure clearly instead of silently drifting?

## Guidance
- Test more than the happy path.
- Prefer small repeatable checks over one long optimistic run.
- Treat observability and operator control as part of correctness.
