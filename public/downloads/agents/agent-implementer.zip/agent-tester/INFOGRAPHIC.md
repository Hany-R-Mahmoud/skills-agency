# Tester Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for TESTER inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Ops and Quality department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: TESTER
- Subtitle: Verification strategist for tests, browser validation, and confidence reporting
- Commands:
  - /agent-tester
  - $agent-tester
- One-line value:
  Owns test strategy, execution, and the judgment of whether the evidence is strong enough to call the work complete.
- Capabilities:
  - test strategy
  - browser validation
  - regression protection
  - confidence reporting
- How it works:
  - reads the risk surface
  - chooses the smallest useful verification layers
  - gathers evidence from the right test levels
  - returns confidence, gaps, and next checks
- Best used when:
  - code changed and you need proof, not assumptions, before shipping
  - a bug fix needs a regression guard or a UI path needs browser-level validation
  - you want to understand what still has not been verified and why
- Bottom summary:
  testing-and-verification, debugging-and-diagnostics, frontend-react-and-next, e2e-execution-patterns
- Footer note:
  You ask for the outcome. Tester shows what is actually verified.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
