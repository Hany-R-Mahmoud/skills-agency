# Tester Guide

`agent-tester` is the verification strategist for tests, browser validation,
and confidence reporting.

## What It Does

It owns test strategy, execution, and the judgment of whether the evidence is
strong enough to call the work complete.

It is best at:

- test strategy
- browser validation
- regression protection
- confidence reporting

## How To Use It

Call it with:

- `/agent-tester`
- `$agent-tester`

Use it when:

- code changed and you need proof, not assumptions, before shipping
- a bug fix needs a regression guard or a UI path needs browser-level
  validation
- you want to understand what still has not been verified and why

## How It Works

It reads the risk surface, chooses the smallest useful verification layers, and
returns evidence plus a confidence call, not just a pass or fail vibe.

## Internal Playbooks

- `Testing and Verification` (`testing-and-verification`): chooses the right
  test layer and keeps evidence tied to behavior
- `Debugging and Diagnostics` (`debugging-and-diagnostics`): supports
  escalation when a failing check still lacks a clear root cause
- `Frontend React and Next` (`frontend-react-and-next`): improves verification
  of rendered UI and Next.js-specific behavior
- `E2E Execution Patterns` (`e2e-execution-patterns`): helps structure browser
  and end-to-end checks that remain reproducible

## Short Version

Use `/agent-tester` or `$agent-tester` when you need stronger evidence before
you call the task done.
