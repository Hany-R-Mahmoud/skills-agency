# Agent pack for agent-orchestrator

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-debugging`
- `agent-docs`
- `agent-implementer`
- `agent-orchestrator`
- `agent-reviewer`
- `agent-security`
- `agent-tester`
- `backend-and-language-engineering`
- `coordination-playbook`
- `debugging-and-diagnostics`
- `documentation-and-doc-ops`
- `frontend-react-and-next`
- `fullstack-engineering`
- `interface-and-design`
- `research-and-reasoning`
- `review-and-pr-operations`
- `security-engineering`
- `systems-architecture`
- `testing-and-verification`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
