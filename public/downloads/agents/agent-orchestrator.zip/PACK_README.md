# Agent pack for agent-orchestrator

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-debugging`
- `agent-design`
- `agent-docs`
- `agent-fintech`
- `agent-implementer`
- `agent-orchestrator`
- `agent-product`
- `agent-reviewer`
- `agent-security`
- `agent-tester`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
