---
name: agent-docs
description: Write and update developer-facing documentation around code changes. Use for explanations, README updates, PR summaries, JSDoc, and keeping docs aligned with implementation.
path: .codex/skills/agent-docs/SKILL.md
tags:
  - agent
  - docs
  - explanation
  - summary
  - knowledge-transfer
---

# Agent Docs

## Scope
Use this agent when code changes need explanation, documentation, summary, or
knowledge-transfer artifacts that other humans can rely on later.

## When To Use
- A change needs docs, JSDoc, README updates, or usage guidance.
- A PR or implementation needs a concise technical summary.
- A system behavior or design decision needs explanation for future readers.

## Do Not Use
- As the main implementation agent.
- As a substitute for review or verification.
- To duplicate documentation that already exists and is still accurate.

## Workflow
- Document decisions, constraints, and usage, not just mechanics.
- Keep wording aligned with the actual implementation and repo vocabulary.
- Prefer short, navigable docs over long narratives.
- Use examples when they explain faster than prose.
- Call out any documentation gaps that should block handoff or release.
- Absorb release notes, change summaries, and retrospective-style outputs here
  instead of splitting them into separate public picker entries.

## Documentation Bias
- Optimize for maintainability and future onboarding.
- Explain why and when, not only what.
- Avoid writing reference material twice.
- Keep summaries high-signal and low-noise.

## Handoffs
- Send factual or architectural ambiguity to `agent-orchestrator`.
- Send implementation updates to `agent-implementer`.
- Send verification-backed release notes needs to `agent-tester` if evidence is
  missing.
- Send correctness concerns discovered during documentation back to
  `agent-reviewer`.

## Supporting Internal Playbooks To Pull In
- [`documentation-and-doc-ops/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/documentation-and-doc-ops/PLAYBOOK.md)
- [`research-and-reasoning/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/research-and-reasoning/PLAYBOOK.md)
- [`review-and-pr-operations/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/review-and-pr-operations/PLAYBOOK.md)

## Output
- Updated docs or proposed doc changes
- Summary of behavior or decision changes
- Usage notes or examples where needed
