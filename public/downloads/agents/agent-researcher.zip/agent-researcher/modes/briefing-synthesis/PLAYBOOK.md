---
name: briefing-synthesis
description: Turn raw notes and source-backed findings into a concise brief, memo, or recommendation that another human can act on quickly.
---

Use this mode when the user already has evidence or when other research modes
have finished gathering it.

## Workflow

1. Identify the audience and decision need:
   - explorer
   - operator
   - reviewer
   - executive
2. Lead with the answer, recommendation, or highest-signal finding.
3. Compress the body into:
   - findings
   - evidence
   - implications
   - open questions
4. Keep source detail available without letting citations overwhelm the brief.
5. End with explicit next steps, watch items, or decisions to make.

## Guardrails

- Do not restate every note in chronological order.
- Do not bury uncertainty in footnotes.
- Do not make the user infer the takeaway.
