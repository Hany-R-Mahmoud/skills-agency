---
name: research-foundation
description: Frame the question, set the quality bar, choose the right sources, and keep findings, uncertainty, and synthesis disciplined from the start.
---

Use this mode at the start of every `agent-researcher` task.

## Workflow

1. Define the actual research question:
   - what must be answered
   - what decision this supports
   - what is out of scope
2. Set the quality bar:
   - quick scan
   - grounded answer
   - high-confidence decision brief
3. Identify the best source classes before searching broadly:
   - local docs or supplied material
   - official documentation or primary sources
   - reputable secondary reporting
4. Track findings in four buckets:
   - confirmed
   - inferred
   - conflicting
   - unknown
5. Keep a running note of dates, source freshness, and likely failure modes.

## Guardrails

- Do not research aimlessly before framing the question.
- Do not present inference as confirmation.
- Do not over-collect low-value sources when a few strong ones answer the
  question.
