---
name: landscape-scan
description: Compare a field of options, patterns, vendors, tools, or approaches and reduce it to a decision-friendly set of distinctions.
---

Use this mode when breadth matters and the user needs a structured comparison.

## Workflow

1. Define the comparison frame:
   - what is being compared
   - what criteria matter
   - what constraints eliminate weak fits early
2. Build a compact candidate set instead of an exhaustive catalog.
3. Compare candidates on the same axes:
   - fit for purpose
   - maturity or credibility
   - cost or complexity
   - risks and tradeoffs
   - evidence quality
4. Remove shallow distinctions and focus on decision-relevant differences.
5. Rank or cluster the options only after the criteria are explicit.

## Guardrails

- Do not pad the list with weak candidates just to seem comprehensive.
- Do not compare options on inconsistent criteria.
- Do not recommend a winner without explaining the tradeoff.
