---
name: source-grounded-research
description: Gather and validate evidence from strong sources, reconcile contradictions, and produce a source-aware answer with explicit uncertainty.
---

Use this mode when the user needs trustworthy research rather than a quick
summary.

## Focus

- evidence gathering from primary or otherwise strong sources
- cross-checking unstable or disputed claims
- source-aware synthesis with uncertainties called out

## Workflow

1. Start with the strongest available sources:
   - official docs
   - original papers or datasets
   - code, changelogs, filings, or direct statements
2. Expand only as needed for coverage:
   - reputable secondary sources
   - expert commentary
   - community signals when primary evidence is incomplete
3. For each important claim, record:
   - source
   - date
   - evidence strength
   - whether it is confirmed or inferred
4. When sources conflict:
   - state the disagreement directly
   - compare source quality and recency
   - explain which interpretation is stronger and why
5. End with a synthesis that answers the user's question, not a source dump.

## Output Shape

Prefer:

- key findings
- supporting evidence
- known uncertainties
- practical implication or recommendation
