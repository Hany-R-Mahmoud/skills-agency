---
name: challenge-review
description: Pressure-test plans, claims, and recommendations with adversarial reasoning, pre-mortems, and alternative-path analysis.
---

Use this mode when the user wants the idea challenged, not merely supported.

## Workflow

1. State the leading claim or proposed plan clearly.
2. Identify the assumptions it depends on.
3. Test the downside cases:
   - what if the core assumption fails
   - what if the environment changes
   - what if the evidence is weaker than it appears
4. Compare serious alternatives, not strawmen.
5. Capture what still needs verification:
   - unresolved assumptions
   - strongest disconfirming check
   - evidence gaps that could flip the answer
6. Produce one of these outcomes:
   - supported with caveats
   - viable but risky
   - not yet justified
   - superseded by a stronger alternative

## Output Shape

- strongest case for the current plan
- strongest case against it
- key risk concentrations
- conditions under which the recommendation changes
- highest-value follow-up check when the answer is still fragile
