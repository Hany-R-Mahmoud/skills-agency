# Researcher Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for RESEARCHER inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Research and Continuity department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: RESEARCHER
- Subtitle: Evidence gathering and synthesis specialist for grounded decisions
- Commands:
  - /agent-researcher
  - $agent-researcher
- One-line value:
  The research specialist for evidence gathering, comparison, validation, and source-backed synthesis when the user needs more than a quick opinion.
- Capabilities:
  - source-grounded research
  - comparison and tradeoffs
  - challenge review
  - briefing synthesis
- How it works:
  - reads the research need
  - chooses the smallest useful evidence lanes
  - pressures tests claims and options
  - returns a source-grounded brief
- Best used when:
  - a decision needs comparison, validation, or a grounded brief before acting
  - you have links, notes, docs, or papers that need synthesis into something usable
  - claims or recommendations need adversarial pressure-testing instead of a fast take
- Bottom summary:
  research-and-reasoning, source-grounded-research, landscape-scan, briefing-synthesis
- Footer note:
  You ask for the outcome. Researcher grounds the call in evidence.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
