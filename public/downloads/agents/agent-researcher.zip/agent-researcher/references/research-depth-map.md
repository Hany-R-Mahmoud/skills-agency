# Research Depth Map

Use this reference to deepen `agent-researcher` when a task needs more than a
quick search-and-summarize pass.

## Source Quality Ladder

- prefer primary sources over commentary when correctness matters
- prefer direct measurements, original docs, filings, code, papers, or first
  party statements over reposted summaries
- use secondary sources to expand coverage, not to replace verification

## Freshness And Stability

- verify dates explicitly when the topic can change
- distinguish stable background facts from fast-moving facts
- treat "latest", "current", "today", and "recent" as verification triggers

## Contradiction Handling

- do not flatten conflicting sources into one blended answer
- identify which claim is supported best and why
- note what evidence would resolve the disagreement if it remains open

## Synthesis Bias

- organize around the user's decision, not around source chronology
- compress obvious facts and spend space on implications, tradeoffs, and open
  questions
- end with a recommendation only when the evidence supports one
