# Skill Map

## Foundation

- `research-foundation`: `modes/research-foundation/PLAYBOOK.md`, shared rules
  for question framing, evidence quality, uncertainty tracking, and output
  discipline

Always start with `research-foundation`.

## Modes

- `source-grounded-research`: `modes/source-grounded-research/PLAYBOOK.md`,
  source collection, validation, contradiction handling, and citation-minded
  synthesis
- `landscape-scan`: `modes/landscape-scan/PLAYBOOK.md`, market, tool, vendor,
  pattern, or option comparison across a broad field
- `challenge-review`: `modes/challenge-review/PLAYBOOK.md`, adversarial
  reasoning, pre-mortems, risk testing, and assumption pressure-tests
- `briefing-synthesis`: `modes/briefing-synthesis/PLAYBOOK.md`, turn research
  notes into a decision-ready brief, memo, or recommendation
