# Request Recipes

- "Research this topic":
  start with `research-foundation`; add `source-grounded-research`
- "Compare these options":
  start with `research-foundation`; add `landscape-scan`
- "Pressure-test this plan or claim":
  start with `research-foundation`; add `challenge-review`
- "Turn these findings into a brief":
  start with `research-foundation`; add `briefing-synthesis`
- "Compare options and recommend one":
  start with `research-foundation`; add `landscape-scan`,
  `briefing-synthesis`
- "Validate whether this is true":
  start with `research-foundation`; add `source-grounded-research`,
  optionally `challenge-review`
