# Researcher Guide

`agent-researcher` is the public evidence gathering and synthesis specialist for
grounded decisions.

## What It Does

It helps with comparison, validation, source-backed synthesis, and challenge
review when the user needs more than a quick opinion.

It is best at:

- source-grounded research
- comparison and tradeoffs
- challenge review
- briefing synthesis

## How To Use It

Call it with:

- `/agent-researcher`
- `$agent-researcher`

Use it when:

- a decision needs comparison, validation, or a grounded brief before acting
- you have links, notes, docs, or papers that need synthesis into something
  usable
- claims or recommendations need adversarial pressure-testing instead of a fast
  take

## How It Works

It reads the research need, chooses the smallest useful evidence lanes, and
returns a source-grounded brief instead of a loose summary.

## Internal Playbooks

- `Research and Reasoning` (`research-and-reasoning`): provides the
  evidence-first operating model for synthesis and challenge review
- `Source Grounded Research` (`source-grounded-research`): keeps the answer
  anchored to stronger sources instead of loose summaries
- `Landscape Scan` (`landscape-scan`): builds comparative views when the user
  needs options, categories, or market context
- `Briefing Synthesis` (`briefing-synthesis`): turns scattered findings into a
  memo, brief, or decision-ready summary

## Short Version

Use `/agent-researcher` or `$agent-researcher` when you need evidence you can
lean on, not just a fast opinion.
