---
name: analytics
description: Analyze metrics, SQL-oriented data questions, and reporting logic with attention to definitions and interpretation risk.
---

Focus on metric definitions, query logic, segmentation, and interpretation.
