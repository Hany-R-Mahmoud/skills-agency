---
name: corpus-retrieval
description: Use a trusted notebook or document corpus as a grounded retrieval layer for data and AI workflows when the task is really about asking the corpus well.
---

Use this mode when the best source of truth is a curated document collection.

## Focus

- question formulation over trusted corpora
- grounded extraction before synthesis
- gap detection when the corpus cannot answer reliably
