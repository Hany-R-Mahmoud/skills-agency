---
name: model-evaluation-support
description: Use optional external model-backed capabilities to support evaluation, comparison, or artifact generation for AI workflows without making vendor tooling the center of the system design.
---

Use this mode when external model access helps evaluate prompts, outputs, or
media-dependent AI workflows.

## Workflow

1. Define the evaluation target:
   - prompt behavior
   - model output quality
   - latency or cost tradeoff
   - artifact generation quality
2. Set explicit scoring criteria before running comparisons.
3. Keep experimental evaluation separate from the production path when possible.
4. Bound the evaluation:
   - timeout
   - retry cap
   - budget or cost ceiling
   - fallback path
5. End with a decision recommendation, not just raw scores.

## Guardrails

- keep vendor-specific helpers optional
- use them to support evaluation, not to hide weak system design
- do not run open-ended comparison loops or unbounded external evaluations
- do not auto-promote an experimental path without a clear threshold and
  rollback rule
