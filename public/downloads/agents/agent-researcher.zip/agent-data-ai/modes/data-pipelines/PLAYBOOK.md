---
name: data-pipelines
description: Design and evolve ETL, warehouse, and streaming data workflows with quality and lineage in mind.
---

Focus on source quality, transformation boundaries, scheduling, and failure
handling.
