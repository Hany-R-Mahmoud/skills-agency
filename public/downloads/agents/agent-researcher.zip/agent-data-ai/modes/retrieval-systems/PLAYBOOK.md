---
name: retrieval-systems
description: Design retrieval pipelines with embeddings, indexing, vector stores, ranking, and hybrid search.
---

Focus on chunking, indexing, recall/precision tradeoffs, and retrieval quality.
