---
name: data-ai-foundation
description: Shared foundation for data and AI work covering data quality, evaluation, latency/cost tradeoffs, and system boundaries.
---

Use this playbook before any other `agent-data-ai` mode.

## Rules

- establish data sources, freshness, and trust level before proposing systems
- treat evaluation as part of correctness, not an afterthought
- make latency, cost, and quality tradeoffs explicit
- distinguish experimentation from productionized workflows
