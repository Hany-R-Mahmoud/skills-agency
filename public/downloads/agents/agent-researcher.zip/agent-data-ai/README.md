# Data AI Guide

`agent-data-ai` is the public data, AI, analytics, retrieval, and ML systems
entry point in this skill pack.

## What It Does

It routes AI and data-heavy work through the right internal lanes while keeping
the result grounded in architecture, data quality, and evaluation.

It is best at:

- LLM systems
- RAG and retrieval
- analytics
- data pipelines

## How To Use It

Call it with:

- `/agent-data-ai`
- `$agent-data-ai`

Use it when:

- you are designing an LLM feature, RAG flow, or prompt pipeline
- the task is about analytics, ETL, ML infrastructure, or vector retrieval
- you need model-backed evaluation support instead of ad hoc intuition

## How It Works

It reads the request, chooses the smallest useful AI and data playbooks, keeps
the evidence chain visible, and returns one coherent system direction.

## Internal Playbooks

- `Data AI Foundation` (`data-ai-foundation`): sets the operating model for AI,
  analytics, and data-system work before deeper lanes are selected
- `LLM Systems` (`llm-systems`): handles prompt flow, context assembly,
  guardrails, and agent-style AI features
- `Retrieval Systems` (`retrieval-systems`): designs retrieval, vector search,
  and grounding workflows that stay explainable
- `Data Pipelines` (`data-pipelines`): shapes ingestion, transformation, and
  quality-aware data movement
- `Model Evaluation Support` (`model-evaluation-support`): adds evaluation
  loops when AI output quality needs more than spot checks

## Short Version

Use `/agent-data-ai` or `$agent-data-ai` when the problem is about AI systems,
retrieval, analytics, or data flow rather than plain application logic.
