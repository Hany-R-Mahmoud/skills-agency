# Data AI Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for DATA AI inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Engineering and Systems department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: DATA AI
- Subtitle: Data, AI, analytics, retrieval, and ML systems specialist
- Commands:
  - /agent-data-ai
  - $agent-data-ai
- One-line value:
  The public entry point for analytics, LLM systems, retrieval, ML workflows, and data pipelines. It keeps AI work grounded in architecture, data quality, and evaluation.
- Capabilities:
  - LLM systems
  - RAG and retrieval
  - analytics
  - data pipelines
- How it works:
  - reads the request
  - chooses the smallest useful AI and data playbooks
  - keeps the evidence chain visible
  - returns one coherent system direction
- Best used when:
  - you are designing an LLM feature, RAG flow, or prompt pipeline
  - the task is about analytics, ETL, ML infrastructure, or vector retrieval
  - you need model-backed evaluation support instead of ad hoc intuition
- Bottom summary:
  data-ai-foundation, llm-systems, retrieval-systems, data-pipelines, model-evaluation-support
- Footer note:
  You ask for the outcome. Data AI grounds the system.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
