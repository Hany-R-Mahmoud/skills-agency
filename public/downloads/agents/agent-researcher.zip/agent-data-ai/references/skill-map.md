# Skill Map

## Foundation

- `data-ai-foundation`: `modes/data-ai-foundation/PLAYBOOK.md`, shared
  discovery, evaluation framing, and data-quality guardrails

Always start with `data-ai-foundation`.

## Modes

- `llm-systems`: `modes/llm-systems/PLAYBOOK.md`, LLM applications, agent
  systems, and prompt pipeline architecture
- `retrieval-systems`: `modes/retrieval-systems/PLAYBOOK.md`, RAG, embeddings,
  vector stores, and hybrid retrieval
- `ml-systems`: `modes/ml-systems/PLAYBOOK.md`, ML pipelines, serving, feature
  flow, and model lifecycle concerns
- `data-pipelines`: `modes/data-pipelines/PLAYBOOK.md`, ETL, warehousing, and
  streaming data workflows
- `analytics`: `modes/analytics/PLAYBOOK.md`, metrics analysis, SQL-oriented
  reasoning, and reporting logic
- `prompt-systems`: `modes/prompt-systems/PLAYBOOK.md`, prompt quality,
  evaluation loops, and prompt-ops concerns
- `corpus-retrieval`: `modes/corpus-retrieval/PLAYBOOK.md`, notebook-grounded
  retrieval and question answering over trusted document collections
- `model-evaluation-support`: `modes/model-evaluation-support/PLAYBOOK.md`,
  optional model-backed evaluation helpers and media/model capability support
