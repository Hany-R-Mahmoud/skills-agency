# Request Recipes

- "Build an AI feature":
  start with `data-ai-foundation`; add `llm-systems`
- "Build RAG / retrieval":
  start with `data-ai-foundation`; add `retrieval-systems`
- "Work on ML pipelines or serving":
  start with `data-ai-foundation`; add `ml-systems`
- "Work on ETL / data engineering":
  start with `data-ai-foundation`; add `data-pipelines`
- "Analyze the data":
  start with `data-ai-foundation`; add `analytics`
- "Improve prompts":
  start with `data-ai-foundation`; add `prompt-systems`
- "Ask our corpus / notebook":
  start with `data-ai-foundation`; add `corpus-retrieval`
- "Use external model help for evaluation":
  start with `data-ai-foundation`; add `model-evaluation-support`
