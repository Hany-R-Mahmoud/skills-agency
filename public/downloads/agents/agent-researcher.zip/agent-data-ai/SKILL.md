---
name: agent-data-ai
description: Unified data and AI systems agent for this skill pack. Use when Codex should handle analytics, data pipelines, LLM systems, RAG, ML workflows, vector retrieval, notebook-grounded corpus retrieval, or optional model-backed evaluation support through one local entry point.
---

# Agent Data AI

Provide a single public entry point for this repository's data, AI, and ML
system work.

Act as a router plus executor: choose the smallest set of data/AI modes needed,
sequence them well, and avoid loading irrelevant guidance.

## Invocation Contract

Invoke this skill directly as `$agent-data-ai` whenever the prompt is about
data pipelines, analytics, LLM application architecture, retrieval, ML systems,
or vector search infrastructure.

## Quick Start

- "build an LLM / RAG system":
  `data-ai-foundation`, then `llm-systems`; often add `retrieval-systems`
- "work on data pipelines":
  `data-ai-foundation`, then `data-pipelines`
- "analyze data or metrics":
  `data-ai-foundation`, then `analytics`
- "design ML infra or serving":
  `data-ai-foundation`, then `ml-systems`
- "improve prompts or prompt pipelines":
  `data-ai-foundation`, then `prompt-systems`
- "ask our document corpus":
  `data-ai-foundation`, then `corpus-retrieval`
- "use model-backed evaluation helpers":
  `data-ai-foundation`, then `model-evaluation-support`

## Core Workflow

1. Classify the task: analytics, ETL, LLM app, RAG, ML, or prompt pipeline.
2. Load `modes/data-ai-foundation/PLAYBOOK.md` first.
3. Choose the minimum supporting modes from the references.
4. Keep outputs explicit about data quality, evaluation, and operational risks.

## Reference

Use these references as needed:

- `references/skill-map.md`
- `references/request-recipes.md`
- `references/data-ai-depth-map.md`
