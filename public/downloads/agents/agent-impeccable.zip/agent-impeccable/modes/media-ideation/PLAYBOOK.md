---
name: media-ideation
description: Generate or shape supporting visual concepts and media ideas that reinforce a UI direction without replacing actual interface design work.
---

Use this mode when visual ideation or generated support assets help clarify the
product direction.

## Guardrails

- the interface still carries the product, not the supporting media
- generated visuals should reinforce the chosen design system
- do not use media ideation as a shortcut around weak layout or UX decisions
