---
name: accessibility
description: Improve accessibility, WCAG alignment, semantic structure, keyboard usability, and assistive-technology compatibility without sacrificing the product's visual language.
---

## MANDATORY PREPARATION

Use the frontend-design skill first and follow the Context Gathering Protocol.
Additionally gather: supported platforms, accessibility expectations, and any
known compliance bar.

---

Use this mode when inclusive interaction quality is a first-order concern.

## Focus Areas

- semantic HTML before ARIA patching
- keyboard reachability and logical focus order
- visible focus treatment
- screen reader naming and announcements
- color contrast and non-color affordances
- reduced motion and zoom resilience

## Guardrails

- do not fix accessibility by degrading the core product experience
- do not add ARIA where native semantics already solve the problem
- do not treat accessibility as a postscript after major UX decisions
