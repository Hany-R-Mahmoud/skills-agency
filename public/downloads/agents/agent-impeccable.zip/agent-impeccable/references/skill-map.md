# Skill Map

Use this file to route a request to the minimum useful subset of the internal
frontend/UI/design modes bundled inside `agent-impeccable`.

## Foundation

- `frontend-design`: `modes/frontend-design/PLAYBOOK.md`, shared design
  principles, anti-patterns, and context gathering
- `teach-impeccable`: `modes/teach-impeccable/PLAYBOOK.md`, one-time project
  design context capture

Always start with `frontend-design`. If design context is absent, use
`teach-impeccable` before making design decisions.

## Structural Modes

- `arrange`: `modes/arrange/PLAYBOOK.md`, improve layout, spacing, composition,
  and visual rhythm
- `adapt`: `modes/adapt/PLAYBOOK.md`, adjust designs for screen sizes, devices,
  platforms, and contexts
- `onboard`: `modes/onboard/PLAYBOOK.md`, improve onboarding flows, empty states,
  and first-use experience
- `normalize`: `modes/normalize/PLAYBOOK.md`, align a feature to the existing
  design system
- `extract`: `modes/extract/PLAYBOOK.md`, identify reusable components, tokens,
  and patterns

Use when the problem is mostly about structure, flow, reuse, or consistency.

## Visual Modes

- `typeset`: `modes/typeset/PLAYBOOK.md`, improve typography and hierarchy
- `colorize`: `modes/colorize/PLAYBOOK.md`, add or refine color strategy
- `animate`: `modes/animate/PLAYBOOK.md`, add purposeful motion and
  micro-interactions
- `delight`: `modes/delight/PLAYBOOK.md`, introduce memorable, personality-rich
  details
- `bolder`: `modes/bolder/PLAYBOOK.md`, increase visual distinctiveness and energy
- `quieter`: `modes/quieter/PLAYBOOK.md`, reduce visual intensity while
  preserving quality
- `distill`: `modes/distill/PLAYBOOK.md`, remove unnecessary complexity
- `polish`: `modes/polish/PLAYBOOK.md`, final refinement pass before shipping
- `overdrive`: `modes/overdrive/PLAYBOOK.md`, push the interface into technically
  ambitious territory
- `media-ideation`: `modes/media-ideation/PLAYBOOK.md`, generate or shape
  supporting visual/media concepts when they help clarify a UI direction

Use when the structure mostly works and the task is about feel, expression, or
final quality.

## Diagnostic Modes

- `critique`: `modes/critique/PLAYBOOK.md`, evaluate UX/design effectiveness and
  identify what is not working
- `audit`: `modes/audit/PLAYBOOK.md`, run a comprehensive interface quality review
  with severity
- `accessibility`: `modes/accessibility/PLAYBOOK.md`, improve WCAG alignment,
  keyboard usability, focus behavior, semantic structure, and inclusive design

Use `critique` for expert feedback. Use `audit` for systematic reporting across
multiple quality dimensions. Use `accessibility` when inclusion and operability
for assistive technologies are first-order concerns.

## Production Modes

- `harden`: `modes/harden/PLAYBOOK.md`, improve resilience, error handling, i18n,
  overflow, and edge cases
- `optimize`: `modes/optimize/PLAYBOOK.md`, improve frontend performance and
  smoothness

Use after concept and styling work when the interface must be production-ready.

## Recommended Bundles

- Build or redesign a feature:
  `frontend-design`, then `arrange`, `typeset`, `colorize`; add `animate` or
  `delight` if appropriate
- Match an existing product:
  `frontend-design`, then `normalize`, then `polish`
- Prepare for launch:
  `frontend-design`, then `harden`, `optimize`, `polish`
- Review without changing code:
  `frontend-design`, then `critique`, `audit`, or `accessibility`
- Simplify an over-designed interface:
  `frontend-design`, then `distill`, optionally `quieter`
- Make a bland interface more memorable:
  `frontend-design`, then `bolder`, `typeset`, `colorize`, optionally `delight`
- Generate supporting visuals:
  `frontend-design`, then `media-ideation`; optionally pair with `colorize` or
  `delight`
- Accessibility pass:
  `frontend-design`, then `accessibility`; add `harden` if implementation-level
  remediation is needed

## Anti-Pattern

Do not invoke all skills just because they exist. Too many simultaneous modes
create contradictory guidance, noisy output, and bloated context.
