# Request Recipes

Use this file when the user describes a desired outcome instead of naming a
specific design skill.

## Build And Redesign

- "Build this page/component/flow":
  start with `frontend-design`; usually add `arrange`, `typeset`, `colorize`
- "Redesign this without changing the product identity":
  start with `frontend-design`; usually add `normalize`, `polish`
- "Make this responsive":
  start with `frontend-design`; add `adapt`; optionally add `arrange`

## Quality And Review

- "Review this UI/UX":
  start with `frontend-design`; add `critique`
- "Audit before launch":
  start with `frontend-design`; add `audit`; optionally add `harden` and
  `optimize` as remediation lanes
- "Check accessibility":
  start with `frontend-design`; add `accessibility`; often add `harden`
- "What feels off here?":
  start with `frontend-design`; add `critique`; add `typeset` or `arrange` if
  the problem is obviously visual

## Visual Direction

- "Make it feel premium":
  start with `frontend-design`; usually add `typeset`, `arrange`, `polish`;
  optionally `quieter`
- "Make it feel more alive":
  start with `frontend-design`; usually add `animate`, `delight`
- "Create visual concepts or supporting media":
  start with `frontend-design`; add `media-ideation`
- "Make it bolder":
  start with `frontend-design`; add `bolder`; optionally `colorize`,
  `typeset`
- "Tone it down":
  start with `frontend-design`; add `quieter` or `distill`
- "Make it simpler":
  start with `frontend-design`; add `distill`; optionally `clarify`

## System Alignment

- "Match the design system":
  start with `frontend-design`; add `normalize`
- "Extract reusable patterns from this":
  start with `frontend-design`; add `extract`

## Product Readiness

- "Make this production-ready":
  start with `frontend-design`; add `harden`, `optimize`, `polish`
- "Fix edge cases":
  start with `frontend-design`; add `harden`
- "Improve keyboard / focus / screen reader support":
  start with `frontend-design`; add `accessibility`; optionally `harden`
- "Make it faster/smoother":
  start with `frontend-design`; add `optimize`; add `animate` only if motion is
  part of the perceived smoothness goal

## Special Cases

- "Improve onboarding / empty states / first run":
  start with `frontend-design`; add `onboard`; often add `clarify`
- "Push this way further":
  start with `frontend-design`; add `overdrive`; add `harden` if the result
  must still be production-safe

## Guardrail

Do not map vague prompts to every possible mode. Pick the most likely primary
mode, then add only the minimum supporting modes needed to complete the job.
