---
name: agent-impeccable
description: Unified frontend UI and design agent for this skill pack. Use when Codex should handle web interface design or redesign end to end, including concept direction, layout, typography, color, motion, onboarding, responsiveness, design-system alignment, critique, hardening, performance, polish, and audit work. Best for requests that could touch multiple related frontend-design skills or when you want one entry point instead of choosing among the individual UI/design skills manually.
---

# Agent Impeccable

Provide a single entry point for this repository's frontend UI and design skills.
Act as a router plus executor: choose the smallest set of design modes needed,
sequence them well, and avoid loading irrelevant guidance.

Do not paste or mentally apply all 21 skills at once. Start with the shared
foundation, then pull only the modes required for the task.

The public entry is this skill only. The former standalone skills now live under
`modes/<skill-name>/PLAYBOOK.md` as internal implementation modes for this
agent, and should not be treated as public picker entries.

## Invocation Contract

Invoke this skill directly as `$agent-impeccable` whenever the prompt is about
design, UI, UX, visual polish, interaction quality, frontend aesthetics,
responsiveness, onboarding, design-system fit, or interface quality.

When explicitly invoked, do not ask the user to choose internal modes unless
there is a real strategic tradeoff. Infer the likely intent from the prompt,
map it to the minimum useful internal mode set, and proceed.

The user should not need to know or name the internal modes. Treat them as
private implementation details.

## Use This Skill For

- building or redesigning a page, component, flow, or full frontend experience
- making an existing interface feel more polished, premium, clear, fast, or
  production-ready
- matching a feature to the existing design system
- auditing, critiquing, or pressure-testing interface quality before shipping
- choosing the right subset of UI/design modes without manually selecting among
  the internal skills

## Do Not Use This Skill For

- backend-only work with no user-facing interface consequences
- generic code review that is not focused on UI, UX, frontend quality, or
  design-system fit
- low-level debugging where the visual/design problem is not yet understood

## Quick Start

If the request sounds like one of these, use the matching route immediately:

- "build/redesign this page":
  `frontend-design`, then usually `arrange`, `typeset`, `colorize`
- "make this feel more polished":
  `frontend-design`, then `polish`, optionally `typeset` or `colorize`
- "make this match the product":
  `frontend-design`, then `normalize`
- "review this UI":
  `frontend-design`, then `critique`; add `audit` for systematic reporting
- "ship this safely":
  `frontend-design`, then `harden` and `optimize`
- "make it more memorable":
  `frontend-design`, then `bolder` or `delight`
- "make it simpler/calmer":
  `frontend-design`, then `distill` or `quieter`

If the user explicitly invokes `$agent-impeccable`, default to automatic
routing. Only surface the chosen modes briefly when it helps explain the path.

## Core Workflow

1. Inspect the request and classify it:
   - creation or redesign
   - critique or audit
   - refinement or stylistic shift
   - production hardening or performance
   - system extraction or normalization
2. Load `modes/frontend-design/PLAYBOOK.md` first for shared principles and the
   Context Gathering Protocol.
3. If project design context is missing, run
   `modes/teach-impeccable/PLAYBOOK.md` before any design decision.
4. Choose the minimum set of additional modes from
   `references/skill-map.md` and `references/request-recipes.md`.
5. Execute in a sane order:
   - understand current state
   - set design direction
   - apply structural changes
   - apply stylistic changes
   - harden and optimize
   - audit or polish if requested
6. Keep output cohesive. If multiple modes are used, resolve conflicts instead
   of stacking contradictory advice.

## Automatic Routing Rule

When the prompt contains design intent but does not specify a mode:

- infer the dominant intent from the prompt language
- choose one primary mode
- add only the minimum supporting modes needed
- continue without asking the user to pick from internal skills

Escalate only when the prompt genuinely points to multiple incompatible
directions, such as "make it both bolder and much quieter" or "match the
existing system but reinvent the brand."

## Routing Rules

Default to these bundles:

- New page, feature, or redesign:
  `frontend-design` plus one or more of `arrange`, `typeset`, `colorize`,
  `animate`, `delight`, `onboard`, `adapt`, `harden`, `polish`
- Design critique without implementation:
  `frontend-design` plus `critique`; add `audit` for structured severity-based
  reporting
- Match existing system:
  `frontend-design` plus `normalize`; add `extract` if reusable patterns should
  be pulled into a system
- Make it bolder or quieter:
  `frontend-design` plus exactly one of `bolder`, `quieter`, or `distill`
- Production readiness:
  `frontend-design` plus `harden`, `optimize`, and optionally `audit`
- Advanced visual ambition:
  `frontend-design` plus `overdrive`, then add `harden` if the result must be
  production-safe

If a request is narrow, stay narrow. For example, typography-only work should
not pull in color, motion, onboarding, and audit by default.

Prefer a primary mode and at most 2-4 supporting modes for most tasks. Pull in
more only when the request is genuinely broad.

## Conflict Resolution

Some modes pull in opposite directions. Resolve them deliberately:

- `bolder` vs `quieter`:
  choose one direction; do not blend both unless the task explicitly asks for a
  rebalance across separate areas
- `distill` vs `delight`:
  prefer `distill` for clarity-first products; prefer `delight` when emotional
  resonance is a product goal
- `overdrive` vs `normalize`:
  use `normalize` when consistency with an existing system matters more than
  novelty
- `polish` vs `audit`:
  `polish` improves; `audit` reports. Do not silently switch one into the other

## Default Execution Standards

Regardless of which modes are selected:

- inspect nearby code and existing patterns before proposing changes
- preserve the established design system unless the request explicitly changes
  it
- treat accessibility, responsive behavior, empty states, loading states, and
  error states as part of correctness
- avoid generic AI aesthetics and repetitive card-grid solutions
- when changing production UI, prefer concrete implementation guidance over
  abstract design commentary
- when uncertainty is material, present 2-3 directions with explicit tradeoffs
  before committing

## User Request Translation

Users often describe outcomes, not modes. Translate intent like this:

- "clean this up" usually means `polish`, sometimes `distill`
- "make it pop" usually means `bolder`, `typeset`, or `colorize`
- "make it smoother" usually means `animate` or `optimize`
- "make it enterprise" usually means `normalize`, `harden`, `polish`
- "make it premium" usually means `typeset`, `arrange`, `polish`, optionally
  `quieter`
- "make onboarding better" usually means `onboard`, often with `clarify`

If the prompt mixes several design desires, prioritize in this order unless the
user says otherwise:

1. preserve product/design-system fit
2. fix clarity and structural issues
3. improve visual quality
4. improve motion and delight
5. push stylistic boldness

## Output Shape

Match the task:

- For implementation work:
  summarize the chosen modes, explain the sequence briefly, then make the code
- For critique work:
  group findings by severity or impact, then provide concrete fixes
- For exploratory work:
  present 2-3 viable directions with tradeoffs before committing

Always name the modes you chose when that helps the user understand the path.

## Reference

Use these references as needed:

- `references/skill-map.md`: compact map of all internal modes
- `references/request-recipes.md`: common user phrasing to mode bundles

Read only the relevant entries rather than reloading every individual skill in
full.
