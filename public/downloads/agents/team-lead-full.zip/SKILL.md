---
name: team-lead-full
description: Full team orchestration entry point for risky, ambiguous, or cross-cutting work. Trigger when the user explicitly invokes `$team-lead-full` anywhere in the prompt, or when they want the heaviest workflow with artifacts, explicit gates, and specialist coordination across implementation, review, testing, security, debugging, research, architecture, and docs.
---

# Team Lead Full

## Scope
Use this skill for large, risky, or ambiguous work where stronger workflow
control is worth the overhead. This is the heaviest entry point and should be
used when the cost of a wrong path is meaningful.

## Invocation Contract
Use this skill immediately when the user explicitly includes `$team-lead-full`
anywhere in the prompt.

Treat it as a lead-driven, delegate-first workflow with explicit artifacts and
quality gates.

## Best Fit
- Cross-cutting features
- Large refactors or migrations
- Architecture-sensitive work
- Security-sensitive work
- Tasks where proposal, validation, and documentation need to be first-class
- Ambiguous requests that benefit from staged clarification before coding

## Operating Rules
- The lead should remain mostly delegate-first.
- Do not let multiple workers edit the same file without an explicit reason and
  ownership plan.
- Prefer phase boundaries over free-form multitasking.
- Require evidence before marking work complete.
- Keep artifacts concise and reusable.

## Workflow
1. Explore:
   inspect the repo, conventions, and task shape
2. Propose:
   define the intended path, tradeoffs, and risks
3. Task:
   break work into owned slices with dependencies and file scope
4. Implement:
   delegate bounded execution to the right specialist
5. Review and verify:
   require review, testing, and security checks when relevant
6. Archive:
   summarize outcomes, residual risks, and follow-ups

## Artifact Expectations
When the task is substantial, maintain lightweight artifacts such as:
- plan summary
- task breakdown
- review findings
- verification summary
- open risks or follow-ups

Keep the artifacts short. They exist to preserve state and make handoffs
reliable, not to create ceremony for its own sake.

Use the shared operating contract at
[`../team-lead/references/shared-team-contract.md`](/Users/hanyramadan/.codex/skills/team-lead/references/shared-team-contract.md)
for the canonical shape of these artifacts.

For context efficiency and token control, also use
[`../team-lead/references/context-efficiency-playbook.md`](/Users/hanyramadan/.codex/skills/team-lead/references/context-efficiency-playbook.md).

## Routing Rules
Core worker agents:
- `agent-orchestrator` mindset for planning and sequencing
- `agent-debugging` for reproduce-first investigation
- `agent-implementer` for owned code changes
- `agent-reviewer` for correctness and regression review
- `agent-tester` for evidence and confidence
- `agent-security` for trust boundaries, secrets, validation, and exposure
- `agent-docs` for explanation, docs, summaries, and decision capture

Domain playbooks the lead may use directly:
- [`systems-architecture/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/systems-architecture/PLAYBOOK.md) for architecture, contracts, boundaries, migrations, and specs
- [`research-and-reasoning/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/research-and-reasoning/PLAYBOOK.md) for evidence gathering, adversarial review, and tradeoffs
- [`fullstack-engineering/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/fullstack-engineering/PLAYBOOK.md) for cross-layer delivery framing
- [`frontend-react-and-next/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/frontend-react-and-next/PLAYBOOK.md) for substantial React or Next.js implementation direction
- [`backend-and-language-engineering/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/backend-and-language-engineering/PLAYBOOK.md) for backend or CLI-intensive execution direction
- [`mcp-development/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/mcp-development/PLAYBOOK.md) for MCP protocol or tool architecture
- [`interface-and-design/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/interface-and-design/PLAYBOOK.md) or `agent-impeccable` for design-heavy streams
- [`platform-engineering/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/platform-engineering/PLAYBOOK.md) for infra or deployment-sensitive changes
- [`openai-docs/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/openai-docs/PLAYBOOK.md) for official OpenAI product guidance when accuracy is time-sensitive

## Context Discipline
- Use iterative retrieval before loading broad repo context into specialists.
- At each major phase boundary, replace stale narrative with a milestone
  summary.
- Prefer artifact-backed handoffs over carrying the full exploration thread
  into later phases.
- Promote repeated stable lessons into
  [`../team-lead/references/learned-patterns.md`](/Users/hanyramadan/.codex/skills/team-lead/references/learned-patterns.md).

## Quality Gates
Before closing the task, explicitly decide whether each gate is satisfied:
- implementation gate
- review gate
- verification gate
- security gate when relevant
- docs gate when relevant

If a gate is skipped, state why and what risk remains.

## Routing Matrix
- Unclear problem shape:
  start with `research-and-reasoning` or `agent-debugging`
- Architecture-sensitive task:
  start with `systems-architecture`
- Cross-layer delivery:
  use `fullstack-engineering` to frame execution, then assign owned slices
- Security or exposure risk:
  involve `agent-security` before closure
- Design-heavy stream:
  use `agent-impeccable` or `interface-and-design`
- Official platform uncertainty:
  use `openai-docs` or another primary-source skill before coding

## Escalation And De-escalation Matrix
- Stay in `$team-lead-full` when:
  - multiple critical paths are affected
  - parallel specialist work adds value
  - written artifacts or explicit gates are necessary
- Reduce to `$team-lead` when:
  - the path is understood and the remaining work is mostly implementation plus review/testing
- Reduce to `$team-lead-lite` when:
  - the problem collapses to one narrow, low-risk change

## De-escalation
If the task becomes simpler than expected, the lead may intentionally reduce the
workflow to `$team-lead` or `$team-lead-lite`.

## Output
- Chosen phase path
- Selected specialists and domain skills
- Artifact summary
- Gate status
- Residual risks and recommended next step
