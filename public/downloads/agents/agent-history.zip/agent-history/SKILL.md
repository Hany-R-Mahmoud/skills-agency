---
name: agent-history
description: Export a conversation, workstream, or project state into a structured handoff briefing for a new chat, new session, or different AI tool. Use when the user wants to continue elsewhere, preserve context, create a continuity pack, summarize all decisions and status, or explicitly invokes `$agent-history` anywhere in the prompt.
---

# Agent History

## Scope
Use this skill to create a clean, paste-ready continuity briefing that lets a
new AI pick up work with minimal loss of context.

## Invocation Contract
Use this skill immediately when the user explicitly includes `$agent-history`
anywhere in the prompt.

Also use it when the user asks for any of the following:
- export this conversation
- create a handoff
- prepare context for a new chat
- continue in another tool
- summarize everything we decided so far
- package the current work for later continuation

## Primary Goal
Preserve the working state accurately enough that a new AI can continue with the
same decisions, constraints, tone, and next steps without re-discovery.

## Output Requirements
Default to a structured briefing that covers:
1. Full working context
2. Decisions made and why
3. Current status and completed work
4. Remaining work and next steps
5. User preferences, rules, and constraints
6. Communication style and collaboration preferences
7. Standing instructions the assistant should keep following
8. Relevant user-specific facts from the conversation
9. Tone, formatting, and structure expectations
10. Anything else needed for seamless continuation

## Accuracy Rules
- Prefer factual continuity over polish.
- Separate confirmed facts from assumptions or inferred context.
- Do not invent missing history. If a detail is unclear, say so explicitly.
- Preserve exact skill names, file paths, commands, and decisions when they
  matter.
- If the conversation produced code or files, mention what changed and where.

## Compression Rules
- Keep the briefing complete, but remove low-signal chatter.
- Preserve rationale, status, blockers, and user-specific preferences.
- Compress repetition aggressively.
- Prefer short sections over long narratives.

## Workflow
1. Identify the active workstream and what outcome the user needs from the
   handoff.
2. Reconstruct the important timeline:
   - initial goal
   - decisions
   - changes made
   - validation performed
   - current open work
3. Capture user-specific preferences and instructions that should survive the
   session.
4. When a trusted notebook or document corpus materially informed the work,
   capture that source context so the next AI knows where grounded answers came
   from.
5. Produce a structured briefing using the template in
   `references/briefing-template.md`.
6. If relevant, include a final "resume prompt" that the user can paste into a
   new chat.

## Template Guidance
Read
[`references/briefing-template.md`](references/briefing-template.md)
before writing the final handoff. Follow its section order unless the user asks
for a different format.

If the work relied on a trusted notebook or document corpus, also consult
[`references/notebooklm-handoff.md`](references/notebooklm-handoff.md)
so the next AI inherits the source-grounding context instead of only the final
summary.

For session continuity mechanics, also consult
[`references/session-continuity-patterns.md`](references/session-continuity-patterns.md).

## Quality Bar
- A new AI should understand the task without rereading the old conversation.
- Another agent should know what not to redo.
- The user should not need to reconstruct missing decisions manually.

## Output
- Structured continuity briefing
- Optional resume prompt for the next AI
- Explicit uncertainties if any context is incomplete
- Source-corpus notes when NotebookLM-style grounding was important to the work
