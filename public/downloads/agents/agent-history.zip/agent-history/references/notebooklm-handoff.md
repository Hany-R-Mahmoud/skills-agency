# NotebookLM Handoff Notes

When work relied on a trusted NotebookLM corpus, include:

- which notebook or corpus mattered
- what kinds of questions it answered
- any limitations or contradictions in that corpus
- whether the next AI should continue to rely on it
