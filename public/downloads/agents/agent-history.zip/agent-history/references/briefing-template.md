# Continuity Briefing Template

Use this template when exporting work for a new chat or a different AI tool.

## Project / Workstream
- What we are working on:
- Why it matters:

## Full Context
- Background:
- Current initiative:
- Relevant files, skills, or tools:

## Decisions Made
- Decision:
- Why:
- Impact:

Repeat as needed for each important decision.

## Current Status
- Completed:
- In progress:
- Validated:

## Remaining Work
- Still needs to be done:
- Recommended next step:
- Risks or open questions:

## User Preferences And Rules
- Preferences:
- Constraints:
- Standing instructions:

## Communication Style
- Tone:
- Working style:
- How to present results:

## User-Specific Notes
- Relevant details about the user:
- Important context that should persist:

## Tone And Format To Continue With
- Response style:
- Formatting expectations:
- Anything to avoid:

## Resume Prompt
Provide a ready-to-paste prompt for the next AI that includes:
- the current objective
- the immediate next step
- what has already been done
- what rules or preferences must be preserved

## Uncertainties
- Anything that is inferred rather than confirmed:
- Anything a new AI should verify first:
