# Session Continuity Patterns

Use this reference when the user wants a handoff that is easy to resume later.

## Pattern

- assign a clear workstream identity
- summarize decisions, current status, and blockers separately
- preserve changed files and validation state explicitly
- provide a clean resume entry point instead of forcing re-discovery

## Resume Bias

- the next AI should absorb the saved state before taking action
- continuity should reduce repeated setup questions
