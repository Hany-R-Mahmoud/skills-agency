# Session Continuity Patterns

Use this reference when the user wants a handoff that is easy to resume later.

## Pattern

- assign a clear workstream identity
- summarize decisions, current status, and blockers separately
- preserve changed files and validation state explicitly
- provide a clean resume entry point instead of forcing re-discovery
- distinguish confirmed facts from assumptions or partial reconstruction
- add a short confidence or completeness note when continuity depends on
  inferred, filtered, or incomplete context
- when useful, include a compact deep-inspect pointer such as the source file,
  note, or artifact path that the next AI can consult

## Continuity Contract

When a handoff needs to survive tool or session boundaries, preserve a compact
canonical snapshot:

- workstream id or session label
- current state
- repo or worktree root when known
- active file scope
- outputs so far
- validation evidence
- remaining risks

Keep the contract stable and JSON-serializable when possible so the next tool
or AI can absorb state without reinterpreting prose-heavy notes.

## Preservation Bias

- Pair mechanical state extraction with concise prose instead of choosing one or
  the other.
- Prefer retrieval or exported state over freehand recollection when a
  structured source exists.
- Let deterministic data carry verifiable continuity:
  - files touched
  - commands run
  - validation state
  - commits or artifacts
- Let prose carry intent and nuance:
  - what mattered
  - why decisions were made
  - what the next AI should pay attention to first
- If prose and extracted state disagree, prefer the extracted state for factual
  continuity and keep the prose as interpretation.
- If continuity depends on searchable notes, prior artifacts, or a memory
  system, query those first and summarize second.

## Resume Bias

- the next AI should absorb the saved state before taking action
- continuity should reduce repeated setup questions
- keep the confidence note concise; it should warn, not drown the handoff
- when facts come from retrieval, distinguish what was found mechanically from
  what is still inferred or unresolved
