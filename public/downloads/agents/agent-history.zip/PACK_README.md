# Agent pack for agent-history

This archive is generated from the local skills repository.

## Included

- `AGENT_FIRST_REFACTOR.md`
- `INDEX.md`
- `README.md`
- `agent-history`

Extract these files into your skills workspace root to preserve the relative links between agents, playbooks, references, and supporting docs.
