# Design-System Governance

Use this reference when `agent-design` needs to define how a design system
stays consistent across pages, themes, components, and future agent sessions.

## Core Philosophy

A design system is useful only if it has a clear source of truth and a stable
override model. Tokens, component rules, and page-specific deviations should be
organized so future work can retrieve the right guidance without re-deciding
the whole system.

## When To Use

Pull this reference with `ui-systems`, and often `brand-system`, when the user
asks to:

- create a reusable design system
- define token architecture
- document design rules for future pages
- support light/dark or brand variants
- establish page-specific overrides
- audit design-token consistency
- prepare a durable handoff for designers, engineers, or agents

## Token Layers

Prefer a three-layer token model:

1. Primitive tokens
   - raw values: colors, font families, sizes, spacing, radius, shadows
   - example roles: `blue-600`, `space-4`, `radius-sm`
2. Semantic tokens
   - purpose aliases: `primary`, `surface`, `text-muted`, `danger`, `focus`
   - these encode meaning and theme behavior
3. Component tokens
   - component-specific use: `button-bg`, `card-border`, `input-focus-ring`
   - these prevent components from hardcoding primitives

Do not skip the semantic layer. It is what allows theme switching and coherent
future decisions.

## Source-Of-Truth Pattern

For durable systems, recommend a structure like:

```text
design-system/
├── MASTER.md
├── tokens.json
├── tokens.css
└── pages/
    ├── dashboard.md
    └── checkout.md
```

- `MASTER.md`: global design rules, token rationale, component behavior, and
  default layout guidance
- `tokens.json`: structured token values when implementation handoff needs it
- `tokens.css`: CSS variables or platform-equivalent token output
- `pages/*.md`: page-specific deviations only

Page files should override the master, not duplicate it.

## Retrieval Rule

When designing a specific page:

1. Read the global source of truth first.
2. Check for a page-specific override.
3. Apply the page override only where it explicitly deviates.
4. If no override exists, use the global system.
5. Do not invent new tokens until existing tokens have been checked.

## Governance Checks

- Every important visual value has a token or documented exception.
- Tokens have purpose names, not only raw descriptions.
- Component states are defined: default, hover, active, focus, selected,
  disabled, loading, error.
- Light and dark modes are mapped intentionally.
- Page-level deviations are documented as exceptions, not silent drift.
- Accessibility requirements are encoded in the system, not only in a final
  checklist.
- The handoff says when to extend the system and when to reuse existing rules.

## Output Shape

For a governance recommendation, include:

1. Source Of Truth
2. Token Layering
3. Component State Rules
4. Theme And Mode Rules
5. Page Override Policy
6. Validation Checklist

Keep the system as small as possible while still preventing drift.
