# Design Intelligence Routing

Use this reference when `agent-design` needs to recommend a design direction
from product context rather than only from aesthetic preference.

## Core Philosophy

Good design direction should be product-aware. The right visual system for a
fintech dashboard, a wellness service, a developer tool, and a creative
portfolio should differ because audience trust, density, action priority, and
risk differ.

Use product context to choose style, color mood, typography, layout pattern,
motion level, and anti-patterns deliberately.

## When To Use

Pull this reference with `design-foundation`, then usually `brand-system`,
`ux-architecture`, `ui-systems`, or `visual-storytelling` when the user asks to:

- choose a visual direction for a product or industry
- design a landing page, dashboard, app, portfolio, or campaign from scratch
- compare possible styles for a product category
- recommend colors, typography, layout, or interaction mood
- make design decisions where audience trust, conversion, or product category
  matters

## Reasoning Flow

1. Identify product category:
   - SaaS, developer tool, fintech, healthcare, education, marketplace,
     e-commerce, creator portfolio, media, wellness, restaurant, nonprofit,
     entertainment, or other
2. Identify audience and context:
   - expert vs casual
   - repeated-use app vs one-time landing page
   - trust-critical vs exploration-led
   - data-dense vs story-led
3. Choose a primary design pattern:
   - hero-centric
   - conversion-focused
   - trust-and-authority
   - product-demo-led
   - feature-rich showcase
   - dashboard/data-dense
   - editorial/storytelling
   - minimal/direct
4. Choose style family:
   - restrained minimal
   - enterprise-clean
   - editorial
   - tactile/soft
   - dark technical
   - bold studio
   - playful consumer
   - premium luxury
5. Choose system ingredients:
   - color mood and contrast level
   - typography character and pairings
   - spacing density
   - imagery or illustration role
   - motion intensity
   - component density
6. Name category-specific anti-patterns:
   - what would damage trust, clarity, performance, accessibility, or fit

## Product Fit Examples

- Fintech or banking:
  prioritize trust, clarity, contrast, predictable navigation, restrained color,
  accessible charts, and conservative motion.
- Healthcare:
  prioritize calm, legibility, reassurance, privacy cues, clear forms, and
  inclusive imagery.
- Developer tools:
  prioritize precision, code/data readability, efficient density, keyboardable
  flows, and technical credibility.
- Creative portfolio or agency:
  allow higher variance, stronger typography, image-led sections, and
  memorable rhythm while preserving readability.
- E-commerce:
  prioritize product imagery, filtering clarity, pricing legibility, trust
  signals, and frictionless checkout cues.
- Data dashboards:
  prioritize scanability, hierarchy, tabular figures, chart accessibility,
  density control, and empty/loading/error states.

## Output Shape

When giving a recommendation, include:

1. Product Fit Assumption
2. Recommended Pattern
3. Style Direction
4. Color And Typography Direction
5. Layout And Motion Direction
6. Anti-Patterns To Avoid
7. Validation Checks

Keep recommendations concrete enough to become a `DESIGN.md`, design handoff,
or implementation brief.
