# Design-System Extraction Playbook

Use this reference when `agent-design` needs to analyze an existing website,
repo, local app, screenshot set, or design reference and turn it into reusable
design-system guidance.

## Core Philosophy

Extraction should be evidence-led. Start from observable design facts, then
turn them into agent-usable rules. Do not treat visual inspiration as a license
to clone a brand one-to-one unless the user owns the identity or explicitly has
permission.

The goal is a reusable design profile: tokens, components, layout rules,
interaction behavior, motion style, image treatment, and constraints that a
future agent can apply consistently.

## When To Use

Pull this reference with `brand-system`, `ui-systems`, and sometimes
`visual-storytelling` when the user asks to:

- extract a design system from a URL, repo, local project, or screenshot
- reverse-engineer the visual language of an existing interface
- turn a visual reference into a `DESIGN.md` or handoff spec
- compare an existing product UI against a desired design direction
- capture colors, typography, spacing, components, motion, and layout patterns
- make a design system grounded in observed evidence rather than invention

## Evidence To Gather

Gather only what the task can reasonably support:

- surfaces: page backgrounds, panels, cards, overlays, and section bands
- color roles: background, surface, text, muted text, border, accent, semantic
  states
- typography: font families, display/body/label/mono roles, size relationships,
  line height, weight, and tracking behavior
- spacing: base grid, section rhythm, card padding, gutters, container width
- shape: radius scale, border treatment, dividers, shadows, and elevation
- components: buttons, inputs, navigation, cards, tables, modals, badges,
  empty/loading/error states
- layout: grid strategy, density, breakpoints, mobile collapse, media framing
- interaction: hover, focus, active, selected, disabled, loading, and error
  behavior
- motion: durations, easing, stagger, scroll behavior, animation purpose, and
  reduced-motion expectations
- imagery: photo style, illustration style, crop logic, overlays, product
  renders, and icon treatment

## Extraction Workflow

1. Identify the source type:
   - live URL
   - local repo or app
   - static screenshot
   - brand/design reference
   - existing `DESIGN.md`
2. Separate observations from interpretation:
   - observed: exact tokens, component patterns, screenshot evidence
   - inferred: rationale, atmosphere, audience fit, likely design principles
3. Build a compact design profile:
   - visual atmosphere
   - token roles
   - type and spacing system
   - component and state rules
   - layout and responsive rules
   - motion and interaction rules
   - do/don't guardrails
4. Add validation artifacts when useful:
   - preview card list
   - color and type catalog
   - component inventory
   - screenshot notes
   - source/rationale summary
5. Package the result in the smallest useful format:
   - critique or audit
   - design handoff
   - `DESIGN.md`
   - extraction report plus recommended next steps

## Grounding Rules

- Do not invent exact hex values, font names, or component states unless the
  source provides them or the user asks for a speculative system.
- If a visual detail is inferred, label it as inferred.
- Preserve implementation-relevant details: breakpoints, focus rings, loading
  states, empty states, and responsive collapse behavior.
- Prefer semantic token names over source-specific class names.
- If the extraction comes from a named third-party brand, frame the output as
  inspired by observable patterns unless usage rights are clear.
- Recommend live browser, screenshot, or code inspection when visual fidelity
  matters and the evidence is incomplete.

## Output Shape

For an extraction report, use:

1. Source And Evidence
2. Observed Visual System
3. Inferred Design Principles
4. Tokens And Component Rules
5. Responsive And Interaction Rules
6. Risks, Gaps, And Validation Needs
7. Recommended Artifact: critique, handoff, or `DESIGN.md`
