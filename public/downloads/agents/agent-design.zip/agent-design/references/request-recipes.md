# Request Recipes

Use this file when the user describes a design outcome instead of naming a
specific internal mode.

## Brand And Identity

- "create our brand system":
  start with `design-foundation`; add `brand-system`
- "create brand guidelines" or "make brand rules reusable":
  start with `design-foundation`; add `brand-system`; pull
  `references/brand-governance.md`
- "refresh our identity":
  start with `design-foundation`; add `brand-system`; sometimes add
  `visual-storytelling`
- "make sure this feels on-brand":
  start with `design-foundation`; add `brand-system`

## Research And UX

- "plan research for this":
  start with `design-foundation`; add `ux-research`
- "turn findings into personas or journeys":
  start with `design-foundation`; add `ux-research`
- "structure this flow":
  start with `design-foundation`; add `ux-architecture`
- "give developers a UX foundation":
  start with `design-foundation`; add `ux-architecture`; often add
  `ui-systems`

## UI Systems

- "design the components or tokens":
  start with `design-foundation`; add `ui-systems`
- "prepare handoff specs":
  start with `design-foundation`; add `ui-systems`
- "define theming and visual rules":
  start with `design-foundation`; add `ui-systems`; sometimes add
  `brand-system`
- "define token architecture" or "set up design-system governance":
  start with `design-foundation`; add `ui-systems`; pull
  `references/design-system-governance.md`
- "create a DESIGN.md" or "make this a portable design system":
  start with `design-foundation`; add `brand-system` and `ui-systems`; pull
  `references/design-md-playbook.md`; add
  `references/design-system-governance.md` when the system needs master/page
  overrides
- "turn this reference into reusable design rules":
  start with `design-foundation`; add `brand-system` and `ui-systems`; pull
  `references/design-md-playbook.md`
- "extract the design system from this site/repo/screenshot":
  start with `design-foundation`; add `brand-system` and `ui-systems`; pull
  `references/design-system-extraction-playbook.md`; add
  `references/design-md-playbook.md` if the output should be portable

## Narrative And Visuals

- "tell this story visually":
  start with `design-foundation`; add `visual-storytelling`
- "make this campaign more compelling":
  start with `design-foundation`; add `visual-storytelling`
- "write prompts for visuals":
  start with `design-foundation`; add `image-direction`
- "make these visuals inclusive":
  start with `design-foundation`; add `inclusive-visuals`
- "give this more personality":
  start with `design-foundation`; add `delight`
- "make this look less generic" or "improve the visual taste":
  start with `design-foundation`; add the most relevant primary mode; pull
  `references/visual-taste-calibration.md`
- "what design direction fits this product":
  start with `design-foundation`; add the most relevant primary mode; pull
  `references/design-intelligence-routing.md`
- "redesign this without losing the existing product":
  start with `design-foundation`; add `ui-systems`; often add
  `brand-system`; pull `references/visual-taste-calibration.md` and
  `references/ux-quality-gates.md`
- "review UX quality" or "check accessibility and interaction":
  start with `design-foundation`; add the most relevant primary mode; pull
  `references/ux-quality-gates.md`

## Guardrail

Do not map vague prompts to every design mode. Pick the most likely primary
mode, then add only the supporting modes needed to finish the job well.
