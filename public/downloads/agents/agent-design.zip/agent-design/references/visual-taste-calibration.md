# Visual Taste Calibration

Use this reference when `agent-design` needs to raise the visual quality of a
concept, redesign, landing page, design system, or image direction without
turning the output into a generic premium template.

## Core Philosophy

Good visual taste is not decoration. It is the disciplined alignment of
hierarchy, spacing, typography, rhythm, materials, interaction, and audience
fit. Push beyond default AI-looking layouts, but keep the design readable,
accessible, and implementable.

Use this as calibration, not dogma. The right amount of expressiveness depends
on product category, audience, surface, and implementation risk.

## Taste Dials

Set these internally when the prompt needs visual direction:

- Design variance:
  low = conventional and symmetric; high = asymmetric, editorial, or art-led
- Motion intensity:
  low = static with clear states; high = expressive, choreographed, or cinematic
- Visual density:
  low = spacious and gallery-like; high = dense dashboard or command surface
- Art direction:
  low = quiet commercial; high = memorable, image-led, or campaign-like
- Implementation clarity:
  low = conceptual mood; high = buildable section or system reference
- Image usage:
  low = type/system-led; high = photography, product media, or image-led story
- Spacing generosity:
  low = compact utility; high = breathable, premium, and editorial

Adapt the dials from the user's words instead of asking them to configure a
scale unless the tradeoff matters.

## Anti-Generic Checks

Actively check for these common weak patterns:

- centered hero plus vague subcopy as the default answer
- repeated three-card feature rows
- purple/blue AI gradients used as a shortcut for "modern"
- generic card spam where spacing or dividers would be clearer
- weak typography hierarchy or oversized headings used without purpose
- flat color palettes with no surface logic
- inconsistent warm and cool neutrals in the same system
- cramped sections with no breathing room
- every section using the same left-text/right-image rhythm
- fake data, generic names, vague startup copy, or placeholder language
- images used as decoration instead of structural design material
- missing loading, empty, error, focus, active, and disabled states

## Hero Discipline

For landing pages, campaign concepts, and image direction:

- make the hero feel like a clear opening scene
- keep the headline short, legible, and structurally important
- choose one dominant focal point
- use asymmetry or image-led composition when it serves the brand
- avoid stuffing the first viewport with badges, fake stats, and tiny details
- keep CTA hierarchy restrained and obvious
- ensure mobile collapse preserves hierarchy and does not create horizontal
  overflow

## Section Rhythm

A strong page rarely repeats the same block over and over. Vary rhythm through:

- density
- image-to-text ratio
- alignment
- scale
- whitespace
- card grouping
- background intensity
- proof, story, feature, and CTA pacing

Keep variation controlled. The page should feel curated, not random.

## Image-First Guidance

When the task is mainly visual and image generation or visual references are
available, prefer a visual-reference-first workflow:

1. define the section count and visual goal
2. create or inspect section-specific references
3. extract typography, spacing, colors, imagery, buttons, and component logic
4. then write the design spec, prompt, or handoff

For multi-section sites, prefer clear section-level references over one tiny
compressed board when fidelity matters.

## Redesign Audit Lens

For existing designs, audit in this order:

1. Typography: hierarchy, width, weight, line-height, and readability
2. Color And Surfaces: palette discipline, contrast, elevation, and texture
3. Layout: grid, spacing, alignment, density, and responsive behavior
4. Interactivity: hover, focus, active, loading, empty, and error states
5. Content: specificity, believable data, useful labels, and non-generic copy
6. Components: necessity, hierarchy, state coverage, and reusable patterns
7. Accessibility: semantics, focus, contrast, alt text, and keyboard paths

Prioritize changes by impact and risk. Start with the smallest changes that
materially improve quality.

For deeper usability, accessibility, responsive, form, navigation, or data
visualization review, pull `references/ux-quality-gates.md` and apply those
gates before treating visual polish as complete.

## Quality Check

Before returning visual direction, verify:

- The design has a clear hierarchy and one primary idea.
- Typography, spacing, and surfaces feel intentional.
- The concept avoids obvious AI-generated defaults.
- Expressiveness matches the audience and product category.
- Visual ambition does not compromise accessibility or implementation clarity.
- The output gives another designer or implementer concrete next moves.
