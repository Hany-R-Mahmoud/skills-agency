# Skill Map

Use this file to route a request to the minimum useful subset of the internal
design modes bundled inside `agent-design`.

## Foundation

- `design-foundation`: shared context gathering, design constraints,
  artifact-shaping rules, and handoff expectations

Always start with `design-foundation`.

## Design Modes

- `brand-system`: brand foundation, identity systems, voice, and consistency
- `ux-research`: research plans, personas, journeys, testing, and insight
  synthesis
- `ux-architecture`: information architecture, flows, wireframe logic, and
  design-ready structure
- `ui-systems`: design tokens, component systems, theming, and implementation
  handoff
- `visual-storytelling`: storyboards, narrative systems, campaign concepts, and
  information storytelling
- `inclusive-visuals`: anti-bias representation constraints, cultural fidelity,
  accessibility, and review checklists for visuals
- `image-direction`: image-prompt engineering, art direction, shot structure,
  and prompt refinement
- `delight`: playful details, personality, microcopy concepts, and purposeful
  moments of charm

## Recommended Bundles

- Build a brand system:
  `design-foundation`, then `brand-system`; pull
  `references/brand-governance.md` for reusable guidelines, assets, or
  approval rules
- Plan or synthesize research:
  `design-foundation`, then `ux-research`
- Turn a concept into structure:
  `design-foundation`, then `ux-architecture`, optionally `ui-systems`
- Create a design system or handoff:
  `design-foundation`, then `ui-systems`, optionally `brand-system`; pull
  `references/design-system-governance.md` for durable token architecture or
  page-level overrides
- Create a portable design-system source:
  `design-foundation`, then `brand-system` and `ui-systems`; pull
  `references/design-md-playbook.md`
- Extract an existing visual system:
  `design-foundation`, then `brand-system` and `ui-systems`; pull
  `references/design-system-extraction-playbook.md`, and add
  `references/design-md-playbook.md` when the output should be portable
- Create a campaign or narrative concept:
  `design-foundation`, then `visual-storytelling`, optionally
  `image-direction`
- Raise visual quality or audit taste:
  `design-foundation`, then the relevant primary mode; pull
  `references/visual-taste-calibration.md`
- Recommend product-aware direction:
  `design-foundation`, then the relevant primary mode; pull
  `references/design-intelligence-routing.md`
- Review UX quality gates:
  `design-foundation`, then the relevant primary mode; pull
  `references/ux-quality-gates.md`
- Improve representation quality:
  `design-foundation`, then `inclusive-visuals`, often with
  `image-direction`
- Write image prompts:
  `design-foundation`, then `image-direction`, optionally
  `inclusive-visuals`
- Add delight:
  `design-foundation`, then `delight`, optionally `brand-system`

## Anti-Pattern

Do not activate every design mode just because a request touches "design."
Choose the smallest useful bundle that can produce a coherent result.

## Supporting References

- `references/design-md-playbook.md`: use when creating, reviewing, or
  extracting a portable `DESIGN.md`-style design-system source file with
  tokens, rules, rationale, component behavior, responsive guidance, and agent
  prompt guidance.
- `references/design-system-extraction-playbook.md`: use when extracting a
  design system from a URL, repo, local app, screenshot set, or visual
  reference.
- `references/design-system-governance.md`: use for token layers, source of
  truth, page-specific overrides, and design-system validation policy.
- `references/brand-governance.md`: use for reusable brand guidelines, voice,
  messaging, asset organization, logo usage, and approval checks.
- `references/design-intelligence-routing.md`: use for product-aware style,
  color, typography, layout, and anti-pattern recommendations.
- `references/ux-quality-gates.md`: use for prioritized accessibility,
  interaction, responsive, form, navigation, and data visualization checks.
- `references/visual-taste-calibration.md`: use when improving taste, avoiding
  generic AI design defaults, calibrating page rhythm, or auditing an existing
  visual direction.
