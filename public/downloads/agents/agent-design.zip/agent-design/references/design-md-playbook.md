# DESIGN.md Playbook

Use this reference when `agent-design` needs to create, review, or extract a
portable design-system source file for future design agents, UI scaffolds, or
implementation handoff.

## Core Philosophy

A useful `DESIGN.md` keeps design decisions actionable by placing the rule,
token, and rationale together. It should be specific enough for an agent to
make the next design decision, while carrying enough "why" to stay coherent
when a future screen or component was not explicitly covered.

Treat `DESIGN.md` as a reusable source of truth, not a moodboard. It should
translate brand and product intent into durable visual rules, component
behavior, responsive expectations, and generation guidance.

## When To Use

Pull this reference alongside `brand-system` and/or `ui-systems` when the
request asks to:

- create a portable design brief or design-system source file
- turn visual inspiration into reusable system rules
- define a design system that other agents can apply later
- extract tokens, component behavior, and guardrails from existing materials
- review whether a design-system document is specific enough to generate from
- prepare a design handoff that should survive beyond one screen or prototype

## Recommended Structure

Use these sections unless the project already has a better local format:

1. Visual Theme And Atmosphere
   - product feeling, density, energy, and surface quality
   - audience fit and use-case context
2. Color Palette And Roles
   - semantic color roles, hex values when known, contrast notes
   - light/dark or mode-specific behavior when relevant
3. Typography Rules
   - font choices or practical substitutes
   - type scale, hierarchy, weight, casing, and reading rhythm
4. Component Styling
   - buttons, inputs, cards, navigation, tables, dialogs, and states
   - radius, borders, icons, focus, hover, disabled, and error behavior
5. Layout Principles
   - spacing scale, grid behavior, density, page rhythm, and alignment
6. Depth And Elevation
   - shadows, layering, surfaces, overlays, and visual hierarchy
7. Do And Do Not Rules
   - concrete guardrails that prevent drift
   - accessibility and inclusion constraints where relevant
8. Responsive Behavior
   - breakpoints, touch targets, collapse patterns, and mobile priorities
9. Agent Prompt Guide
   - short reusable instructions for applying the system in future tasks

## Preview And Validation Artifacts

When the user needs a durable design-system package, do not stop at the
markdown rules. Recommend or create small preview artifacts that make the
system inspectable:

- color swatches with semantic names, hex values, and contrast notes
- typography scale examples for display, heading, body, label, and mono roles
- component previews for buttons, inputs, cards, navigation, tables, and states
- light and dark mode previews when modes exist
- spacing and radius examples that show the rhythm rather than only naming it
- a short before/after or source/rationale note when extracting from a reference

Treat previews as quality control. They should reveal whether the written
system can actually generate coherent UI, not act as decorative collateral.

## Source Of Truth And Overrides

When the `DESIGN.md` will guide multiple future pages, pair it with a simple
governance model:

- global source: the default rules every page inherits
- page overrides: only the deviations a specific page needs
- token source: structured values when implementation handoff needs them

Use `references/design-system-governance.md` for the fuller token and override
policy. Avoid duplicating the whole master system inside every page-specific
file.

## Writing Rules

- Prefer semantic roles over raw decoration: `surface`, `accent`, `danger`,
  `muted text`, `focus ring`.
- Pair each important rule with the reason it exists.
- Make constraints concrete enough to test: sizes, roles, states, or examples.
- Include negative guidance where drift is likely.
- Avoid copying a named brand one-to-one unless the user owns or is authorized
  to use that identity.
- When drawing from public references, adapt the observable design pattern into
  an original system and flag trademark or brand-usage risk.
- If the source is an existing website or codebase, separate observed facts
  from inferred design rationale.

## Quality Check

Before returning a `DESIGN.md` artifact, verify:

- A future agent could generate a new screen without asking for basic style
  decisions.
- The document includes both visual choices and rationale.
- Tokens and component rules are reusable across multiple surfaces.
- Responsive behavior and interaction states are explicit.
- Preview examples cover the most important tokens and components.
- Accessibility is built into the rules, not appended as a vague reminder.
- Any brand-inspired material is framed as inspiration unless usage rights are
  clear.
