# UX Quality Gates

Use this reference when `agent-design` is reviewing, planning, or shaping an
interface where usability, accessibility, responsiveness, or interaction quality
matters.

## Core Philosophy

Visual quality is not complete unless the interface is usable, accessible,
responsive, and resilient across states. Apply these gates before treating a
design as ready for handoff.

Prioritize critical gates first. A beautiful interface with broken focus,
illegible contrast, tiny touch targets, or missing error states is not done.

## Priority Order

1. Accessibility
2. Touch And Interaction
3. Layout Stability And Performance
4. Responsive Behavior
5. Typography And Color
6. Animation And Motion
7. Forms And Feedback
8. Navigation
9. Charts And Data

## Accessibility

Check:

- normal text contrast meets at least 4.5:1
- large text and meaningful icons have sufficient contrast
- focus states are visible and not removed
- icon-only controls have accessible names
- images have meaningful alt text when content-bearing
- heading hierarchy is logical
- color is not the only way to convey meaning
- reduced motion preferences are respected
- keyboard and screen-reader paths match visual order

## Touch And Interaction

Check:

- touch targets are at least 44px/44pt, or platform equivalent
- adjacent controls have enough spacing to avoid accidental taps
- hover is never the only way to access essential actions
- pressed, active, selected, disabled, loading, and error states are distinct
- clickable elements look clickable
- gesture-only interactions have visible alternatives
- destructive actions are clearly separated and confirmed when needed

## Layout Stability And Performance

Check:

- images and async content reserve space to avoid layout shift
- heavy media is lazy-loaded when below the fold
- fonts avoid invisible text during load
- animation uses transform and opacity rather than layout properties
- long lists, dense tables, or charts have an appropriate simplification or
  virtualization strategy
- fixed headers, footers, and action bars do not cover content

## Responsive Behavior

Check:

- small phone, tablet, desktop, and wide desktop layouts are accounted for
- no horizontal overflow on mobile
- full-height sections use dynamic viewport-safe behavior when relevant
- gutters, columns, and type scale adapt by breakpoint
- text remains readable when content wraps or scales
- primary content appears before secondary content on small screens

## Typography And Color

Check:

- body text is readable, usually 16px or equivalent on mobile
- long-form line length is controlled
- type roles are consistent: display, heading, body, label, caption, mono
- numeric data uses tabular or monospaced figures where alignment matters
- colors are semantic, not raw one-off choices
- dark mode is designed separately, not simply inverted
- interaction and semantic colors remain accessible in every theme

## Animation And Motion

Check:

- motion has a purpose: continuity, feedback, hierarchy, or state change
- durations are brief enough to feel responsive
- exits are not slower than entries
- reduced-motion behavior exists
- animations are interruptible
- decorative motion does not compete with content
- chart or dashboard motion does not delay comprehension

## Forms And Feedback

Check:

- labels are visible and persistent
- helper text appears near complex fields
- errors appear near the related field and explain recovery
- submit actions show loading and success/error feedback
- invalid forms focus the first problem when appropriate
- long forms preserve user work or warn before dismissal
- empty states explain what happened and what to do next

## Navigation

Check:

- current location is visible
- back behavior is predictable
- primary and secondary navigation are distinct
- deep pages have an escape route
- modals are not used for primary navigation
- route changes preserve relevant scroll, filters, and input state
- mobile navigation does not hide essential actions

## Charts And Data

Check:

- chart type matches the data task
- legends, labels, units, and tooltips are clear
- data is not distinguished by color alone
- chart text and data marks meet contrast needs
- data tables or summaries exist where accessibility requires them
- loading, empty, and error states are designed
- dense datasets are aggregated or split rather than overloaded

## Output Shape

For review work, group findings by priority:

1. Critical blockers
2. High-impact usability issues
3. Visual polish and consistency
4. Nice-to-have refinements

For planning work, convert gates into acceptance criteria another designer or
implementer can verify.
