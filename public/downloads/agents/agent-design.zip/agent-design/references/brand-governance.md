# Brand Governance

Use this reference when `agent-design` needs to define, review, or maintain a
brand system beyond one visual direction.

## Core Philosophy

Brand is a source of truth, not just a palette. A useful brand system connects
positioning, voice, messaging, visual identity, asset usage, and approval rules
so future work can stay coherent without asking the same questions again.

## When To Use

Pull this reference with `brand-system`, and sometimes `ui-systems` or
`visual-storytelling`, when the user asks to:

- create or refresh brand guidelines
- review brand consistency
- define voice, tone, messaging, or positioning
- organize brand assets and naming rules
- define logo, color, and typography usage
- prepare approval criteria for campaigns or generated assets
- sync brand guidance into design tokens or a `DESIGN.md`

## Brand Source Of Truth

Recommend one canonical brand document when the brand will be reused:

```text
docs/brand-guidelines.md
```

It should capture:

- purpose and positioning
- audience and use contexts
- personality and voice
- messaging pillars
- visual identity
- logo usage and clear-space rules
- color palette and accessibility constraints
- typography rules and fallbacks
- imagery and illustration direction
- asset naming and organization
- approval checklist

## Voice And Messaging

Define:

- voice attributes: stable personality traits
- tone range: how voice changes by context
- messaging pillars: 3-5 durable ideas the brand repeats
- proof points: facts, features, or evidence that support the pillars
- banned phrasing: cliches, claims, or tone mismatches to avoid

Keep voice concrete. "Friendly and premium" is not enough unless it is paired
with examples, tradeoffs, and forbidden patterns.

## Visual Identity Rules

Define:

- primary and secondary logo usage
- minimum size and clear space
- approved color variants
- background restrictions
- unacceptable logo modifications
- primary palette, neutral palette, semantic colors
- type roles and fallback fonts
- icon and illustration style
- photography or generated-image constraints

If the user references an external brand, flag legal or trademark risk unless
they clearly own or are authorized to use it.

## Asset Organization

Recommend predictable naming and grouping:

```text
assets/brand/
├── logos/
├── icons/
├── imagery/
├── templates/
└── exports/
```

Use names that encode purpose, variant, size, and theme when relevant:

```text
logo-primary-dark.svg
logo-mark-light-512.png
social-header-linkedin-1584x396.png
```

## Approval Checklist

Before approving a brand artifact, check:

- It matches the brand source of truth.
- Voice and message fit the audience and channel.
- Logo usage follows clear-space, color, and size rules.
- Colors and text meet accessibility needs.
- Type hierarchy matches the system.
- Imagery avoids stereotypes, tokenism, or off-brand stock tropes.
- Claims are supportable and not misleading.
- File naming and export formats are production-usable.

## Output Shape

For brand governance work, include:

1. Brand Source Of Truth
2. Voice And Messaging Rules
3. Visual Identity Rules
4. Asset Organization
5. Approval Checklist
6. Open Risks Or Missing Inputs
