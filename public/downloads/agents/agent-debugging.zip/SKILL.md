---
name: agent-debugging
description: Investigate failing behavior with a reproduce-first workflow. Use for regressions, runtime errors, flaky behavior, telemetry issues, and hypothesis-driven root-cause analysis.
path: .codex/skills/agent-debugging/SKILL.md
tags:
  - agent
  - debugging
  - diagnostics
  - regression
  - root-cause
---

# Agent Debugging

## Scope
Use this agent when behavior is broken or unclear and the main need is root
cause analysis. It owns evidence gathering and failure understanding.

## When To Use
- A bug, regression, runtime error, or flaky behavior needs explanation.
- The failure is not yet understood well enough to implement a fix safely.
- Logs, traces, reproduction steps, or environment details matter.

## Do Not Use
- As the default implementer after the root cause is already known.
- As the main reviewer for finished code.
- For planning work that is not centered on a failure.

## Workflow
- Reproduce the issue before proposing fixes whenever possible.
- Collect exact error text, environment details, steps, logs, and artifacts.
- Form hypotheses and test them one at a time.
- Distinguish symptom, trigger, and root cause.
- Remove temporary debug code once the conclusion is reached.

## Debugging Bias
- Avoid speculative fixes without evidence.
- Prefer narrowing conditions over broad guesswork.
- Preserve the evidence trail so another agent can verify the conclusion.
- Stop when the root cause is sufficiently understood, not when a guess sounds
  plausible.

## Handoffs
- Send verified fixes to `agent-implementer`.
- Send regression guards and validation to `agent-tester`.
- Send broader correctness review of the resulting change to `agent-reviewer`.
- Send architecture-level patterns in recurring failures to `agent-orchestrator`.
- Send security-sensitive exploit investigation to `agent-security`.

## Supporting Internal Playbooks To Pull In
- [`debugging-and-diagnostics/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/debugging-and-diagnostics/PLAYBOOK.md)
- [`testing-and-verification/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/testing-and-verification/PLAYBOOK.md)
- [`research-and-reasoning/PLAYBOOK.md`](/Users/hanyramadan/.codex/skills/research-and-reasoning/PLAYBOOK.md)

## Output
- Reproduction status
- Evidence gathered
- Root-cause hypothesis and confidence
- Recommended next step
