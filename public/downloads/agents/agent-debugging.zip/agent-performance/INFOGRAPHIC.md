# Performance Infographic Prompt

Locked variant: `Gemini portrait social`

```text
Create a portrait infographic for PERFORMANCE inside the Skills Agency brand system.

Goal:
Explain what the agent is, how to use it, what it helps with, and the internal playbooks it routes through.

Visual direction:
- cinematic command-floor aesthetic from the Skills Agency website
- dark layered surfaces first, but adaptable to the light theme later
- sharp geometric framing, restrained glow, premium operational layout
- display typography in the spirit of Syne, body text in the spirit of Manrope, mono command styling in the spirit of JetBrains Mono
- use the Engineering and Systems department accent from the website design system
- avoid generic SaaS gradients, pastel styling, oversized rounded cards, or noisy cyberpunk clutter

Mandatory content:
- Title: PERFORMANCE
- Subtitle: Profiling and optimization specialist for apps, systems, and DX
- Commands:
  - /agent-performance
  - $agent-performance
- One-line value:
  The optimization specialist for runtime bottlenecks, rendering cost, backend latency, and developer-experience speed. Focuses on real bottlenecks instead of premature tuning.
- Capabilities:
  - profiling
  - frontend performance
  - backend latency
  - DX optimization
- How it works:
  - reads the slowdown
  - chooses the smallest useful performance lanes
  - identifies the hotspot
  - returns a practical optimization path
- Best used when:
  - something feels slow and you need profiling before changing code blindly
  - a frontend, backend, or full app bottleneck needs targeted optimization
  - developer workflow speed or feedback loops are getting in the team’s way
- Bottom summary:
  performance-foundation, profiling, frontend-performance, backend-performance, dx-optimization
- Footer note:
  You ask for the outcome. Performance finds the bottleneck first.

Keep it friendly, easy to scan, and suitable for reuse on the website later.
```
