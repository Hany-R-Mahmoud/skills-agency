---
name: frontend-performance
description: Improve frontend responsiveness, rendering cost, bundle weight, and network behavior using evidence-based optimization.
---

Use for render thrash, bundle bloat, interaction latency, and UI smoothness.
