---
name: app-performance
description: Analyze end-to-end application performance across frontend, backend, network, and persistence layers.
---

Use when the bottleneck layer is not yet clear or spans multiple layers.
