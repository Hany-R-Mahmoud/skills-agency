---
name: performance-foundation
description: Shared foundation for performance work with measurement-first habits, baseline capture, and tradeoff-aware optimization.
---

Use this playbook before any other `agent-performance` mode.

## Rules

- measure before optimizing
- capture a baseline and a target when possible
- distinguish user-perceived slowness from system-resource bottlenecks
- keep correctness and maintainability in view while optimizing
