---
name: dx-optimization
description: Improve developer workflow performance across builds, tests, monorepo tooling, and local feedback loops.
---

Use for slow builds, test feedback lag, poor cache use, and tooling friction.
