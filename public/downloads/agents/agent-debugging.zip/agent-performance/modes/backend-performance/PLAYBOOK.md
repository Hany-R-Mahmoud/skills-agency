---
name: backend-performance
description: Improve backend latency, throughput, query efficiency, and resource usage with attention to production behavior.
---

Use for hot paths, DB/query issues, concurrency limits, and service bottlenecks.
