---
name: profiling
description: Gather performance evidence through instrumentation, profiling, and bottleneck isolation before suggesting fixes.
---

Use for flame graphs, traces, browser tools, query timing, and hotspot
identification.
