# Performance Guide

`agent-performance` is the optimization and profiling entry point for apps,
systems, and developer experience.

## What It Does

It focuses on real bottlenecks instead of premature tuning and helps teams
measure first, then optimize where it matters.

It is best at:

- profiling
- frontend performance
- backend latency
- DX optimization

## How To Use It

Call it with:

- `/agent-performance`
- `$agent-performance`

Use it when:

- something feels slow and you need profiling before changing code blindly
- a frontend, backend, or full app bottleneck needs targeted optimization
- developer workflow speed or feedback loops are getting in the team’s way

## How It Works

It reads the slowdown, picks the smallest useful performance lanes, identifies
the hotspot, and returns a practical optimization path with tradeoffs.

## Internal Playbooks

- `Performance Foundation` (`performance-foundation`): establishes the
  measurement-first approach before optimization changes are made
- `Profiling` (`profiling`): finds the actual hotspots across render, compute,
  latency, and throughput
- `Frontend Performance` (`frontend-performance`): targets re-render cost,
  bundle weight, and interaction responsiveness
- `Backend Performance` (`backend-performance`): works through throughput,
  latency, and expensive server-side paths
- `DX Optimization` (`dx-optimization`): improves local feedback loops, build
  time, and developer throughput

## Short Version

Use `/agent-performance` or `$agent-performance` when you need measured
optimization instead of guesswork.
