# Skill Map

## Foundation

- `performance-foundation`: `modes/performance-foundation/PLAYBOOK.md`, shared
  measurement-first rules, baseline capture, and optimization guardrails

Always start with `performance-foundation`.

## Modes

- `profiling`: `modes/profiling/PLAYBOOK.md`, instrumentation and evidence
  gathering
- `app-performance`: `modes/app-performance/PLAYBOOK.md`, end-to-end bottleneck
  analysis across the application
- `frontend-performance`: `modes/frontend-performance/PLAYBOOK.md`, rendering,
  bundle, network, and UI responsiveness
- `backend-performance`: `modes/backend-performance/PLAYBOOK.md`, latency,
  throughput, query, and compute bottlenecks
- `dx-optimization`: `modes/dx-optimization/PLAYBOOK.md`, build, test, and
  tooling performance for developers
