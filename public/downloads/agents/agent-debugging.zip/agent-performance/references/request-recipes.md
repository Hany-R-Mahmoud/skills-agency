# Request Recipes

- "Profile this":
  start with `performance-foundation`; add `profiling`
- "Make the app faster":
  start with `performance-foundation`; add `app-performance`
- "Frontend feels slow":
  start with `performance-foundation`; add `frontend-performance`
- "Backend is slow":
  start with `performance-foundation`; add `backend-performance`
- "The dev workflow is too slow":
  start with `performance-foundation`; add `dx-optimization`
