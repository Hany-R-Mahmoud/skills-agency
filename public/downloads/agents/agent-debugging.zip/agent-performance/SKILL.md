---
name: agent-performance
description: Unified performance and optimization agent for this skill pack. Use when Codex should handle profiling, frontend or backend performance, system bottlenecks, or developer-experience optimization through one local entry point.
---

# Agent Performance

Provide a single public entry point for performance analysis and optimization
work.

Act as a router plus executor: choose the smallest set of performance modes
needed, sequence them well, and avoid loading irrelevant guidance.

## Invocation Contract

Invoke this skill directly as `$agent-performance` whenever the prompt is about
profiling, bottlenecks, frontend performance, backend latency, throughput,
resource efficiency, or developer-experience optimization.

## Quick Start

- "profile this system":
  `performance-foundation`, then `profiling`
- "fix frontend performance":
  `performance-foundation`, then `frontend-performance`
- "fix backend performance":
  `performance-foundation`, then `backend-performance`
- "general app performance":
  `performance-foundation`, then `app-performance`
- "speed up the developer workflow":
  `performance-foundation`, then `dx-optimization`

## Reference

Use these references as needed:

- `references/skill-map.md`
- `references/request-recipes.md`
- `references/performance-depth-map.md`
